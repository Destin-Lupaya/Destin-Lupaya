import 'package:orion/Resources/AppStateProvider/user_stateprovider.dart';
import 'package:orion/Resources/Components/button.dart';
import 'package:orion/Resources/Components/decorated_container.dart';
import 'package:orion/Resources/Components/empty_model.dart';
import 'package:orion/Resources/Components/texts.dart';
import 'package:orion/Resources/global_variables.dart';
import 'package:orion/Resources/responsive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class BibliothequePage extends StatefulWidget {
  const BibliothequePage({Key? key}) : super(key: key);

  @override
  _BibliothequePageState createState() => _BibliothequePageState();
}

class _BibliothequePageState extends State<BibliothequePage> {
  final ScrollController _controller = ScrollController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: Consumer(builder: (context, appStateProvider, _) {
        return SingleChildScrollView(
          controller: _controller,
          child: Column(
            children: [
              Consumer<UserStateProvider>(
                  builder: (context, userStateProvider, _) {
                return DecoratedContainer(
                  backColor: AppColors.kBlackColor.withOpacity(0.5),
                  child: Row(
                    children: [
                      Expanded(
                          flex: 4,
                          child: TextWidgets.textBold(
                              title: 'Mes fichiers',
                              fontSize: 18,
                              textColor: AppColors.kWhiteColor)),
                      Expanded(
                        flex: 1,
                        child: CustomButton(
                            text: 'Add a file',
                            icon: Icons.add_to_photos_rounded,
                            backColor: AppColors.kYellowColor,
                            textColor: AppColors.kBlackColor,
                            callback: () async {
                              FilePickerResult? fileResult =
                                  await FilePicker.platform.pickFiles(
                                      allowMultiple: true,
                                      type: FileType.custom,
                                      allowedExtensions: [
                                    "png",
                                    "pdf",
                                    "jpg",
                                    "jpeg",
                                    "doc",
                                    "docx"
                                  ]);
                              if (fileResult != null && fileResult.count > 0) {
                                userStateProvider.addFiles(
                                    context: context,
                                    picked: fileResult.files,
                                    callback: () {});
                              }
                            }),
                      ),
                    ],
                  ),
                );
              }),
              DecoratedContainer(
                backColor: AppColors.kBlackColor.withOpacity(0.5),
                child: Consumer<UserStateProvider>(
                    builder: (context, userStateProvider, _) {
                  return userStateProvider.pickedFiles.isNotEmpty
                      ? GridView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: userStateProvider.pickedFiles.length,
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                                  mainAxisSpacing: 5,
                                  crossAxisSpacing: 5,
                                  crossAxisCount:
                                      Responsive.isMobile(context) ? 2 : 5),
                          itemBuilder: (context, int index) {
                            return fileContainer(
                                file: userStateProvider.pickedFiles[index]);
                          })
                      : EmptyModel(color: AppColors.kGreyColor);
                }),
              )
            ],
          ),
        );
      })),
    );
  }

  fileContainer({required PlatformFile file}) {
    return GestureDetector(
      onTap: () {
        showCupertinoModalPopup(
            context: context,
            builder: (builder) {
              return Center(
                child: Container(
                  padding: const EdgeInsets.all(10),
                  child: Image.memory(file.bytes!),
                ),
              );
            });
      },
      child: Container(
          color: Colors.white.withOpacity(0.1),
          child: Stack(children: [
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              child: Container(
                width: double.maxFinite,
                height: double.maxFinite,
                padding: const EdgeInsets.all(0),
                child: Image.memory(
                  file.bytes!,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            Positioned(
                left: 0,
                right: 0,
                bottom: -2,
                child: Container(
                  padding: EdgeInsets.all(5),
                  decoration: BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                          colors: [
                        Colors.black,
                        Colors.black.withOpacity(0.5)
                      ])),
                  child: TextWidgets.textBold(
                      title: file.name,
                      fontSize: 12,
                      textColor: AppColors.kWhiteColor),
                )),
            Positioned(
                right: 0,
                top: 0,
                child: Container(
                  padding: const EdgeInsets.all(5),
                  decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.5),
                      borderRadius: const BorderRadius.only(
                          bottomLeft: Radius.circular(10))),
                  child: TextWidgets.text300(
                      title:
                          "${((file.size / 1024) / 1024).toStringAsFixed(2)} mb",
                      fontSize: 10,
                      textColor: AppColors.kWhiteColor),
                )),
          ])),
    );
  }

  // fileWidget() {
  //   return Container(
  //       child: ListTile(
  //     onTap: () {
  //       showCupertinoModalPopup(
  //           context: context,
  //           builder: (builder) {
  //             return Center(
  //               child: Container(
  //                 padding: const EdgeInsets.all(10),
  //                 child:
  //                     Image.memory(userStateProvider.pickedFiles[index].bytes!),
  //               ),
  //             );
  //           });
  //     },
  //     leading: Container(
  //       width: 60,
  //       height: 60,
  //       padding: const EdgeInsets.all(10),
  //       child: Image.memory(userStateProvider.pickedFiles[index].bytes!),
  //     ),
  //     title: TextWidgets.textBold(
  //         title: userStateProvider.pickedFiles[index].name,
  //         fontSize: 16,
  //         textColor: AppColors.kWhiteColor),
  //     subtitle: TextWidgets.text300(
  //         title: userStateProvider.pickedFiles[index].extension!,
  //         fontSize: 16,
  //         textColor: AppColors.kGreyColor),
  //     trailing: TextWidgets.text300(
  //         title:
  //             "${(userStateProvider.pickedFiles[index].size / 1024).toString()} kb",
  //         fontSize: 16,
  //         textColor: AppColors.kWhiteColor),
  //   ));
  // }
}
