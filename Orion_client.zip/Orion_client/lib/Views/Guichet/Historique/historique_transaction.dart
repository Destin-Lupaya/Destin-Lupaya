import 'package:orion/Resources/AppStateProvider/loan_stateprovider.dart';

import 'package:orion/Resources/Components/dialogs.dart';
import 'package:orion/Resources/Components/dropdown_button.dart';
import 'package:orion/Resources/Components/empty_model.dart';
import 'package:orion/Resources/Components/search_textfield.dart';

import 'package:orion/Resources/Models/Guichet_Model/historique_model.dart';
import 'package:orion/Resources/Models/saved_loan.model.dart';
import 'package:orion/Resources/responsive.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:orion/Views/Guichet/review_transaction.dart';
import 'package:provider/provider.dart';

import 'package:orion/Resources/Components/texts.dart';
import 'package:orion/Resources/global_variables.dart';

class HistortransList extends StatefulWidget {
  HistortransList({Key? key}) : super(key: key);

  @override
  State<HistortransList> createState() => _HistortransListState();
}

class _HistortransListState extends State<HistortransList> {
  final TextEditingController _searchCtrller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Card(
      color: AppColors.kBlackColor.withOpacity(0.5),
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(kDefaultPadding / 2)),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Column(
              children: [
                TextWidgets.textNormal(
                    title: 'Dernières transactions',
                    fontSize: 18,
                    textColor: AppColors.kWhiteColor),
                Row(
                  children: [
                    !Responsive.isMobile(context)
                        ? Expanded(flex: 2, child: Container())
                        : Container(),
                    Expanded(
                      child: SearchTextFormFieldWidget(
                          backColor: AppColors.kTextFormWhiteColor,
                          hintText: 'Recherchez...',
                          isObsCured: false,
                          editCtrller: _searchCtrller,
                          textColor: AppColors.kWhiteColor,
                          maxLines: 1),
                    ),
                  ],
                )
              ],
            ),
            filterWidget(),
            const SizedBox(
              height: 20,
            ),
            buildLoansList(context: context)
          ],
        ),
      ),
    );
  }

  String statusFilter = "Initiated", creditFilter = "Voir l'historique Virtuel";

  filterWidget() {
    return Row(
      children: [
        Expanded(
            child: CustomDropdownButton(
                backColor: AppColors.kWhiteDarkColor,
                value: statusFilter,
                hintText: 'Status',
                callBack: (value) {},
                items: const [
              "Initiated",
              "En cours d'étude",
              "En attente",
              "Pending",
              "Denied"
            ])),
        Expanded(
            child: CustomDropdownButton(
                backColor: AppColors.kWhiteDarkColor,
                value: creditFilter,
                hintText: 'Type Historique',
                callBack: (value) {},
                items: const [
              "Voir l'historique Virtuel",
              "Voir l'historique Cash"
            ])),
      ],
    );
  }

  buildLoansList({required BuildContext context}) {
    return Consumer<LoanStateProvider>(
      builder: (context, loanProvider, _) {
        return ListView(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          children: [
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: 5,
              itemBuilder: (context, int paybackIndex) {
                return paybackItem(
                    // singlePayback:
                    //     Provider.of<LoanStateProvider>(context, listen: false)
                    //         .myLoans[paybackIndex]
                    //         .payback![paybackIndex],
                    );
              },
            ),
            ExpansionTile(
              backgroundColor: Color.fromRGBO(30, 30, 30, 1),
              title: TextWidgets.textBold(
                title: "En attente",
                fontSize: 14,
                textColor: AppColors.kWhiteColor,
              ),
              children: [
                loanProvider.myLoans
                        .where(
                            (loan) => loan.status!.toLowerCase() == 'initiated')
                        .toList()
                        .isNotEmpty
                    ? ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: loanProvider.myLoans
                            .where((loan) =>
                                loan.status!.toLowerCase() == 'initiated')
                            .toList()
                            .length,
                        itemBuilder: (context, int index) {
                          return trackItem(
                            savedLoan: loanProvider.myLoans
                                .where((loan) =>
                                    loan.status!.toLowerCase() == 'initiated')
                                .toList()[index],
                            index: index,
                          );
                        },
                      )
                    : EmptyModel(color: AppColors.kGreyColor)
              ],
            ),
            ExpansionTile(
              backgroundColor: Color.fromRGBO(30, 30, 30, 1),
              title: TextWidgets.textBold(
                title: "En cours d'etude",
                fontSize: 14,
                textColor: AppColors.kWhiteColor,
              ),
              children: [
                loanProvider.myLoans
                        .where(
                            (loan) => loan.status!.toLowerCase() == 'en etude')
                        .toList()
                        .isNotEmpty
                    ? ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: loanProvider.myLoans
                            .where((loan) =>
                                loan.status!.toLowerCase() == 'en etude')
                            .toList()
                            .length,
                        itemBuilder: (context, int index) {
                          return trackItem(
                            savedLoan: loanProvider.myLoans
                                .where((loan) =>
                                    loan.status!.toLowerCase() == 'en etude')
                                .toList()[index],
                            index: index,
                          );
                        },
                      )
                    : EmptyModel(color: AppColors.kGreyColor)
              ],
            ),
            ExpansionTile(
              backgroundColor: Color.fromRGBO(30, 30, 30, 1),
              title: TextWidgets.textBold(
                title: "En attente",
                fontSize: 14,
                textColor: AppColors.kWhiteColor,
              ),
              children: [
                loanProvider.myLoans
                        .where((loan) =>
                            loan.status!.toLowerCase() == 'en decaissement')
                        .toList()
                        .isNotEmpty
                    ? ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: loanProvider.myLoans
                            .where((loan) =>
                                loan.status!.toLowerCase() == 'en decaissement')
                            .toList()
                            .length,
                        itemBuilder: (context, int index) {
                          return trackItem(
                            savedLoan: loanProvider.myLoans
                                .where((loan) =>
                                    loan.status!.toLowerCase() ==
                                    'en decaissement')
                                .toList()[index],
                            index: index,
                          );
                        },
                      )
                    : EmptyModel(color: AppColors.kGreyColor)
              ],
            ),
            ExpansionTile(
              backgroundColor: Color.fromRGBO(30, 30, 30, 1),
              title: TextWidgets.textBold(
                title: "Pending",
                fontSize: 14,
                textColor: AppColors.kWhiteColor,
              ),
              children: [
                loanProvider.myLoans
                        .where(
                            (loan) => loan.status!.toLowerCase() == 'decaissé')
                        .toList()
                        .isNotEmpty
                    ? ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: loanProvider.myLoans
                            .where((loan) =>
                                loan.status!.toLowerCase() == 'decaissé')
                            .toList()
                            .length,
                        itemBuilder: (context, int index) {
                          return trackItem(
                            savedLoan: loanProvider.myLoans
                                .where((loan) =>
                                    loan.status!.toLowerCase() == 'decaissé')
                                .toList()[index],
                            index: index,
                          );
                        },
                      )
                    : EmptyModel(color: AppColors.kGreyColor)
              ],
            ),
            ExpansionTile(
              backgroundColor: Color.fromRGBO(30, 30, 30, 1),
              title: TextWidgets.textBold(
                title: "Denied",
                fontSize: 14,
                textColor: AppColors.kWhiteColor,
              ),
              children: [
                loanProvider.myLoans
                        .where(
                            (loan) => loan.status!.toLowerCase() == 'remboursé')
                        .toList()
                        .isNotEmpty
                    ? ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: loanProvider.myLoans
                            .where((loan) =>
                                loan.status!.toLowerCase() == 'remboursé')
                            .toList()
                            .length,
                        itemBuilder: (context, int index) {
                          return trackItem(
                            savedLoan: loanProvider.myLoans
                                .where((loan) =>
                                    loan.status!.toLowerCase() == 'remboursé')
                                .toList()[index],
                            index: index,
                          );
                        },
                      )
                    : EmptyModel(color: AppColors.kGreyColor)
              ],
            ),
          ],
        );
      },
    );
    // return ListView.builder(
    //   shrinkWrap: true,
    //   physics: const NeverScrollableScrollPhysics(),
    //   itemCount: loanProvider.myLoans.length,
    //   itemBuilder: (context, int index) {
    //     return trackItem(
    //       savedLoan: loanProvider.myLoans[index],
    //       index: index,
    //     );
    //   },
    // );
  }

  int selectedLoanID = 0;

  trackItem({
    required SavedLoanModel savedLoan,
    required int index,
  }) {
    double total = 0;
    ;
    if (savedLoan.payback != null && savedLoan.payback!.isNotEmpty) {
      for (int i = 0; i < savedLoan.payback!.length; i++) {
        for (int y = 0; y < savedLoan.payback![i].payment!.length; y++) {
          total = total +
              double.parse(
                  savedLoan.payback![i].payment![y]['amount'].toString());
        }
      }
    }
    return Container(
      child: Stack(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            margin: const EdgeInsets.only(top: 15),
            child: Container(
              padding: const EdgeInsets.all(10),
              margin: const EdgeInsets.all(0),
              decoration: BoxDecoration(
                  color: AppColors.kBlackColor.withOpacity(1),
                  border: Border.all(
                      color: selectedLoanID == savedLoan.id!
                          ? AppColors.kYellowColor
                          : AppColors.kTransparentColor,
                      width: 2),
                  borderRadius: BorderRadius.circular(10)),
              child: ExpansionTile(
                onExpansionChanged: (value) {
                  if (value == true) {
                    if (savedLoan.status!.toLowerCase() != 'decaissé') {
                      Dialogs.showDialogNoAction(
                          heightFactor: 2,
                          context: context,
                          title: 'Error',
                          content:
                              'Vous ne pouvez pas rembourser un crédit qui n\'est pas encore decaissé');
                      return;
                    }
                    selectedLoanID = savedLoan.id!;
                    Provider.of<LoanStateProvider>(context, listen: false)
                        .getRefundCalendar(
                            context: context,
                            loanID: savedLoan.id!.toString(),
                            callback: () {});
                  } else {
                    selectedLoanID = 0;
                  }
                  setState(() {});
                },
                tilePadding: EdgeInsets.zero,
                title: Column(
                  children: [
                    ListTile(
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          TextWidgets.textBold(
                            title: "Approvisionez-vous chez l' agregateur",
                            // savedLoan.loanData.designation.toString().trim(),
                            fontSize: 14,
                            textColor: AppColors.kWhiteColor,
                          ),
                          TextWidgets.text300(
                            title:
                                '${savedLoan.duration.toString().trim()} mois',
                            fontSize: 14,
                            textColor: AppColors.kWhiteColor,
                          )
                        ],
                      ),
                      // trailing: TextWidgets.text300(
                      //   title: '${savedLoan.duration.toString().trim()} mois',
                      //   fontSize: 14,
                      //   textColor: AppColors.kWhiteColor,
                      // ),
                      subtitle: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10.0),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                TextWidgets.text300(
                                  title:
                                      '${savedLoan.refundMode.toString().trim().toUpperCase()}',
                                  fontSize: 14,
                                  textColor: AppColors.kWhiteColor,
                                ),
                                TextWidgets.text300(
                                  title: savedLoan.payback!.isNotEmpty
                                      ? "${(savedLoan.payback![0].interestRate * savedLoan.duration).toStringAsFixed(2).trim()}\$ d'intéret"
                                      : "",
                                  fontSize: 14,
                                  textColor: AppColors.kWhiteColor,
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),
                            TextWidgets.text300(
                              title: savedLoan.payback!.isNotEmpty
                                  ? 'Remboursement: ${savedLoan.payback!.length > 0 ? ((total * 100) / (savedLoan.amount + (savedLoan.payback![0].interestRate * savedLoan.duration))).toStringAsFixed(3) : "0"}%'
                                  : 'En attente...',
                              fontSize: 12,
                              textColor: AppColors.kWhiteColor,
                            ),
                            Container(
                                width: 100,
                                height: 5,
                                decoration: BoxDecoration(
                                  color:
                                      AppColors.kYellowColor.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Container(
                                      height: 5,
                                      width: (total * 100) / savedLoan.amount,
                                      // savedLoan.payback == null?0:(double.parse(savedLoan.payback!.map((refundData) => refundData.payment!.isNotEmpty && refundData.payment != null ? refundData.payment!.map((payment) => payment['amount']).reduce((prev, next) => prev + next) : "0").toList()[0].toString()) * 100) / savedLoan.amount,
                                      decoration: BoxDecoration(
                                          color: AppColors.kYellowColor,
                                          borderRadius:
                                              BorderRadius.circular(20))),
                                )),
                            GestureDetector(
                              onTap: () {
                                // showCupertinoModalPopup(
                                //     context: context,
                                //     builder: (context) {
                                //       return Center(
                                //           child: FeesPaymentPage(
                                //         loanToPayTo: savedLoan,
                                //       ));
                                //     });
                              },
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                    vertical: 10.0, horizontal: 16),
                                margin: const EdgeInsets.symmetric(
                                    vertical: 10.0, horizontal: 0),
                                decoration: BoxDecoration(
                                    color:
                                        AppColors.kWhiteColor.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(20)),
                                child: TextWidgets.text300(
                                    title: 'Voir les frais',
                                    fontSize: 14,
                                    textColor: AppColors.kWhiteColor),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                children: [
                  Provider.of<LoanStateProvider>(context, listen: false)
                              .myLoans[index]
                              .payback !=
                          null
                      ? ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: Provider.of<LoanStateProvider>(context,
                                  listen: false)
                              .myLoans[index]
                              .payback!
                              .length,
                          itemBuilder: (context, int paybackIndex) {
                            return paybackItem();
                          },
                        )
                      : EmptyModel(color: AppColors.kGreyColor),
                ],
              ),
            ),
          ),
          Positioned(
            top: 0,
            right: 20,
            child: Center(
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 24, vertical: 8),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(50),
                    color: AppColors.kYellowColor),
                child: TextWidgets.textBold(
                  title: '${savedLoan.amount.toString().trim()}\$',
                  fontSize: 14,
                  textColor: AppColors.kBlackColor,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  paybackItem() {
    return Container(
      child: Stack(
        children: [
          GestureDetector(
            onTap: () {
              showCupertinoModalPopup(
                  context: context,
                  builder: (context) => Center(
                          child: ReviewApprovPage(
                        creationActiviteModel: HistoriqueModel.fromJson({
                          "designation": "test",
                          "caissier": "test",
                          "solde_virtuel_CDF": "test",
                          "solde_virtuel_USD": "test",
                          "solde_cash_CDF": "test",
                          "solde_cash_USD": "test",
                        }),
                        updatingData: true,
                      )));
            },
            child: Container(
              padding: const EdgeInsets.only(left: 10),
              margin: const EdgeInsets.only(left: 5),
              decoration: const BoxDecoration(
                  border:
                      Border(left: BorderSide(color: Colors.yellow, width: 2))),
              child: Container(
                width: double.maxFinite,
                padding: const EdgeInsets.all(10),
                margin: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                    color: AppColors.kBlackLightColor.withOpacity(0.6),
                    border: Border.all(color: Colors.red),
                    borderRadius: BorderRadius.circular(10)),
                child: Column(
                  children: [
                    // if (Responsive.isMobile(context))
                    Responsive(
                        mobile: Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                //crossAxisAlignment: CrossAxisAlignment.spaceBetween,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  TextWidgets.textWithLabel(
                                      title: 'Jour',
                                      fontSize: 14,
                                      textColor: AppColors.kWhiteColor,
                                      value: "2001-09-09"),
                                  TextWidgets.textWithLabel(
                                      title: 'Demandeur',
                                      fontSize: 14,
                                      textColor: AppColors.kWhiteColor,
                                      value: 'Destin Kabote'),
                                  TextWidgets.textWithLabel(
                                      title: 'Montant',
                                      fontSize: 14,
                                      textColor: AppColors.kWhiteColor,
                                      value: '120'),
                                  TextWidgets.textWithLabel(
                                      title: 'Type Transaction',
                                      fontSize: 14,
                                      textColor: AppColors.kWhiteColor,
                                      value: 'Virtuel/Cash'),
                                  TextWidgets.textWithLabel(
                                      title: 'Devise',
                                      fontSize: 14,
                                      textColor: AppColors.kWhiteColor,
                                      value: 'CDF/USD'),
                                  TextWidgets.textWithLabel(
                                      title: 'Niveau d\'alerte',
                                      fontSize: 14,
                                      textColor: AppColors.kWhiteColor,
                                      value: 'Rupture de Stock'),
                                ],
                              ),
                            ),
                          ],
                        ),
                        tablet: Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  TextWidgets.textWithLabel(
                                      title: 'Jour',
                                      fontSize: 14,
                                      textColor: AppColors.kWhiteColor,
                                      value: "2001-09-09"),
                                  TextWidgets.textWithLabel(
                                      title: 'Demandeur',
                                      fontSize: 14,
                                      textColor: AppColors.kWhiteColor,
                                      value: 'Destin Kabote'),
                                  TextWidgets.textWithLabel(
                                      title: 'Montant',
                                      fontSize: 14,
                                      textColor: AppColors.kWhiteColor,
                                      value: '120'),
                                  TextWidgets.textWithLabel(
                                      title: 'Type Transaction',
                                      fontSize: 14,
                                      textColor: AppColors.kWhiteColor,
                                      value: 'Virtuel/Cash'),
                                  TextWidgets.textWithLabel(
                                      title: 'Devise',
                                      fontSize: 14,
                                      textColor: AppColors.kWhiteColor,
                                      value: 'CDF/USD'),
                                  TextWidgets.textWithLabel(
                                      title: 'Niveau d\'alerte',
                                      fontSize: 14,
                                      textColor: AppColors.kWhiteColor,
                                      value: 'Rupture de Stock'),
                                ],
                              ),
                            ),
                          ],
                        ),
                        web: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              TextWidgets.textWithLabel(
                                  title: 'Jour',
                                  fontSize: 14,
                                  textColor: AppColors.kWhiteColor,
                                  value: "2001-09-09"),
                              TextWidgets.textWithLabel(
                                  title: 'Demandeur',
                                  fontSize: 14,
                                  textColor: AppColors.kWhiteColor,
                                  value: 'Destin Kabote'),
                              TextWidgets.textWithLabel(
                                  title: 'Montant',
                                  fontSize: 14,
                                  textColor: AppColors.kWhiteColor,
                                  value: '120'),
                              TextWidgets.textWithLabel(
                                  title: 'Type Transaction',
                                  fontSize: 14,
                                  textColor: AppColors.kWhiteColor,
                                  value: 'Virtuel/Cash'),
                              TextWidgets.textWithLabel(
                                  title: 'Devise',
                                  fontSize: 14,
                                  textColor: AppColors.kWhiteColor,
                                  value: 'CDF/USD'),
                              TextWidgets.textWithLabel(
                                  title: 'Niveau d\'alerte',
                                  fontSize: 14,
                                  textColor: AppColors.kWhiteColor,
                                  value: 'Rupture de Stock'),
                            ],
                          ),
                        )),

                    // if (!Responsive.isMobile(context))
                    //   Row(
                    //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    //     children: [
                    //       TextWidgets.textWithLabel(
                    //           title: 'Jour',
                    //           fontSize: 14,
                    //           textColor: AppColors.kWhiteColor,
                    //           value: "2021-09-09"),
                    //       TextWidgets.textWithLabel(
                    //           title: 'Demandeur',
                    //           fontSize: 14,
                    //           textColor: AppColors.kWhiteColor,
                    //           value: 'Destin Kabote'),
                    //       TextWidgets.textWithLabel(
                    //           title: 'Montant',
                    //           fontSize: 14,
                    //           textColor: AppColors.kWhiteColor,
                    //           value: '120\$'),
                    //       TextWidgets.textWithLabel(
                    //           title: 'Type Transaction',
                    //           fontSize: 14,
                    //           textColor: AppColors.kWhiteColor,
                    //           value: 'Virtuel/Cash'),
                    //       TextWidgets.textWithLabel(
                    //           title: 'Devise',
                    //           fontSize: 14,
                    //           textColor: AppColors.kWhiteColor,
                    //           value: 'CDF/USD'),
                    //       TextWidgets.textWithLabel(
                    //           title: 'Niveau d\'alerte',
                    //           fontSize: 14,
                    //           textColor: AppColors.kWhiteColor,
                    //           value: 'Rupture de Stock'),
                    //     ],
                    //   ),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            top: 0,
            left: 0,
            bottom: 0,
            child: Center(
              child: Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(50),
                    color: AppColors.kRedColor),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
