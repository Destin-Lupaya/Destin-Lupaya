import 'package:orion/Resources/AppStateProvider/app_stateprovider.dart';

import 'package:orion/Resources/AppStateProvider/user_stateprovider.dart';
import 'package:orion/Resources/Components/button.dart';
import 'package:orion/Resources/Components/dropdown_button.dart';
import 'package:orion/Resources/Components/empty_model.dart';
import 'package:orion/Resources/Components/modal_progress.dart';
import 'package:orion/Resources/Components/search_textfield.dart';
import 'package:orion/Resources/Components/card.dart';
import 'package:orion/Resources/Components/searchable_textfield.dart';
import 'package:orion/Resources/Components/text_fields.dart';
import 'package:orion/Resources/Components/texts.dart';
import 'package:orion/Resources/Models/Guichet_Model/activite_model.dart';
import 'package:orion/Resources/Models/Guichet_Model/historique_model.dart';
import 'package:orion/Resources/global_variables.dart';
import 'package:flutter/material.dart';
import 'package:orion/Resources/responsive.dart';
import 'package:provider/provider.dart';

class ReviewApprovPage extends StatefulWidget {
  final bool updatingData;

  final HistoriqueModel? creationActiviteModel;
  const ReviewApprovPage(
      {Key? key, required this.updatingData, this.creationActiviteModel})
      : super(key: key);

  @override
  _ReviewApprovPageState createState() => _ReviewApprovPageState();
}

List<String> typeactiviteList = ["Mobile Money", "Autres"];
late String typeactiviteMode = "Mobile Money";

String? nomFournisseur;
String? membreInterne;

String? nomMembre;

class _ReviewApprovPageState extends State<ReviewApprovPage> {
  final PageController _controller = PageController();
  String? sousCompteId;
  final TextEditingController _dateCtrller = TextEditingController();
  final TextEditingController _demandeurtCtrller = TextEditingController();
  final TextEditingController _montantCtrller = TextEditingController();

  final TextEditingController _typeCtrller = TextEditingController();
  final TextEditingController _deviseCDFCtrller = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.updatingData == true) {
      _dateCtrller.text = widget.creationActiviteModel!.designation.trim();
      _demandeurtCtrller.text =
          widget.creationActiviteModel!.description.trim();
      _montantCtrller.text = widget.creationActiviteModel!.caissier.trim();
      _typeCtrller.text =
          widget.creationActiviteModel!.type_activite.toString().trim();
      _deviseCDFCtrller.text =
          widget.creationActiviteModel!.solde_virtuel_CDF.toString().trim();
    }
    WidgetsBinding.instance!.addPostFrameCallback((timeStamp) {
      // Provider.of<UserStateProvider>(context, listen: false)
      //     .getactivities(context: context, isRefreshed: false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        width: Responsive.isMobile(context)
            ? MediaQuery.of(context).size.width
            : MediaQuery.of(context).size.width / 2,
        height: MediaQuery.of(context).size.height * .85,
        // color: AppColors.kBlackLightColor,
        child:
            Consumer<AppStateProvider>(builder: (context, appStateProvider, _) {
          return ModalProgress(
              isAsync: appStateProvider.isAsync,
              progressColor: AppColors.kYellowColor,
              child: ListView(
                  // shrinkWrap: true,
                  // physics: const NeverScrollableScrollPhysics(),
                  children: [
                    CardWidget(
                      backColor: AppColors.kBlackLightColor,
                      title: 'Modifier la demande d\'Approvisionnement',
                      content: Wrap(children: [
                        Row(children: [
                          Expanded(
                            child: TextFormFieldWidget(
                              maxLines: 1,
                              hintText: 'Date',
                              editCtrller: _dateCtrller,
                              textColor: AppColors.kWhiteColor,
                              backColor: AppColors.kTextFormWhiteColor,
                            ),
                          ),
                          Expanded(
                            child: TextFormFieldWidget(
                              maxLines: 1,
                              hintText: 'Demandeur',
                              editCtrller: _demandeurtCtrller,
                              textColor: AppColors.kWhiteColor,
                              backColor: AppColors.kTextFormWhiteColor,
                            ),
                          ),
                        ]),
                        // Row(
                        //   children: [
                        //     Expanded(
                        //       child: CustomDropdownButton(
                        //           value: typeactiviteMode,
                        //           hintText: "Type d\'activites ",
                        //           callBack: (newValue) {
                        //             setState(() {
                        //               typeactiviteMode = newValue;
                        //             });
                        //           },
                        //           items: typeactiviteList),
                        //     ),
                        //   ],
                        // ),
                        Row(
                          children: [
                            Expanded(
                              child: TextFormFieldWidget(
                                maxLines: 1,
                                hintText: 'Montant',
                                editCtrller: _montantCtrller,
                                textColor: AppColors.kWhiteColor,
                                backColor: AppColors.kTextFormWhiteColor,
                              ),
                            ),
                            Expanded(
                              child: TextFormFieldWidget(
                                maxLines: 1,
                                hintText: 'Type Transaction',
                                editCtrller: _typeCtrller,
                                textColor: AppColors.kWhiteColor,
                                backColor: AppColors.kTextFormWhiteColor,
                              ),
                            ),
                          ],
                        ),
                        Consumer<UserStateProvider>(
                            builder: (context, userStateProvider, _) {
                          return Row(children: [
                            Expanded(
                              child: CustomButton(
                                text: 'Supprimer',
                                backColor: AppColors.kRedColor,
                                textColor: AppColors.kWhiteColor,
                                callback: () {},
                              ),
                            ),
                            Expanded(
                              child: CustomButton(
                                text: 'Refuser',
                                backColor: AppColors.kRedColor.withOpacity(0.5),
                                textColor: AppColors.kWhiteColor,
                                callback: () {},
                              ),
                            ),
                            Expanded(
                                child: CustomButton(
                              text: 'Modifier',
                              backColor: AppColors.kYellowColor,
                              textColor: AppColors.kWhiteColor,
                              callback: () {
                                Map data = {
                                  "id": widget.creationActiviteModel!.id,
                                  "designation": "test",
                                  "caissier": "test",
                                  "solde_virtuel_CDF": "test",
                                  "solde_virtuel_USD": "test",
                                  "solde_cash_CDF": "test",
                                  "solde_cash_USD": "test",
                                };

                                userStateProvider.updateDemande(
                                    context: context,
                                    historique: HistoriqueModel.fromJson(data),
                                    callback: () {
                                      Navigator.pop(context);
                                    });
                              },
                            ))
                          ]);

                          //DisplayCaissePage()
                        }),
                      ]),
                    )
                  ]));
        }));
  }
}
