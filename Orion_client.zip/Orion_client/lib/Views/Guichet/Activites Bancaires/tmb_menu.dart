import 'package:orion/Resources/AppStateProvider/app_stateprovider.dart';

import 'package:orion/Resources/Components/search_textfield.dart';
import 'package:orion/Resources/Components/card.dart';
import 'package:orion/Resources/Components/card_title_subtitle_icon.dart';

import 'package:flutter/cupertino.dart';
import 'package:orion/Resources/Components/modal_progress.dart';

import 'package:orion/Views/Guichet/Activites Bancaires/tmb.dart';

import 'package:orion/Resources/global_variables.dart';
import 'package:orion/Resources/responsive.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AddTmbPage extends StatefulWidget {
  const AddTmbPage({Key? key}) : super(key: key);

  @override
  State<AddTmbPage> createState() => _AddTmbPageState();
}

class _AddTmbPageState extends State<AddTmbPage> {
  final TextEditingController _searchCtrller = TextEditingController();

  String type = "En cours";

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.kTransparentColor,
      child: Container(
          // padding: const EdgeInsets.symmetric(horizontal: 10),
          width: Responsive.isMobile(context)
              ? MediaQuery.of(context).size.width
              : MediaQuery.of(context).size.width / 2,
          height: MediaQuery.of(context).size.height * .85,
          // color: AppColors.kBlackLightColor,
          child: Consumer<AppStateProvider>(
              builder: (context, appStateProvider, child) {
            return ModalProgress(
              isAsync: appStateProvider.isAsync,
              progressColor: AppColors.kYellowColor,
              child: ListView(
                // shrinkWrap: false,
                // physics: const NeverScrollableScrollPhysics(),
                children: [
                  CardWidget(
                      backColor: AppColors.kBlackLightColor,
                      title: 'Tout vos comptes au meme endroit',
                      content: Column(
                        children: [
                          //Expanded(
                          //child:
                          SearchTextFormFieldWidget(
                              backColor: AppColors.kTextFormWhiteColor,
                              hintText: 'Recherchez...',
                              isObsCured: false,
                              editCtrller: _searchCtrller,
                              textColor: AppColors.kWhiteColor,
                              maxLines: 1),
                          //),
                          CardWithIconTitleSubtitle(
                              balance: {
                                "virtuel_CDF": "CDF: 100",
                                "virtuel_USD": "USD: 200",
                                "cash_CDF": "CDF: 300",
                                "cash_USD": "USD: 400"
                              },
                              width: !Responsive.isWeb(context)
                                  ? double.maxFinite
                                  : 300,
                              //icon: Icons.attach_money,
                              title: 'Transferez du cash',
                              image: Image.asset('Assets/Images/Orion/tmb.png'),
                              subtitle:
                                  "Transferez de l'argent rapidement a vos clients la TMB avec Orion",
                              title2: 'Compte 990268381 - Destin Kabote',
                              title3: '',
                              subtitle1: 'Soldes Cash',
                              subtitle2: 'Soldes Virtuel',
                              page: TmbPage(
                                updatingData: false,
                              ),
                              iconColor: AppColors.kYellowColor,
                              titleColor: AppColors.kWhiteColor,
                              subtitleColor: AppColors.kGreyColor),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              IconButton(
                                  onPressed: () {
                                    showCupertinoModalPopup(
                                        context: context,
                                        builder: (context) {
                                          return Center(
                                            child: TmbPage(
                                              updatingData: false,
                                            ),
                                          );
                                        });
                                  },
                                  icon: Icon(
                                    Icons.add_circle_outline,
                                    color: AppColors.kYellowColor,
                                  )),
                            ],
                          ),
                          CardWithIconTitleSubtitle(
                              width: !Responsive.isWeb(context)
                                  ? double.maxFinite
                                  : 300,
                              //icon: Icons.attach_money,
                              title: 'Transfert Virtuel',
                              image: Image.asset('Assets/Images/Orion/tmb.png'),
                              balance: {
                                "virtuel_CDF": "CDF: 100",
                                "virtuel_USD": "USD: 200",
                                "cash_CDF": "CDF: 300",
                                "cash_USD": "USD: 400"
                              },
                              subtitle:
                                  "Transferez de l'argent rapidement a vos clients la TMB  avec Orion",
                              title2: 'Compte 990268381 - Destin Kabote',
                              title3: '',
                              subtitle1: 'Soldes Cash',
                              subtitle2: 'Soldes Virtuel',
                              page: TmbPage(
                                updatingData: false,
                              ),
                              iconColor: AppColors.kYellowColor,
                              titleColor: AppColors.kWhiteColor,
                              subtitleColor: AppColors.kGreyColor),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              IconButton(
                                  onPressed: () {
                                    showCupertinoModalPopup(
                                        context: context,
                                        builder: (context) {
                                          return Center(
                                            child: TmbPage(
                                              updatingData: false,
                                            ),
                                          );
                                        });
                                  },
                                  icon: Icon(
                                    Icons.add_circle_outline,
                                    color: AppColors.kYellowColor,
                                  )),
                            ],
                          )
                        ],
                      ))
                ],
              ),
            );
          })),
    );
  }
}

// class CreditHistoryPage extends StatelessWidget {
//   const CreditHistoryPage({Key? key}) : super(key: key);
//   @override
//   Widget build(BuildContext context) {
//     return Consumer<UserStateProvider>(
//       builder: (context, userStateProvider, child) {
//         return userStateProvider.creditHistoryData.isNotEmpty
//             ? Column(
//                 children: [
//                   Container(
//                     padding:
//                         const EdgeInsets.symmetric(horizontal: 5, vertical: 10),
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                       children: [
//                         Expanded(
//                           flex: 4,
//                           child: TextWidgets.text300(
//                               title: 'Institution',
//                               fontSize: 14,
//                               textColor: AppColors.kWhiteColor),
//                         ),
//                         Expanded(
//                           flex: 2,
//                           child: TextWidgets.text300(
//                               title: 'Adresse',
//                               fontSize: 14,
//                               textColor: AppColors.kWhiteColor),
//                         ),
//                       ],
//                     ),
//                   ),
//                   Container(
//                     padding:
//                         const EdgeInsets.symmetric(horizontal: 5, vertical: 10),
//                     child: ListView.builder(
//                         shrinkWrap: true,
//                         physics: const NeverScrollableScrollPhysics(),
//                         itemCount: userStateProvider.creditHistoryData.length,
//                         itemBuilder: (context, int index) {
//                           return Column(
//                             children: [
//                               Container(
//                                 padding: const EdgeInsets.symmetric(
//                                     horizontal: 5, vertical: 10),
//                                 color: index % 2 == 0
//                                     ? AppColors.kWhiteColor.withOpacity(0.03)
//                                     : AppColors.kTransparentColor,
//                                 child: Row(
//                                   mainAxisAlignment:
//                                       MainAxisAlignment.spaceBetween,
//                                   children: [
//                                     Expanded(
//                                       flex: 4,
//                                       child: TextWidgets.text300(
//                                           title: userStateProvider
//                                               .creditHistoryData[index]
//                                               .institution
//                                               .trim(),
//                                           fontSize: 14,
//                                           textColor: AppColors.kWhiteColor),
//                                     ),
//                                     Expanded(
//                                       flex: 2,
//                                       child: TextWidgets.text300(
//                                           title: userStateProvider
//                                               .creditHistoryData[index].address
//                                               .trim(),
//                                           fontSize: 14,
//                                           textColor: AppColors.kWhiteColor),
//                                     ),
//                                   ],
//                                 ),
//                               ),
//                               Divider(
//                                   height: 2,
//                                   thickness: 1,
//                                   color: AppColors.kWhiteColor.withOpacity(0.4))
//                             ],
//                           );
//                         }),
//                   )
//                 ],
//               )
//             : EmptyModel(color: AppColors.kGreyColor);
//       },
//     );
//   }
// }
