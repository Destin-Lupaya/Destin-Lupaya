import 'package:orion/Resources/AppStateProvider/app_stateprovider.dart';
import 'package:orion/Resources/AppStateProvider/user_stateprovider.dart';
import 'package:orion/Resources/Components/button.dart';
import 'package:orion/Resources/Components/card.dart';
import 'package:orion/Resources/Components/empty_model.dart';
import 'package:orion/Resources/Components/modal_progress.dart';
import 'package:orion/Resources/Components/text_fields.dart';
import 'package:orion/Resources/Components/texts.dart';
import 'package:orion/Resources/Models/client_bank.model.dart';
import 'package:orion/Resources/global_variables.dart';
import 'package:orion/Resources/Models/Guichet_Model/envoyer_argent_model.dart';
import 'package:orion/Resources/responsive.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class TmbPage extends StatefulWidget {
  final bool updatingData;
  final EnvoieModel? envoieModel;
  TmbPage({Key? key, required this.updatingData, this.envoieModel})
      : super(key: key);

  @override
  State<TmbPage> createState() => _TmbPageState();
}

class _TmbPageState extends State<TmbPage> {
  final TextEditingController _nomCtrller = TextEditingController();
  final TextEditingController _commentCtrller = TextEditingController();
  final TextEditingController _montantCtrller = TextEditingController();
  final TextEditingController _pswCtrller = TextEditingController();
  final TextEditingController _searchCtrller = TextEditingController();
  @override
  void initState() {
    super.initState();
    if (widget.updatingData == true) {
      _nomCtrller.text = widget.envoieModel!.Nom_beneficiaire.trim();
      _commentCtrller.text = widget.envoieModel!.commentaire.toString().trim();
      _montantCtrller.text = widget.envoieModel!.montant.toString().trim();
      _pswCtrller.text = widget.envoieModel!.password.toString().trim();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.kTransparentColor,
      child: Container(
          // padding: const EdgeInsets.symmetric(horizontal: 10),
          width: Responsive.isMobile(context)
              ? MediaQuery.of(context).size.width
              : MediaQuery.of(context).size.width / 2,
          height: MediaQuery.of(context).size.height * .85,
          // color: AppColors.kBlackLightColor,
          child: Consumer<AppStateProvider>(
              builder: (context, appStateProvider, child) {
            return ModalProgress(
              isAsync: appStateProvider.isAsync,
              progressColor: AppColors.kYellowColor,
              child: ListView(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  CardWidget(
                      backColor: AppColors.kBlackLightColor,
                      title: 'Envoyer de l\'Argent via compte TMB',
                      content: Column(
                        children: [
                          TextFormFieldWidget(
                              backColor: AppColors.kTextFormBackColor,
                              hintText: 'Numero Beneficiaire',
                              editCtrller: _nomCtrller,
                              textColor: AppColors.kWhiteColor,
                              maxLines: 1),
                          TextFormFieldWidget(
                              backColor: AppColors.kTextFormBackColor,
                              hintText: 'Commentaire',
                              editCtrller: _commentCtrller,
                              textColor: AppColors.kWhiteColor,
                              maxLines: 1),
                          TextFormFieldWidget(
                              backColor: AppColors.kTextFormBackColor,
                              hintText: 'Montant',
                              editCtrller: _montantCtrller,
                              textColor: AppColors.kWhiteColor,
                              maxLines: 1),
                          TextFormFieldWidget(
                              backColor: AppColors.kTextFormBackColor,
                              hintText: 'Mot de pass',
                              editCtrller: _pswCtrller,
                              textColor: AppColors.kWhiteColor,
                              maxLines: 1),
                          Consumer<UserStateProvider>(
                              builder: (context, userStateProvider, _) {
                            return CustomButton(
                              backColor: AppColors.kYellowColor,
                              text: 'Envoyer',
                              textColor: AppColors.kBlackColor,
                              callback: () {
                                Map data = {
                                  //"id": widget.updatingData == true
                                  //? widget.pretModel.id!.toString() : "0",
                                  'Nom_beneficiaire': _nomCtrller.text.trim(),
                                  'commentaire': _commentCtrller.text.trim(),
                                  'montant': _montantCtrller.text.trim(),
                                  'password': _pswCtrller.text.trim(),
                                  'users_id': Provider.of<UserStateProvider>(
                                          context,
                                          listen: false)
                                      .userId
                                      .toString(),
                                };
                                userStateProvider.addBank(
                                    context: context,
                                    updatingData: widget.updatingData,
                                    bank: BankModel.fromJson(data),
                                    callback: () {
                                      Navigator.pop(context);
                                    });
                              },
                            );
                          })
                        ],
                      ))
                ],
              ),
            );
          })),
    );
  }
}

class EnvoieArgentsPage extends StatelessWidget {
  const EnvoieArgentsPage({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Consumer<UserStateProvider>(
      builder: (context, userStateProvider, child) {
        return userStateProvider.envoieModels.isNotEmpty
            ? Column(
                children: [
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          flex: 4,
                          child: TextWidgets.text300(
                              title: 'Numero du Destinateur',
                              fontSize: 14,
                              textColor: AppColors.kWhiteColor),
                        ),
                        Expanded(
                          flex: 2,
                          child: TextWidgets.text300(
                              title: 'Commentaire',
                              fontSize: 14,
                              textColor: AppColors.kWhiteColor),
                        ),
                        Expanded(
                          flex: 2,
                          child: TextWidgets.text300(
                              title: 'Montant',
                              fontSize: 14,
                              textColor: AppColors.kWhiteColor),
                        ),
                        //       Expanded(
                        //         flex: 2,
                        //         child: TextWidgets.text300(
                        //             title: 'Numéro du compte',
                        //             fontSize: 14,
                        //             textColor: AppColors.kWhiteColor),
                        //       ),
                        //       Expanded(
                        //         flex: 2,
                        //         child: TextWidgets.text300(
                        //             title: 'Action',
                        //             fontSize: 14,
                        //             textColor: AppColors.kWhiteColor),
                        //       ),
                      ],
                    ),
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 10),
                    child: ListView.builder(
                        physics: const NeverScrollableScrollPhysics(),
                        shrinkWrap: true,
                        itemCount: userStateProvider.envoieModels.length,
                        itemBuilder: (context, int index) {
                          return Column(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 5, vertical: 10),
                                color: index % 2 == 0
                                    ? AppColors.kWhiteColor.withOpacity(0.03)
                                    : AppColors.kTransparentColor,
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Expanded(
                                      flex: 4,
                                      child: TextWidgets.text300(
                                          title: userStateProvider
                                              .envoieModels[index]
                                              .Nom_beneficiaire
                                              .trim(),
                                          fontSize: 14,
                                          textColor: AppColors.kWhiteColor),
                                    ),
                                    Expanded(
                                      flex: 2,
                                      child: TextWidgets.text300(
                                          title: userStateProvider
                                              .envoieModels[index].commentaire
                                              .toString(),
                                          fontSize: 14,
                                          textColor: AppColors.kWhiteColor),
                                    ),
                                    Expanded(
                                      flex: 2,
                                      child: TextWidgets.text300(
                                          title: userStateProvider
                                              .envoieModels[index].montant
                                              .trim(),
                                          fontSize: 14,
                                          textColor: AppColors.kWhiteColor),
                                    ),
                                    Expanded(
                                      flex: 2,
                                      child: TextWidgets.text300(
                                          title: userStateProvider
                                              .envoieModels[index].password
                                              .trim(),
                                          fontSize: 14,
                                          textColor: AppColors.kWhiteColor),
                                    ),
                                    Expanded(
                                      flex: 2,
                                      child: Row(
                                        children: [
                                          GestureDetector(
                                            onTap: () {
                                              showCupertinoModalPopup(
                                                  context: context,
                                                  builder: (context) {
                                                    return Center(
                                                      child: TmbPage(
                                                        updatingData: true,
                                                        //bank: userStateProvider
                                                        //.banks[index],
                                                      ),
                                                    );
                                                  });
                                            },
                                            child: Icon(Icons.edit,
                                                color: AppColors.kGreenColor),
                                          ),
                                          const SizedBox(width: 10),
                                          GestureDetector(
                                            child: Icon(Icons.delete,
                                                color: AppColors.kRedColor),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Divider(
                                  height: 2,
                                  thickness: 1,
                                  color: AppColors.kWhiteColor.withOpacity(0.4))
                            ],
                          );
                        }),
                  )
                ],
              )
            : EmptyModel(color: AppColors.kGreyColor);
      },
    );
  }
}
