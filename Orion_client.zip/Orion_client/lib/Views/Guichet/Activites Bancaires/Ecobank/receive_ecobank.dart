import 'package:orion/Resources/AppStateProvider/app_stateprovider.dart';
import 'package:orion/Resources/AppStateProvider/user_stateprovider.dart';
import 'package:orion/Resources/Components/button.dart';
import 'package:orion/Resources/Components/card.dart';
import 'package:orion/Resources/Components/empty_model.dart';
import 'package:orion/Resources/Components/modal_progress.dart';
import 'package:orion/Resources/Components/text_fields.dart';
import 'package:orion/Resources/Components/texts.dart';
import 'package:orion/Resources/Components/dropdown_button.dart';
import 'package:orion/Resources/global_variables.dart';
import 'package:orion/Resources/Components/searchable_textfield.dart';
import 'package:orion/Resources/Models/Guichet_Model/approvisionement_model.dart';
import 'package:orion/Resources/Components/Guichet/applogo_ecobank.dart';
import 'package:orion/Resources/responsive.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

blockSeparator({required String title}) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(),
      const SizedBox(
        height: 20,
      ),
      TextWidgets.text500(
          title: title,
          fontSize: 14,
          textColor: AppColors.kYellowColor.withOpacity(0.5)),
    ],
  );
}

class ApprovisionnementEcobankPage extends StatefulWidget {
  final bool updatingData;
  final ApprovisionnementModel? approvisionnementModel;
  ApprovisionnementEcobankPage(
      {Key? key, required this.updatingData, this.approvisionnementModel})
      : super(key: key);

  @override
  State<ApprovisionnementEcobankPage> createState() =>
      _ApprovisionnementEcobankPageState();
}

List<String> deviseModeList = ["USD", "CDF"];
late String deviseMode = "USD";
List<String> alertLevelList = ["Urgence", "Rupture de Stock", "Prevention"];
late String alertLevelMode = "Prevention";
String? membreInterne;
String? nomFournisseur;
String? nomMembre;

class _ApprovisionnementEcobankPageState
    extends State<ApprovisionnementEcobankPage> {
  final TextEditingController _nomCtrller = TextEditingController();
  final TextEditingController _commentCtrller = TextEditingController();
  final TextEditingController _montantCtrller = TextEditingController();
  final TextEditingController _pswCtrller = TextEditingController();
  final TextEditingController _searchCtrller = TextEditingController();
  @override
  void initState() {
    super.initState();
    if (widget.updatingData == true) {
      _nomCtrller.text = widget.approvisionnementModel!.nom_Expediteur.trim();
      _commentCtrller.text =
          widget.approvisionnementModel!.commentaire.toString().trim();
      _montantCtrller.text =
          widget.approvisionnementModel!.montant.toString().trim();
      _pswCtrller.text =
          widget.approvisionnementModel!.password.toString().trim();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Material(
        color: AppColors.kTransparentColor,
        child: Container(

            // padding: const EdgeInsets.symmetric(horizontal: 10),
            width: Responsive.isMobile(context)
                ? MediaQuery.of(context).size.width
                : MediaQuery.of(context).size.width / 2,
            height: MediaQuery.of(context).size.height * .85,
            // color: AppColors.kBlackLightColor,
            child: Consumer<AppStateProvider>(
                builder: (context, appStateProvider, _) {
              return ModalProgress(
                //       isAsync: appStateProvider.isAsync,
                //       progressColor: AppColors.kYellowColor,
                //       child: SingleChildScrollView(
                //           controller: _controller,
                //           child: Responsive(
                //               mobile: Column(
                //                 children: [
                //                   Padding(
                //                     padding: const EdgeInsets.all(8.0),
                //                     child: Column(
                //                       crossAxisAlignment: CrossAxisAlignment.start,
                //                       children: [
                //                         EnvoieAirtelmoneyPage(
                //                           updatingData: false,
                //                         ),
                //                         EnvoieAirtelmoneysPage(
                //                           updatingData: false,
                //                         ),
                //                       ],
                //                     ),
                //                   ),
                //                 ],
                //               ),
                //               tablet: Column(
                //                 children: [
                //                   Padding(
                //                     padding: const EdgeInsets.all(8.0),
                //                     child: Column(
                //                       crossAxisAlignment: CrossAxisAlignment.start,
                //                       children: [
                //                         // Expanded(
                //                         //   child:
                //                         // procarousselImage(),
                //                         // //),
                //                         // //
                //                         // presentWidget(),
                //                         //),
                //                         EnvoieAirtelmoneyPage(
                //                           updatingData: false,
                //                         ),
                //                         EnvoieAirtelmoneysPage(
                //                           updatingData: false,
                //                         ),
                //                         //)
                //                       ],
                //                     ),
                //                   ),
                //                 ],
                //               ),
                //               web: Column(children: [
                //                 Padding(
                //                   padding: const EdgeInsets.all(8.0),
                //                   child: Column(
                //                     crossAxisAlignment: CrossAxisAlignment.start,
                //                     children: [
                //                       Row(
                //                         children: [
                //                           Expanded(
                //                             child: EnvoieAirtelmoneyPage(
                //                               updatingData: false,
                //                             ),
                //                           ),
                //                           Expanded(
                //                               child: EnvoieAirtelmoneysPage(
                //                             updatingData: false,
                //                           ))
                //                         ],
                //                       )
                //                     ],
                //                   ),
                //                 ),
                //               ]))));
                // },
                //   builder: (context, appStateProvider, child) {
                // return ModalProgress(
                isAsync: appStateProvider.isAsync,
                progressColor: AppColors.kYellowColor,
                child: ListView(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  children: [
                    CardWidget(
                        backColor: AppColors.kBlackLightColor,
                        title: 'Cash vers Cash',
                        content: Column(children: [
                          const AppLogo(size: Size(100, 100)),
                          CustomDropdownButton(
                              value: deviseMode,
                              hintText: "Type Devise",
                              callBack: (newValue) {
                                setState(() {
                                  deviseMode = newValue;
                                });
                              },
                              items: deviseModeList),
                          CustomDropdownButton(
                              value: alertLevelMode,
                              hintText: "Niveau Alert",
                              callBack: (newValue) {
                                setState(() {
                                  alertLevelMode = newValue;
                                });
                              },
                              items: alertLevelList),
                          blockSeparator(title: 'Coordonnees de l\'Expediteur'),
                          Row(children: [
                            // Expanded(
                            //   child: SearchableTextFormFieldWidget(
                            //     hintText: 'Vers membre interne',
                            //     textColor: AppColors.kWhiteColor,
                            //     backColor: AppColors.kTextFormWhiteColor,
                            //     editCtrller: _mbrCtrller,
                            //     maxLines: 1,
                            //     callback: (value) {
                            //       membreInterne = value.toString();
                            //       setState(() {});
                            //     },
                            //     data: Provider.of<UserStateProvider>(context)
                            //         .usersData,
                            //     displayColumn: "fname",
                            //     indexColumn: "telephone",
                            //     secondDisplayColumn: "lname",
                            //   ),
                            // ),
                            Expanded(
                              child: SearchableTextFormFieldWidget(
                                hintText: 'Numero Expediteur',
                                textColor: AppColors.kWhiteColor,
                                backColor: AppColors.kTextFormWhiteColor,
                                editCtrller: _nomCtrller,
                                maxLines: 1,
                                callback: (value) {
                                  nomMembre = value.toString();
                                  setState(() {});
                                },
                                //data: Provider.of<AppStateProvider>(context)
                                data: Provider.of<UserStateProvider>(context)
                                    // .membreInscrit,
                                    .usersData,
                                displayColumn: "telephone",
                                indexColumn: "fname",
                                secondDisplayColumn: "lname",
                              ),
                            )
                          ]),
                          // TextFormFieldWidget(
                          //     backColor: AppColors.kTextFormBackColor,
                          //     hintText: 'Vers membre interne',
                          //     editCtrller: _nomCtrller,
                          //     textColor: AppColors.kWhiteColor,
                          //     maxLines: 1),
                          // TextFormFieldWidget(
                          //     backColor: AppColors.kTextFormBackColor,
                          //     hintText: 'Numero Beneficiaire',
                          //     editCtrller: _nomCtrller,
                          //     textColor: AppColors.kWhiteColor,
                          //     maxLines: 1),
                          TextFormFieldWidget(
                              backColor: AppColors.kTextFormBackColor,
                              hintText: 'Commentaire',
                              editCtrller: _commentCtrller,
                              textColor: AppColors.kWhiteColor,
                              maxLines: 1),
                          TextFormFieldWidget(
                              backColor: AppColors.kTextFormBackColor,
                              hintText: 'Montant',
                              editCtrller: _montantCtrller,
                              textColor: AppColors.kWhiteColor,
                              maxLines: 1),
                          // TextFormFieldWidget(
                          //     backColor: AppColors.kTextFormBackColor,
                          //     hintText: 'Mot de pass',
                          //     editCtrller: _pswCtrller,
                          //     textColor: AppColors.kWhiteColor,
                          //     maxLines: 1),
                          Consumer<UserStateProvider>(
                            builder: (context, userStateProvider, _) {
                              return CustomButton(
                                  backColor: AppColors.kYellowColor,
                                  text: 'Recevoir',
                                  textColor: AppColors.kBlackColor,
                                  callback: () {
                                    // onPressed:
                                    // () {
                                    if (_nomCtrller.text.isEmpty ||
                                        _montantCtrller.text.isEmpty) {
                                      return
                                          //    Message.showToast(
                                          //       msg:
                                          //           'Veuillez remplir tous les champs');
                                          // }
                                          showDialog<void>(
                                        context: context,
                                        barrierDismissible:
                                            false, // user must tap button!
                                        builder: (BuildContext context) {
                                          return AlertDialog(
                                            title: const Text('Champs vide'),
                                            content: SingleChildScrollView(
                                              child: ListBody(
                                                children: const <Widget>[
                                                  Text(
                                                      'Le numero de telephone et le montant sont obligatoire'),
                                                  Text(
                                                      'Veillez completer tous les champs?'),
                                                ],
                                              ),
                                            ),
                                            actions: <Widget>[
                                              TextButton(
                                                child: const Text('Fermer'),
                                                onPressed: () {
                                                  Navigator.of(context).pop();
                                                },
                                              ),
                                            ],
                                          );
                                        },
                                      );
                                    }
                                    return showDialog(
                                        context: context,
                                        builder: (context) => AlertDialog(
                                              content: Container(
                                                  padding: EdgeInsets.all(5),
                                                  width: double.maxFinite,
                                                  height: 200,
                                                  child: Column(
                                                    children: [
                                                      TextFormFieldWidget(
                                                          backColor: AppColors
                                                              .kTextFormBackColor,
                                                          hintText: 'PIN',
                                                          editCtrller:
                                                              _pswCtrller,
                                                          textColor: AppColors
                                                              .kWhiteColor,
                                                          maxLines: 1)
                                                    ],
                                                  )),
                                              actions: [
                                                ElevatedButton(
                                                    onPressed: () {
                                                      Navigator.pop(context);
                                                    },
                                                    child: Text('Annuler')),
                                                ElevatedButton(
                                                    onPressed: () async {
                                                      if (_pswCtrller
                                                          .text.isEmpty) {
                                                        return
                                                            // Message.showToast(
                                                            //     msg:
                                                            //         'Veuillez entre un code PIN');
                                                            showDialog(
                                                                context:
                                                                    context,
                                                                builder: (BuildContext
                                                                        context) =>
                                                                    new AlertDialog(
                                                                      title: new Text(
                                                                          'Warning'),
                                                                      content:
                                                                          new Text(
                                                                              'Veuillez entre un code PIN'),
                                                                      actions: <
                                                                          Widget>[
                                                                        new IconButton(
                                                                            icon:
                                                                                new Icon(Icons.close),
                                                                            onPressed: () {
                                                                              Navigator.pop(context);
                                                                            })
                                                                      ],
                                                                    ));
                                                      }
                                                      if (_pswCtrller.text !=
                                                          "1234") {
                                                        return
                                                            //  Message.showToast(
                                                            //     msg:
                                                            //         'Code PIN incorrect');
                                                            showDialog(
                                                                context:
                                                                    context,
                                                                builder: (BuildContext
                                                                        context) =>
                                                                    new AlertDialog(
                                                                      title: new Text(
                                                                          'Warning'),
                                                                      content:
                                                                          new Text(
                                                                              'Code PIN incorrect'),
                                                                      actions: <
                                                                          Widget>[
                                                                        new IconButton(
                                                                            icon:
                                                                                new Icon(Icons.close),
                                                                            onPressed: () {
                                                                              Navigator.pop(context);
                                                                            })
                                                                      ],
                                                                    ));
                                                      }
                                                      userStateProvider
                                                          .approvCash(
                                                              montant: double.parse(
                                                                  _montantCtrller
                                                                      .text
                                                                      .trim()),
                                                              devise:
                                                                  deviseMode,
                                                              context: context,
                                                              callback: () {
                                                                Navigator.pop(
                                                                    context);
                                                              });
                                                    },
                                                    child: Text('Confirmer')),
                                              ],
                                            ));
                                  });

                              Map data = {
                                //"id": widget.updatingData == true
                                //? widget.pretModel.id!.toString() : "0",
                                'Nom_beneficiaire': _nomCtrller.text.trim(),
                                'commentaire': _commentCtrller.text.trim(),
                                'montant': _montantCtrller.text.trim(),
                                'password': _pswCtrller.text.trim(),
                                'users_id': Provider.of<UserStateProvider>(
                                        context,
                                        listen: false)
                                    .userId
                                    .toString(),
                              };
                              // userStateProvider.addBank(
                              //     context: context,
                              //     updatingData: widget.updatingData,
                              //     bank: BankModel.fromJson(data),
                              //     callback: () {
                              //       Navigator.pop(context);
                              //     });
                            },
                          )
                        ]))
                  ],
                ),
              );
            })));
    //     ),
    //   ),
    // );
  }
}

//import "package:dialog/~file~";

class ApprovisionnementEcobanksPage extends StatefulWidget {
  final bool updatingData;
  final ApprovisionnementModel? approvisionnementModel;
  ApprovisionnementEcobanksPage(
      {Key? key, required this.updatingData, this.approvisionnementModel})
      : super(key: key);

  @override
  State<ApprovisionnementEcobanksPage> createState() =>
      _ApprovisionnementEcobanksPageState();
}

class _ApprovisionnementEcobanksPageState
    extends State<ApprovisionnementEcobanksPage> {
  List<String> deviseModeList = ["USD", "CDF"];
  late String deviseMode = "USD";
  String? membreInterne;
  String? nomMembre;

  final TextEditingController _mbrCtrller = TextEditingController();
  final TextEditingController _nomCtrller = TextEditingController();
  final TextEditingController _commentCtrller = TextEditingController();
  final TextEditingController _montantCtrller = TextEditingController();
  final TextEditingController _pswCtrller = TextEditingController();
  final TextEditingController _searchCtrller = TextEditingController();
  final TextEditingController _typeAheadController = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.updatingData == true) {
      _nomCtrller.text = widget.approvisionnementModel!.nom_Expediteur.trim();
      _commentCtrller.text =
          widget.approvisionnementModel!.commentaire.toString().trim();
      _montantCtrller.text =
          widget.approvisionnementModel!.montant.toString().trim();
      _pswCtrller.text =
          widget.approvisionnementModel!.password.toString().trim();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Material(
        color: AppColors.kTransparentColor,
        child: Container(
            // padding: const EdgeInsets.symmetric(horizontal: 10),
            width: Responsive.isMobile(context)
                ? MediaQuery.of(context).size.width
                : MediaQuery.of(context).size.width / 2,
            height: MediaQuery.of(context).size.height * .85,

            // color: AppColors.kBlackLightColor,
            child: Consumer<AppStateProvider>(
                builder: (context, appStateProvider, child) {
              return ModalProgress(
                isAsync: appStateProvider.isAsync,
                progressColor: AppColors.kYellowColor,
                child: ListView(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  children: [
                    CardWidget(
                        backColor: AppColors.kBlackLightColor,
                        title: 'Virtuel vers Virtuel',
                        content: Column(children: [
                          const AppLogo(size: Size(100, 100)),
                          CustomDropdownButton(
                              value: deviseMode,
                              hintText: "Type Devise",
                              callBack: (newValue) {
                                setState(() {
                                  deviseMode = newValue;
                                });
                              },
                              items: deviseModeList),
                          CustomDropdownButton(
                              value: alertLevelMode,
                              hintText: "Niveau Alert",
                              callBack: (newValue) {
                                setState(() {
                                  alertLevelMode = newValue;
                                });
                              },
                              items: alertLevelList),
                          blockSeparator(title: 'Coordonnees de l\'Expediteur'),
                          Row(children: [
                            // Expanded(
                            //   child: SearchableTextFormFieldWidget(
                            //     hintText: 'Vers membre interne',
                            //     textColor: AppColors.kWhiteColor,
                            //     backColor: AppColors.kTextFormWhiteColor,
                            //     editCtrller: _mbrCtrller,
                            //     maxLines: 1,
                            //     callback: (value) {
                            //       membreInterne = value.toString();
                            //       setState(() {});
                            //     },
                            //     data: Provider.of<UserStateProvider>(context)
                            //         .usersData,
                            //     displayColumn: "fname",
                            //     indexColumn: "telephone",
                            //     secondDisplayColumn: "lname",
                            //   ),
                            // ),
                            Expanded(
                              child: SearchableTextFormFieldWidget(
                                hintText: 'Numero Expediteur',
                                textColor: AppColors.kWhiteColor,
                                backColor: AppColors.kTextFormWhiteColor,
                                editCtrller: _nomCtrller,
                                maxLines: 1,
                                callback: (value) {
                                  nomMembre = value.toString();
                                  setState(() {});
                                },
                                //data: Provider.of<AppStateProvider>(context)
                                data: Provider.of<UserStateProvider>(context)
                                    // .membreInscrit,
                                    .usersData,
                                displayColumn: "fname",
                                indexColumn: "telephone",
                                secondDisplayColumn: "lname",
                              ),
                            )
                          ]),
                          // TextFormFieldWidget(
                          //     backColor: AppColors.kTextFormBackColor,
                          //     hintText: 'Vers membre interne',
                          //     editCtrller: _nomCtrller,
                          //     textColor: AppColors.kWhiteColor,
                          //     maxLines: 1),
                          // TextFormFieldWidget(
                          //     backColor: AppColors.kTextFormBackColor,
                          //     hintText: 'Numero Beneficiaire',
                          //     editCtrller: _nomCtrller,
                          //     textColor: AppColors.kWhiteColor,
                          //     maxLines: 1),
                          TextFormFieldWidget(
                              backColor: AppColors.kTextFormBackColor,
                              hintText: 'Commentaire',
                              editCtrller: _commentCtrller,
                              textColor: AppColors.kWhiteColor,
                              maxLines: 1),
                          TextFormFieldWidget(
                              backColor: AppColors.kTextFormBackColor,
                              hintText: 'Montant',
                              editCtrller: _montantCtrller,
                              textColor: AppColors.kWhiteColor,
                              maxLines: 1),
                          // TextFormFieldWidget(
                          //     backColor: AppColors.kTextFormBackColor,
                          //     hintText: 'Mot de pass',
                          //     editCtrller: _pswCtrller,
                          //     textColor: AppColors.kWhiteColor,
                          //     maxLines: 1),
                          Consumer<UserStateProvider>(
                            builder: (context, userStateProvider, _) {
                              return CustomButton(
                                  backColor: AppColors.kYellowColor,
                                  text: 'Recevoir',
                                  textColor: AppColors.kBlackColor,
                                  callback: () {
                                    // onPressed:
                                    // () {
                                    if (_nomCtrller.text.isEmpty ||
                                        _montantCtrller.text.isEmpty) {
                                      return
                                          // Message.showToast(
                                          //     msg: 'Veuillez remplir tous les champs');
                                          showDialog<void>(
                                        context: context,
                                        barrierDismissible:
                                            false, // user must tap button!
                                        builder: (BuildContext context) {
                                          return AlertDialog(
                                            title: const Text('Champs vide'),
                                            content: SingleChildScrollView(
                                              child: ListBody(
                                                children: const <Widget>[
                                                  Text(
                                                      'Le numero de telephone et le montant sont obligatoire'),
                                                  Text(
                                                      'Veillez completer tous les champs?'),
                                                ],
                                              ),
                                            ),
                                            actions: <Widget>[
                                              TextButton(
                                                child: const Text('Fermer'),
                                                onPressed: () {
                                                  Navigator.of(context).pop();
                                                },
                                              ),
                                            ],
                                          );
                                        },
                                      );
                                    }
                                    return showDialog(
                                        context: context,
                                        builder: (context) => AlertDialog(
                                              content: Container(
                                                  padding: EdgeInsets.all(5),
                                                  width: double.maxFinite,
                                                  height: 200,
                                                  child: Column(
                                                    children: [
                                                      TextFormFieldWidget(
                                                          backColor: AppColors
                                                              .kTextFormBackColor,
                                                          hintText: 'PIN',
                                                          editCtrller:
                                                              _pswCtrller,
                                                          textColor: AppColors
                                                              .kWhiteColor,
                                                          maxLines: 1)
                                                    ],
                                                  )),
                                              actions: [
                                                ElevatedButton(
                                                    onPressed: () {
                                                      Navigator.pop(context);
                                                    },
                                                    child: Text('Annuler')),
                                                ElevatedButton(
                                                    onPressed: () async {
                                                      if (_pswCtrller
                                                          .text.isEmpty) {
                                                        return
                                                            // Message.showToast(
                                                            //     msg:
                                                            //         'Veuillez entre un code PIN');
                                                            showDialog(
                                                                context:
                                                                    context,
                                                                builder: (BuildContext
                                                                        context) =>
                                                                    new AlertDialog(
                                                                      title: new Text(
                                                                          'Attention'),
                                                                      content:
                                                                          new Text(
                                                                              'Veuillez entre un code PIN'),
                                                                      actions: <
                                                                          Widget>[
                                                                        new IconButton(
                                                                            icon:
                                                                                new Icon(Icons.close),
                                                                            onPressed: () {
                                                                              Navigator.pop(context);
                                                                            })
                                                                      ],
                                                                    ));
                                                      }
                                                      if (_pswCtrller.text !=
                                                          "1234") {
                                                        return await
                                                            // Message.showToast(
                                                            //     msg:
                                                            //         'Code PIN incorrect');
                                                            showDialog(
                                                                context:
                                                                    context,
                                                                builder: (BuildContext
                                                                        context) =>
                                                                    new AlertDialog(
                                                                      title: new Text(
                                                                          'Warning'),
                                                                      content:
                                                                          new Text(
                                                                              'Code PIN incorrect'),
                                                                      actions: <
                                                                          Widget>[
                                                                        new IconButton(
                                                                            icon:
                                                                                new Icon(Icons.close),
                                                                            onPressed: () {
                                                                              Navigator.pop(context);
                                                                            })
                                                                      ],
                                                                    ));
                                                      }
                                                      userStateProvider
                                                          .approvVirtuel(
                                                              montant: double.parse(
                                                                  _montantCtrller
                                                                      .text
                                                                      .trim()),
                                                              devise:
                                                                  deviseMode,
                                                              context: context,
                                                              callback: () {
                                                                Navigator.pop(
                                                                    context);
                                                              });
                                                    },
                                                    child: Text('Confirmer')),
                                              ],
                                            ));
                                  });

                              Map data = {
                                //"id": widget.updatingData == true
                                //? widget.pretModel.id!.toString() : "0",
                                'Nom_beneficiaire': _nomCtrller.text.trim(),
                                'commentaire': _commentCtrller.text.trim(),
                                'montant': _montantCtrller.text.trim(),
                                'password': _pswCtrller.text.trim(),
                                'users_id': Provider.of<UserStateProvider>(
                                        context,
                                        listen: false)
                                    .userId
                                    .toString(),
                              };
                              // userStateProvider.addBank(
                              //     context: context,
                              //     updatingData: widget.updatingData,
                              //     bank: BankModel.fromJson(data),
                              //     callback: () {
                              //       Navigator.pop(context);
                              //      });
                            },
                          )
                        ]))
                  ],
                ),
              );
            })));
    //     ),
    //   ),
    // );
  }
}
