import 'package:orion/Resources/AppStateProvider/app_stateprovider.dart';
import 'package:orion/Resources/AppStateProvider/user_stateprovider.dart';
import 'package:orion/Resources/Components/button.dart';
import 'package:orion/Resources/Components/card.dart';

import 'package:orion/Resources/Components/modal_progress.dart';
import 'package:orion/Resources/Components/radio_button.dart';
import 'package:orion/Resources/Components/text_fields.dart';
import 'package:orion/Resources/Components/texts.dart';
import 'package:orion/Resources/Components/dropdown_button.dart';
import 'package:orion/Resources/global_variables.dart';
import 'package:orion/Resources/Components/Guichet/applogo_airtel.dart';
import 'package:orion/Resources/Models/Guichet_Model/envoyer_argent_model.dart';
import 'package:orion/Resources/Components/searchable_textfield.dart';
import 'package:orion/Resources/responsive.dart';
import 'package:flutter/cupertino.dart';
import 'package:orion/Resources/Components/Guichet/button_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:io';

//import "package:dialog/~file~";
blockSeparator({required String title}) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(),
      const SizedBox(
        height: 20,
      ),
      TextWidgets.text500(
          title: title, fontSize: 14, textColor: AppColors.kBlackColor),
    ],
  );
}

class EnvoieAirtelmoneysPage extends StatefulWidget {
  final bool updatingData;
  final EnvoieModel? envoieModel;
  EnvoieAirtelmoneysPage(
      {Key? key, required this.updatingData, this.envoieModel})
      : super(key: key);

  @override
  State<EnvoieAirtelmoneysPage> createState() => _EnvoieAirtelmoneysPageState();
}

class _EnvoieAirtelmoneysPageState extends State<EnvoieAirtelmoneysPage> {
  List<String> deviseModeList = ["USD", "CDF"];
  late String deviseMode = "USD";
  List<String> alertLevelList = ["Urgence", "Rupture de Stock", "Prevention"];
  late String alertLevelMode = "Prevention";

  List<String> typetransactionModeList = ["Cash", "Virtuel"];
  late String typetransactionMode = "Virtuel";

  List<String> alertList = ["Success", "Pending", "Denied"];
  late String alertMode = "Success";
  String? membreInterne;
  String? nomFournisseur;
  String? nomMembre;

  final TextEditingController _mbrCtrller = TextEditingController();
  final TextEditingController _nomCtrller = TextEditingController();
  final TextEditingController _commentCtrller = TextEditingController();
  final TextEditingController _montantCtrller = TextEditingController();
  final TextEditingController _pswCtrller = TextEditingController();
  final TextEditingController _searchCtrller = TextEditingController();
  final TextEditingController _typeAheadController = TextEditingController();
  final FocusNode node1 = FocusNode();

  @override
  void initState() {
    super.initState();
    if (widget.updatingData == true) {
      _nomCtrller.text = widget.envoieModel!.Nom_beneficiaire.trim();
      _commentCtrller.text = widget.envoieModel!.commentaire.toString().trim();
      _montantCtrller.text = widget.envoieModel!.montant.toString().trim();
      _pswCtrller.text = widget.envoieModel!.password.toString().trim();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Material(
        color: AppColors.kTransparentColor,
        child: Container(
            // padding: const EdgeInsets.symmetric(horizontal: 10),
            width: Responsive.isMobile(context)
                ? MediaQuery.of(context).size.width
                : MediaQuery.of(context).size.width / 2,
            height: MediaQuery.of(context).size.height * .85,

            // color: AppColors.kBlackLightColor,
            child: Consumer<AppStateProvider>(
                builder: (context, appStateProvider, child) {
              return ModalProgress(
                isAsync: appStateProvider.isAsync,
                progressColor: AppColors.kYellowColor,
                child: ListView(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  children: [
                    CardWidget(
                        backColor: AppColors.kBlackLightColor,
                        title: 'RETRAIT',
                        content: Column(children: [
                          const AppLogo(size: Size(100, 100)),
                          Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                // blockSeparator(title: 'Type Approvisionnement'),
                                Card(
                                    child: Column(
                                  children: [
                                    blockSeparator(title: 'Type Transaction'),
                                    Wrap(
                                        direction: Axis.horizontal,
                                        children: List.generate(
                                            typetransactionModeList.length,
                                            (index) => CustomRadioButton(
                                                textColor:
                                                    AppColors.kBlackColor,
                                                value: typetransactionMode ==
                                                        typetransactionModeList[
                                                                index]
                                                            .toString()
                                                    ? true
                                                    : false,
                                                label: typetransactionModeList[
                                                        index]
                                                    .toString(),
                                                callBack: () {
                                                  typetransactionMode =
                                                      typetransactionModeList[
                                                          index];
                                                  setState(() {});
                                                }))),
                                  ],
                                )),
                                // blockSeparator(title: 'Type Devise'),
                                Card(
                                  child: Column(
                                    children: [
                                      blockSeparator(title: 'Type Devise'),
                                      Wrap(
                                          direction: Axis.horizontal,
                                          children: List.generate(
                                              deviseModeList.length,
                                              (index) => CustomRadioButton(
                                                  textColor:
                                                      AppColors.kBlackColor,
                                                  value: deviseMode ==
                                                          deviseModeList[index]
                                                              .toString()
                                                      ? true
                                                      : false,
                                                  label: deviseModeList[index]
                                                      .toString(),
                                                  callBack: () {
                                                    deviseMode =
                                                        deviseModeList[index];
                                                    setState(() {});
                                                  }))),
                                    ],
                                  ),
                                ),
                                //blockSeparator(title: 'Niveau Alert'),
                                // Card(
                                //   child: Column(
                                //     children: [
                                //       blockSeparator(title: 'Niveau Alert'),
                                //       Wrap(
                                //           direction: Axis.horizontal,
                                //           children: List.generate(
                                //               alertLevelList.length,
                                //               (index) => CustomRadioButton(
                                //                   textColor: AppColors.kBlackColor,
                                //                   value: alertLevelMode ==
                                //                           alertLevelList[index]
                                //                               .toString()
                                //                       ? true
                                //                       : false,
                                //                   label: alertLevelList[index]
                                //                       .toString(),
                                //                   callBack: () {
                                //                     alertLevelMode =
                                //                         alertLevelList[index];
                                //                     setState(() {});
                                //                   }))),
                                //     ],
                                //   ),
                                // ),
                              ]),
                          blockSeparator(title: 'Coordonnees du Fournisseur'),
                          Row(children: [
                            Expanded(
                              child: SearchableTextFormFieldWidget(
                                hintText: 'Numero Beneficiaire',
                                textColor: AppColors.kYellowColor,
                                backColor: AppColors.kTextFormWhiteColor,

                                editCtrller: _nomCtrller,
                                maxLines: 1,
                                callback: (value) {
                                  nomMembre = value.toString();
                                  setState(() {});
                                },
                                //data: Provider.of<AppStateProvider>(context)
                                data: Provider.of<UserStateProvider>(context)
                                    // .membreInscrit,
                                    .usersData,
                                displayColumn: "telephone",
                                indexColumn: "fname",
                                secondDisplayColumn: "lname",
                              ),
                            )
                          ]),
                          TextFormFieldWidget(
                              backColor: AppColors.kTextFormBackColor,
                              hintText: 'Ref (Commentaire)',
                              editCtrller: _commentCtrller,
                              textColor: AppColors.kWhiteColor,
                              maxLines: 1),
                          TextFormFieldWidget(
                              backColor: AppColors.kTextFormBackColor,
                              hintText: 'Montant',
                              editCtrller: _montantCtrller,
                              textColor: AppColors.kWhiteColor,
                              maxLines: 1),
                          Consumer<UserStateProvider>(
                            builder: (context, userStateProvider, _) {
                              return CustomButton(
                                  backColor: AppColors.kYellowColor,
                                  text: 'Valider',
                                  textColor: AppColors.kBlackColor,
                                  onClicked: () => FocusScope.of(context)
                                      .requestFocus(node1),
                                  callback: () {
                                    // onPressed:
                                    // () {
                                    if (_nomCtrller.text.isEmpty ||
                                        _montantCtrller.text.isEmpty) {
                                      return
                                          // Message.showToast(
                                          //     msg: 'Veuillez remplir tous les champs');
                                          showDialog<void>(
                                        context: context,
                                        barrierDismissible:
                                            false, // user must tap button!
                                        builder: (BuildContext context) {
                                          return AlertDialog(
                                            title: const Text('Champs vide'),
                                            content: SingleChildScrollView(
                                              child: ListBody(
                                                children: const <Widget>[
                                                  Text(
                                                      'Le numero de telephone et le montant sont obligatoire'),
                                                  Text(
                                                      'Veillez remplir tous les champs?'),
                                                ],
                                              ),
                                            ),
                                            actions: <Widget>[
                                              TextButton(
                                                child: const Text('Fermer'),
                                                onPressed: () {
                                                  Navigator.of(context).pop();
                                                },
                                              ),
                                            ],
                                          );
                                        },
                                      );
                                    }
                                    return showDialog(
                                        context: context,
                                        builder: (context) => AlertDialog(
                                              content: Container(
                                                  padding: EdgeInsets.all(5),
                                                  width: double.minPositive,
                                                  height: 100,
                                                  child: Column(
                                                    children: [
                                                      TextFormFieldWidget(
                                                          focusNode: node1,
                                                          backColor: AppColors
                                                              .kTextFormBackColor,
                                                          hintText: 'PIN',
                                                          editCtrller:
                                                              _pswCtrller,
                                                          textColor: AppColors
                                                              .kBlackColor,
                                                          //
                                                          maxLines: 1)
                                                    ],
                                                  )),
                                              actions: [
                                                ElevatedButton(
                                                    onPressed: () {
                                                      Navigator.pop(context);
                                                    },
                                                    child: Text('Annuler')),
                                                ElevatedButton(
                                                    onPressed: () async {
                                                      if (_pswCtrller
                                                          .text.isEmpty) {
                                                        return
                                                            // Message.showToast(
                                                            //     msg:
                                                            //         'Veuillez entre un code PIN');
                                                            showDialog(
                                                                context:
                                                                    context,
                                                                builder: (BuildContext
                                                                        context) =>
                                                                    new AlertDialog(
                                                                      title: new Text(
                                                                          'Attention'),
                                                                      content:
                                                                          new Text(
                                                                              'Veuillez entre un code PIN'),
                                                                      actions: <
                                                                          Widget>[
                                                                        new IconButton(
                                                                            icon:
                                                                                new Icon(Icons.close),
                                                                            onPressed: () {
                                                                              Navigator.pop(context);
                                                                            })
                                                                      ],
                                                                    ));
                                                      }
                                                      if (_pswCtrller.text !=
                                                          "1234") {
                                                        return await
                                                            // Message.showToast(
                                                            //     msg:
                                                            //         'Code PIN incorrect');
                                                            showDialog(
                                                                context:
                                                                    context,
                                                                builder: (BuildContext
                                                                        context) =>
                                                                    new AlertDialog(
                                                                      title: new Text(
                                                                          'Warning'),
                                                                      content:
                                                                          new Text(
                                                                              'Code PIN incorrect'),
                                                                      actions: <
                                                                          Widget>[
                                                                        new IconButton(
                                                                            icon:
                                                                                new Icon(Icons.close),
                                                                            onPressed: () {
                                                                              Navigator.pop(context);
                                                                            })
                                                                      ],
                                                                    ));
                                                      }
                                                      userStateProvider
                                                          .envoiVirtuelcheck(
                                                              montant: double.parse(
                                                                  _montantCtrller
                                                                      .text
                                                                      .trim()),
                                                              devise:
                                                                  deviseMode,
                                                              typedevise:
                                                                  typetransactionMode,
                                                              context: context,
                                                              callback: () {
                                                                Navigator.pop(
                                                                    context);
                                                              });
                                                    },
                                                    child: Text('Confirmer')),
                                                // ButtonWidget(
                                                //   backColor:
                                                //       AppColors.kBlackColor,
                                                //   textColor:
                                                //       AppColors.kWhiteColor,
                                                //   text: 'Focaliser',
                                                //   onClicked: () =>
                                                //       FocusScope.of(context)
                                                //           .requestFocus(node1),
                                                //   callback: () {},
                                                // )
                                              ],
                                            ));
                                  });

                              Map data = {
                                //"id": widget.updatingData == true
                                //? widget.pretModel.id!.toString() : "0",
                                'Nom_beneficiaire': _nomCtrller.text.trim(),
                                'commentaire': _commentCtrller.text.trim(),
                                'montant': _montantCtrller.text.trim(),
                                'password': _pswCtrller.text.trim(),
                                'users_id': Provider.of<UserStateProvider>(
                                        context,
                                        listen: false)
                                    .userId
                                    .toString(),
                              };
                              // userStateProvider.addBank(
                              //     context: context,
                              //     updatingData: widget.updatingData,
                              //     bank: BankModel.fromJson(data),
                              //     callback: () {
                              //       Navigator.pop(context);
                              //      });
                            },
                          )
                        ]))
                  ],
                ),
              );
            })));
    //     ),
    //   ),
    // );
  }
}

class EnvoieAirtelmoneyPage extends StatefulWidget {
  final bool updatingData;
  final EnvoieModel? envoieModel;
  EnvoieAirtelmoneyPage(
      {Key? key, required this.updatingData, this.envoieModel})
      : super(key: key);

  @override
  State<EnvoieAirtelmoneyPage> createState() => _EnvoieAirtelmoneyPageState();
}

class _EnvoieAirtelmoneyPageState extends State<EnvoieAirtelmoneyPage> {
  List<String> deviseModeList = ["USD", "CDF"];
  late String deviseMode = "USD";
  List<String> alertLevelList = ["Urgence", "Rupture de Stock", "Prevention"];
  late String alertLevelMode = "Prevention";

  List<String> typetransactionModeList = ["Cash", "Virtuel"];
  late String typetransactionMode = "Virtuel";

  List<String> alertList = ["Success", "Pending", "Denied"];
  late String alertMode = "Success";
  String? membreInterne;
  String? nomFournisseur;
  String? nomMembre;
  final ScrollController _controller = ScrollController();
  final TextEditingController _mbrCtrller = TextEditingController();
  final TextEditingController _nomCtrller = TextEditingController();
  final TextEditingController _commentCtrller = TextEditingController();
  final TextEditingController _montantCtrller = TextEditingController();
  final TextEditingController _pswCtrller = TextEditingController();
  final TextEditingController _searchCtrller = TextEditingController();
  final TextEditingController _typeAheadController = TextEditingController();
  final FocusNode node1 = FocusNode();

  @override
  void initState() {
    super.initState();
    if (widget.updatingData == true) {
      _nomCtrller.text = widget.envoieModel!.Nom_beneficiaire.trim();
      _commentCtrller.text = widget.envoieModel!.commentaire.toString().trim();
      _montantCtrller.text = widget.envoieModel!.montant.toString().trim();
      _pswCtrller.text = widget.envoieModel!.password.toString().trim();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Material(
        color: AppColors.kTransparentColor,
        child: Container(

            // padding: const EdgeInsets.symmetric(horizontal: 10),
            width: Responsive.isMobile(context)
                ? MediaQuery.of(context).size.width
                : MediaQuery.of(context).size.width / 2,
            height: MediaQuery.of(context).size.height * .85,
            // color: AppColors.kBlackLightColor,
            child: Consumer<AppStateProvider>(
                builder: (context, appStateProvider, _) {
              return ModalProgress(
                isAsync: appStateProvider.isAsync,
                progressColor: AppColors.kYellowColor,
                child: ListView(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  children: [
                    CardWidget(
                        backColor: AppColors.kBlackLightColor,
                        title: 'DEPOT',
                        content: Column(children: [
                          const AppLogo(size: Size(100, 100)),
                          Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                // blockSeparator(title: 'Type Approvisionnement'),
                                Card(
                                    child: Column(
                                  children: [
                                    blockSeparator(title: 'Type Transaction'),
                                    Center(
                                      child: Wrap(
                                          direction: Axis.horizontal,
                                          children: List.generate(
                                              typetransactionModeList.length,
                                              (index) => CustomRadioButton(
                                                  textColor:
                                                      AppColors.kBlackColor,
                                                  value: typetransactionMode ==
                                                          typetransactionModeList[
                                                                  index]
                                                              .toString()
                                                      ? true
                                                      : false,
                                                  label:
                                                      typetransactionModeList[
                                                              index]
                                                          .toString(),
                                                  callBack: () {
                                                    typetransactionMode =
                                                        typetransactionModeList[
                                                            index];
                                                    setState(() {});
                                                  }))),
                                    ),
                                  ],
                                )),
                                // blockSeparator(title: 'Type Devise'),
                                Card(
                                  child: Column(
                                    children: [
                                      blockSeparator(title: 'Type Devise'),
                                      Center(
                                        child: Wrap(
                                            direction: Axis.horizontal,
                                            children: List.generate(
                                                deviseModeList.length,
                                                (index) => CustomRadioButton(
                                                    textColor:
                                                        AppColors.kBlackColor,
                                                    value: deviseMode ==
                                                            deviseModeList[
                                                                    index]
                                                                .toString()
                                                        ? true
                                                        : false,
                                                    label: deviseModeList[index]
                                                        .toString(),
                                                    callBack: () {
                                                      deviseMode =
                                                          deviseModeList[index]
                                                              .toString();
                                                      setState(() {});
                                                    }))),
                                      )
                                    ],
                                  ),
                                ),
                                //blockSeparator(title: 'Niveau Alert'),
                                // Card(
                                //   child: Column(
                                //     children: [
                                //       blockSeparator(title: 'Niveau Alert'),
                                //       Wrap(
                                //           direction: Axis.horizontal,
                                //           children: List.generate(
                                //               alertLevelList.length,
                                //               (index) => CustomRadioButton(
                                //                   textColor: AppColors.kBlackColor,
                                //                   value: alertLevelMode ==
                                //                           alertLevelList[index]
                                //                               .toString()
                                //                       ? true
                                //                       : false,
                                //                   label: alertLevelList[index]
                                //                       .toString(),
                                //                   callBack: () {
                                //                     alertLevelMode =
                                //                         alertLevelList[index];
                                //                     setState(() {});
                                //                   }))),
                                //     ],
                                //   ),
                                // ),
                              ]),
                          blockSeparator(title: 'Coordonnees du Fournisseur'),
                          Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Expanded(
                                  child: SearchableTextFormFieldWidget(
                                    hintText: 'Numero Beneficiaire',
                                    textColor: AppColors.kWhiteColor,
                                    backColor: AppColors.kTextFormWhiteColor,
                                    editCtrller: _nomCtrller,
                                    maxLines: 1,
                                    callback: (value) {
                                      nomMembre = value.toString();
                                      setState(() {});
                                    },
                                    //data: Provider.of<AppStateProvider>(context)
                                    data:
                                        Provider.of<UserStateProvider>(context)
                                            // .membreInscrit,
                                            .usersData,
                                    displayColumn: "telephone",
                                    indexColumn: "fname",
                                    secondDisplayColumn: "lname",
                                  ),
                                )
                              ]),
                          TextFormFieldWidget(
                              backColor: AppColors.kTextFormBackColor,
                              hintText: 'Ref (Commentaire)',
                              editCtrller: _commentCtrller,
                              textColor: AppColors.kWhiteColor,
                              maxLines: 1),
                          TextFormFieldWidget(
                              backColor: AppColors.kTextFormBackColor,
                              hintText: 'Montant',
                              editCtrller: _montantCtrller,
                              textColor: AppColors.kWhiteColor,
                              maxLines: 1),
                          Consumer<UserStateProvider>(
                            builder: (context, userStateProvider, _) {
                              return CustomButton(
                                  backColor: AppColors.kYellowColor,
                                  text: 'Valider',
                                  textColor: AppColors.kBlackColor,

                                  // onClicked: () => FocusScope.of(context)
                                  //     .requestFocus(node1),
                                  callback: () {
                                    // onPressed:
                                    // () {
                                    if (_nomCtrller.text.isEmpty ||
                                        _montantCtrller.text.isEmpty) {
                                      //    Message.showToast(
                                      //       msg:
                                      //           'Veuillez remplir tous les champs');
                                      // }
                                      return showDialog<void>(
                                        context: context,
                                        barrierDismissible:
                                            false, // user must tap button!
                                        builder: (BuildContext context) {
                                          return AlertDialog(
                                            title: const Text('Champs vide'),
                                            content: SingleChildScrollView(
                                              child: ListBody(
                                                children: const <Widget>[
                                                  Text(
                                                      'Le numero de telephone et le montant sont obligatoire'),
                                                  Text(
                                                      'Veillez remplir tous les champs?'),
                                                ],
                                              ),
                                            ),
                                            actions: <Widget>[
                                              TextButton(
                                                child: const Text('Fermer'),
                                                onPressed: () {
                                                  Navigator.of(context).pop();
                                                },
                                              ),
                                            ],
                                          );
                                        },
                                      );
                                    }
                                    // {
                                    // if (_nomCtrller.text.isNotEmpty ||
                                    //     _montantCtrller.text.isNotEmpty) {
                                    //   FocusScope.of(context)
                                    //       .requestFocus(node1);
                                    // }
                                    // }

                                    return showDialog(
                                        context: context,
                                        builder: (context) => AlertDialog(
                                              content: Container(
                                                  padding: EdgeInsets.all(5),
                                                  width: double.minPositive,
                                                  height: 100,
                                                  child: Column(
                                                    children: [
                                                      TextFormFieldWidget(
                                                          focusNode: node1,
                                                          backColor: AppColors
                                                              .kTextFormBackColor,
                                                          hintText: 'PIN',
                                                          editCtrller:
                                                              _pswCtrller,
                                                          textColor: AppColors
                                                              .kBlackColor,
                                                          maxLines: 1)
                                                    ],
                                                  )),
                                              actions: [
                                                ElevatedButton(
                                                    onPressed: () {
                                                      Navigator.pop(context);
                                                    },
                                                    child: Text('Annuler')),
                                                ElevatedButton(
                                                    onPressed: () async {
                                                      if (_pswCtrller
                                                          .text.isEmpty) {
                                                        return
                                                            // Message.showToast(
                                                            //     msg:
                                                            //         'Veuillez entre un code PIN');
                                                            showDialog(
                                                                context:
                                                                    context,
                                                                builder: (BuildContext
                                                                        context) =>
                                                                    new AlertDialog(
                                                                      title: new Text(
                                                                          'Attention'),
                                                                      content:
                                                                          new Text(
                                                                              'Veuillez entre un code PIN'),
                                                                      actions: <
                                                                          Widget>[
                                                                        new IconButton(
                                                                            icon:
                                                                                new Icon(Icons.close),
                                                                            onPressed: () {
                                                                              Navigator.pop(context);
                                                                            })
                                                                      ],
                                                                    ));
                                                      }
                                                      if (_pswCtrller.text !=
                                                          "1234") {
                                                        return await
                                                            // Message.showToast(
                                                            //     msg:
                                                            //         'Code PIN incorrect');
                                                            showDialog(
                                                                context:
                                                                    context,
                                                                builder: (BuildContext
                                                                        context) =>
                                                                    new AlertDialog(
                                                                      title: new Text(
                                                                          'Warning'),
                                                                      content:
                                                                          new Text(
                                                                              'Code PIN incorrect'),
                                                                      actions: <
                                                                          Widget>[
                                                                        new IconButton(
                                                                            icon:
                                                                                new Icon(Icons.close),
                                                                            onPressed: () {
                                                                              Navigator.pop(context);
                                                                            })
                                                                      ],
                                                                    ));
                                                      }
                                                      userStateProvider
                                                          .envoICashCheck(
                                                              montant: double.parse(
                                                                  _montantCtrller
                                                                      .text
                                                                      .trim()),
                                                              devise:
                                                                  deviseMode,
                                                              typedevise:
                                                                  typetransactionMode,
                                                              context: context,
                                                              callback: () {
                                                                Navigator.pop(
                                                                    context);
                                                              });
                                                    },
                                                    child: Text('Confirmer')),
                                              ],
                                            ));
                                  });

                              Map data = {
                                //"id": widget.updatingData == true
                                //? widget.pretModel.id!.toString() : "0",
                                'Nom_beneficiaire': _nomCtrller.text.trim(),
                                'commentaire': _commentCtrller.text.trim(),
                                'montant': _montantCtrller.text.trim(),
                                'password': _pswCtrller.text.trim(),
                                'users_id': Provider.of<UserStateProvider>(
                                        context,
                                        listen: false)
                                    .userId
                                    .toString(),
                              };
                              // userStateProvider.addBank(
                              //     context: context,
                              //     updatingData: widget.updatingData,
                              //     bank: BankModel.fromJson(data),
                              //     callback: () {
                              //       Navigator.pop(context);
                              //     });
                            },
                          )
                        ]))
                  ],
                ),
              );
            })));
    //     ),
    //   ),
    // );
  }
}

//import "package:dialog/~file~";
