import 'package:orion/Resources/AppStateProvider/app_stateprovider.dart';
import 'package:orion/Resources/AppStateProvider/user_stateprovider.dart';
import 'package:orion/Resources/Components/modal_progress.dart';
import 'package:orion/Resources/Components/texts.dart';
import 'package:orion/Resources/global_variables.dart';
import 'package:orion/Resources/responsive.dart';

import 'package:orion/Views/Guichet/Menu%20Mobile%20Money/Orange%20Money/emprunt_orange_money.dart';
import 'package:orion/Views/Guichet/Menu%20Mobile%20Money/Orange%20Money/pret_orange_money.dart';
import 'package:orion/Views/Guichet/Menu%20Mobile%20Money/Orange%20Money/receive_orange.dart';
import 'package:orion/Views/Guichet/Menu%20Mobile%20Money/Orange%20Money/send_orange_money.dart';
import 'package:orion/Views/Guichet/Menu%20Mobile%20Money/Orange%20Money/sorti_orange_money.dart';

import 'package:orion/Views/Guichet/Historique/historique_transaction.dart';
import 'package:file_picker/file_picker.dart';
import 'package:orion/Resources/Components/applogo.dart';
import 'package:carousel_pro/carousel_pro.dart';
import 'package:carousel_images/carousel_images.dart';
import 'package:orion/Views/Home/menu.dart';
import 'package:orion/Resources/AppStateProvider/menu_state_provider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

class GestionOrangePage extends StatefulWidget {
  const GestionOrangePage({Key? key}) : super(key: key);

  @override
  _GestionOrangePageState createState() => _GestionOrangePageState();
}

class _GestionOrangePageState extends State<GestionOrangePage> {
  final ScrollController _controller = ScrollController();
  List<PlatformFile> _pickedFiles = [];
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((timeStamp) {
      // Provider.of<UserStateProvider>(context, listen: false)
      //     .initUserData(context: context, isRefreshed: false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<MenuStateProvider>(
        builder: (context, menuStateProvider, child) {
      return Scaffold(
        appBar: AppBar(
          title: Row(children: [
            const AppLogo(size: Size(100, 100)),
            Text(menuStateProvider.currentMenu == null ||
                    menuStateProvider.currentMenu == 'Accueil'
                ? 'Orion'
                : menuStateProvider.currentMenu),
            if (Responsive.isWeb(context))
              Expanded(
                child: Consumer<MenuStateProvider>(
                    builder: (context, menuStateProvider, child) {
                  return Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children:
                        List.generate(menuStateProvider.menu.length, (index) {
                      return MenuItem(
                          title: menuStateProvider.menu[index].title,
                          icon: menuStateProvider.menu[index].icon,
                          textColor: AppColors.kWhiteColor,
                          hoverColor: AppColors.kYellowColor,
                          backColor: Colors.transparent);
                    }),
                  );
                }),
              ),
          ]),
        ),
        body: SafeArea(child: Consumer<AppStateProvider>(
          builder: (context, appStateProvider, _) {
            return ModalProgress(
                isAsync: appStateProvider.isAsync,
                progressColor: AppColors.kYellowColor,
                child: SingleChildScrollView(
                    controller: _controller,
                    child: Responsive(
                        mobile: Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // procarousselImage(),
                                  // presentWidget(),
                                  // Expanded(
                                  //   child:
                                  // ),
                                  // Expanded(child:
                                  userCard(),
                                  scoreCard(),
                                  stepsList()
                                ],
                              ),
                            ),
                          ],
                        ),
                        tablet: Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // Expanded(
                                  //   child:
                                  // procarousselImage(),
                                  // //),
                                  // //
                                  // presentWidget(),
                                  //),
                                  userCard(),
                                  // Expanded(
                                  //   child:
                                  scoreCard(),
                                  //)
                                ],
                              ),
                            ),
                            stepsList(),
                            // Text('tablet'),
                          ],
                        ),
                        web: Column(children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // procarousselImage(),
                                // presentWidget(),
                                // Expanded(
                                //   child:
                                // ),
                                // Expanded(child:
                                userCard(),
                                scoreCard(),
                                stepsList(),
                              ],
                            ),
                          ),
                        ]))));
          },
        )),
      );
    });
  }

  // @override
  // Widget build(BuildContext context) {
  //   return Scaffold(
  //     body: SafeArea(
  //         child: SingleChildScrollView(
  //             controller: _controller,
  //             child: Responsive(
  //                 mobile: Column(
  //                   children: [
  //                     presentWidget(),
  //                     listWidget(),
  //                   ],
  //                 ),
  //                 tablet: Row(
  //                   mainAxisAlignment: MainAxisAlignment.start,
  //                   crossAxisAlignment: CrossAxisAlignment.start,
  //                   children: [
  //                     Expanded(
  //                       flex: 2,
  //                       child: presentWidget(),
  //                     ),
  //                     Expanded(
  //                       child: listWidget(),
  //                     )
  //                   ],
  //                 ),
  //                 web: Column(
  //                   mainAxisAlignment: MainAxisAlignment.start,
  //                   crossAxisAlignment: CrossAxisAlignment.start,
  //                   children: [
  //                     presentWidget(),
  //                     Row(
  //                       children: [
  //                         listWidget(),
  //                       ],
  //                     )
  //                   ],
  //                 )))),
  //   );
  // }
  // final List<String> listImages = [
  //   'Assets/Images/Orion/hopital.jpg',
  //   //'https://www.factroom.ru/wp-content/uploads/2019/04/5-osobennostej-klimata-pitera-o-kotoryh-vy-dolzhny-znat-esli-sobiraetes-syuda-priekhat.jpg',
  //   //'https://cdn.flixbus.de/2018-01/munich-header-d8_0.jpg',
  //   'Assets/Images/Orion/mpesa.png',
  //   'Assets/Images/Orion/airtelm.png',
  //   'Assets/Images/Orion/canal.png',
  //   'Assets/Images/Orion/congo.jpg',
  //   'Assets/Images/Orion/dhl.png',
  //   'Assets/Images/Orion/sbt.png',
  //   'Assets/Images/Orion/ecobank.png',
  //   'Assets/Images/Orion/tmb.png',
  //   'Assets/Images/Orion/smico.png',
  //   'Assets/Images/Orion/equit.png',
  //   'Assets/Images/Orion/fina.png',
  //   'Assets/Images/Orion/western.png',
  //   'Assets/Images/Orion/orangem.png',
  //   'Assets/Images/Orion/mpesa.png',
  //   'Assets/Images/Orion/airtelm.png',
  // ];

  // carousselImage() {
  //   return CarouselImages(
  //     scaleFactor: 0.7,
  //     listImages: listImages,
  //     height: 300.0,
  //     borderRadius: 30.0,
  //     cachedNetworkImage: true,
  //     verticalAlignment: Alignment.bottomCenter,
  //     onTap: (index) {
  //       print('Tapped on page $index');
  //     },
  //   );
  // }
  procarousselImage() {
    return Container(
      height: 300,
      child: Carousel(
        boxFit: BoxFit.cover,
        autoplay: true,
        animationCurve: Curves.fastOutSlowIn,
        animationDuration: Duration(milliseconds: 1000),
        dotSize: 6.0,
        dotIncreasedColor: Color(0xFFFF335C),
        dotBgColor: Colors.transparent,
        dotPosition: DotPosition.topRight,
        dotVerticalPadding: 10.0,
        showIndicator: true,
        indicatorBgPadding: 7.0,
        images: [
          NetworkImage(
            'Assets/Images/Orion/congo.jpg',
          ),
          NetworkImage(
            'Assets/Images/Orion/canal.png',
          ),
          NetworkImage(
            'Assets/Images/Orion/mpesa.png',
          ),
          NetworkImage(
            'Assets/Images/Orion/airtelm.png',
          ),
          NetworkImage(
            'Assets/Images/Orion/western.png',
          ),
          NetworkImage(
            'Assets/Images/Orion/fina.png',
          ),
          NetworkImage(
            'Assets/Images/Orion/equit.png',
          ),
          NetworkImage(
            'Assets/Images/Orion/smico.png',
          ),
          ExactAssetImage(
            'Assets/Images/Orion/hopital.jpg',
          ),
          ExactAssetImage(
            'Assets/Images/Orion/sbt.png',
          ),
          ExactAssetImage(
            'Assets/Images/Orion/dhl.png',
          ),
          ExactAssetImage(
            'Assets/Images/Orion/tmb.png',
          ),
          ExactAssetImage(
            'Assets/Images/Orion/orangem.png',
          ),
          ExactAssetImage(
            'Assets/Images/Orion/ecobank.png',
          ),
        ],
      ),
    );
  }

  presentWidget() {
    return Container(
        //height: 400,
        padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 0),
        child: Column(children: [
          Container(
            width: double.maxFinite,
            // height: 300,
            child: Stack(
              children: [
                Positioned(
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    child: Image.asset(
                      'Assets/Images/Orion/okapi.PNG',
                      fit: BoxFit.cover,
                    )),
                Container(
                    width: double.maxFinite,
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.6),
                    ),
                    child: Column(
                      crossAxisAlignment: !Responsive.isMobile(context)
                          ? CrossAxisAlignment.start
                          : CrossAxisAlignment.center,
                      children: [
                        TextWidgets.textBold(
                            title: 'Orion',
                            fontSize: 50,
                            textColor: AppColors.kWhiteColor),
                        const SizedBox(height: 20),
                        TextWidgets.text500(
                            align: !Responsive.isMobile(context)
                                ? TextAlign.left
                                : TextAlign.center,
                            title:
                                'Lorsque l\'informatique et la gestion des affaires se rancontre',
                            fontSize: 25,
                            textColor: AppColors.kWhiteColor),
                        const SizedBox(height: 40),
                        TextWidgets.text300(
                            align: !Responsive.isMobile(context)
                                ? TextAlign.left
                                : TextAlign.center,
                            title:
                                'Creez votre guichet Mobile money, SMICO et Western Union, Envoyer de l\'argent gerer votre caisse et transfer inter-agent ici',
                            fontSize: 20,
                            textColor: AppColors.kWhiteColor),
                        const SizedBox(height: 10),
                        // Consumer<MenuStateProvider>(
                        //     builder: (context, menuStateProvider, child) {
                        //   return Row(
                        //     mainAxisAlignment: MainAxisAlignment.end,
                        //     children: List.generate(
                        //         menuStateProvider.menu.length, (index) {
                        //       return MenuItem(
                        //           title: menuStateProvider.menu[index].title,
                        //           icon: menuStateProvider.menu[index].icon,
                        //           textColor: AppColors.kWhiteColor,
                        //           hoverColor: AppColors.kYellowColor,
                        //           backColor: Colors.transparent);
                        //     }),
                        //   );
                        // }),
                        // SizedBox(
                        //   width: 300,
                        //   child: CustomButton(
                        //     text: 'En savoir plus',
                        //     backColor: AppColors.kYellowColor,
                        //     textColor: AppColors.kBlackColor,
                        //     callback: () {},
                        //   ),
                        // ),
                      ],
                    )),
              ],
            ),
          ),
        ]));
  }
}

scoreCard() {
  return Card(
    color: AppColors.kTransparentColor.withOpacity(0.5),
    shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(kDefaultPadding / 2)),
    child: Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Row(
        children: [
          Expanded(
              flex: 1,
              child: Row(
                children: [
                  Column(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Consumer<UserStateProvider>(
                          builder: (context, userStateProvider, _) {
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              children: [
                                Column(
                                  children: [
                                    TextWidgets.text300(
                                      title: 'Cash CDF',
                                      fontSize: 16,
                                      textColor: AppColors.kWhiteColor
                                          .withOpacity(0.4),
                                    ),
                                    TextWidgets.text300(
                                      title:
                                          userStateProvider.cashCDF.toString(),
                                      fontSize: 20,
                                      textColor: AppColors.kWhiteColor,
                                    ),
                                  ],
                                ),
                                Column(
                                  children: [
                                    TextWidgets.text300(
                                      title: 'Cash USD',
                                      fontSize: 16,
                                      textColor: AppColors.kWhiteColor
                                          .withOpacity(0.4),
                                    ),
                                    TextWidgets.text300(
                                      title:
                                          userStateProvider.cashUSD.toString(),
                                      fontSize: 20,
                                      textColor: AppColors.kWhiteColor,
                                    ),
                                  ],
                                ),
                              ],
                            )
                          ],
                        );
                      })
                    ],
                  ),
                ],
              )),
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextWidgets.text300(
                      title: 'Facilitez vous la vie avec Orion',
                      fontSize: 18,
                      textColor: AppColors.kWhiteColor,
                    ),
                  ],
                ),
                Consumer<UserStateProvider>(
                    builder: (context, userStateProvider, _) {
                  return Column(
                    children: [
                      Column(
                        children: [
                          TextWidgets.text300(
                            title: 'Virtuel USD',
                            fontSize: 16,
                            textColor: AppColors.kWhiteColor.withOpacity(0.4),
                          ),
                          TextWidgets.text300(
                            title:
                                '${(userStateProvider.stockVirtuelUSD).toString()}',
                            fontSize: 25,
                            textColor: AppColors.kWhiteColor,
                          ),
                        ],
                      ),
                      Column(
                        children: [
                          TextWidgets.text300(
                            title: 'Virtuel CDF',
                            fontSize: 16,
                            textColor: AppColors.kWhiteColor.withOpacity(0.4),
                          ),
                          TextWidgets.text300(
                            title:
                                '${(userStateProvider.stockVirtuelCDF).toString()}',
                            fontSize: 25,
                            textColor: AppColors.kWhiteColor,
                          ),
                        ],
                      ),
                    ],
                  );
                })
              ],
            ),
          )
        ],
      ),
    ),
  );
}

userCard() {
  return Consumer<UserStateProvider>(builder: (context, userStateProvider, _) {
    return Card(
      color: AppColors.kBlackColor.withOpacity(0.5),
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(kDefaultPadding / 2)),
      child: Container(
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Center(
              child: Container(
                width: 90,
                height: 90,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(1000),
                    border: Border.all(
                      color: AppColors.kWhiteColor,
                      width: 2,
                    )),
                child: Stack(
                  children: [
                    const FlutterLogo(
                      size: 80,
                    ),
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: Center(
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: AppColors.kBlackColor.withOpacity(0.5),
                          ),
                          child: Icon(Icons.camera_alt,
                              color: AppColors.kYellowColor),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // TextWidgets.textBold(
            //     title:
            //         '${userStateProvider.clientData!.fname} ${userStateProvider.clientData!.lname}',
            //     fontSize: 16,
            //     textColor: AppColors.kWhiteColor),
            // const SizedBox(
            //   height: 10,
            // ),
            // TextWidgets.text300(
            //     title:
            //         '${userStateProvider.clientData!.telephone ?? userStateProvider.clientData!.email}',
            //     fontSize: 12,
            //     textColor: AppColors.kWhiteColor),
          ],
        ),
      ),
    );
  });
}

listWidget() {
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 8),
    margin: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                flex: 1,
                child: TextWidgets.textBold(
                    title: '#', fontSize: 14, textColor: AppColors.kWhiteColor),
              ),
              Expanded(
                flex: 3,
                child: TextWidgets.textBold(
                    title: 'Jour',
                    fontSize: 14,
                    textColor: AppColors.kWhiteColor),
              ),
              Expanded(
                flex: 2,
                child: TextWidgets.textBold(
                    title: 'Montant',
                    fontSize: 14,
                    textColor: AppColors.kWhiteColor),
              ),
              Expanded(
                flex: 2,
                child: TextWidgets.textBold(
                    title: 'Taux',
                    fontSize: 14,
                    textColor: AppColors.kWhiteColor),
              ),
              Expanded(
                flex: 3,
                child: TextWidgets.textBold(
                    title: 'Total',
                    fontSize: 14,
                    textColor: AppColors.kWhiteColor),
              )
            ],
          ),
        ),
        ListView.builder(
            itemCount: 5,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (context, int index) {
              return Column(
                children: [
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 10),
                    color: index % 2 == 0
                        ? AppColors.kWhiteColor.withOpacity(0.03)
                        : AppColors.kTransparentColor,
                    child: Row(
                      // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          flex: 1,
                          child: TextWidgets.textBold(
                              title: (index + 1).toString(),
                              fontSize: 14,
                              textColor: AppColors.kWhiteColor),
                        ),
                        Expanded(
                          flex: 3,
                          child: TextWidgets.text300(
                              title: DateTime.now()
                                  .add(Duration(days: 30 * index))
                                  .toString()
                                  .substring(0, 10),
                              fontSize: 14,
                              textColor: AppColors.kWhiteColor),
                        ),
                        Expanded(
                          flex: 2,
                          child: TextWidgets.text300(
                              title: 'Nom',
                              fontSize: 14,
                              textColor: AppColors.kWhiteColor),
                        ),
                        Expanded(
                          flex: 2,
                          child: TextWidgets.text300(
                              title: "Adresse",
                              fontSize: 14,
                              textColor: AppColors.kWhiteColor),
                        ),
                        Expanded(
                          flex: 3,
                          child: TextWidgets.text300(
                              title: 'Holder',
                              fontSize: 14,
                              textColor: AppColors.kWhiteColor),
                        ),
                        IconButton(
                            onPressed: () {},
                            icon: Icon(
                              Icons.edit,
                              color: AppColors.kGreenColor,
                            )),
                      ],
                    ),
                  ),
                  Divider(
                    height: 2,
                    thickness: 1,
                    color: AppColors.kGreyColor,
                  )
                ],
              );
            }),
        const SizedBox(
          height: 20,
        ),
      ],
    ),
  );
}

stepsList() {
  return Container(
    padding: EdgeInsets.zero,
    child: Column(
      children: [
        // ===============================Historique de Transaction============================
        Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            decoration: BoxDecoration(
                color: AppColors.kBlackColor.withOpacity(0.5),
                borderRadius: BorderRadius.circular(kDefaultPadding / 2)),
            child: Consumer<UserStateProvider>(
                builder: (context, userStateProvider, _) {
              return ExpansionTile(
                title: Row(
                  children: [
                    Icon(
                        userStateProvider.banks.isNotEmpty
                            ? Icons.check
                            : Icons.clear,
                        color: userStateProvider.banks.isNotEmpty
                            ? AppColors.kGreenColor
                            : AppColors.kRedColor),
                    const SizedBox(width: 20),
                    TextWidgets.textBold(
                        title: 'Historique',
                        fontSize: 16,
                        textColor: AppColors.kWhiteColor),
                    Expanded(
                        child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        IconButton(
                            onPressed: () {
                              showCupertinoModalPopup(
                                  context: context,
                                  builder: (context) {
                                    return Center(
                                      child: HistortransList(
                                          //updatingData: false,
                                          ),
                                    );
                                  });
                            },
                            icon: Icon(
                              Icons.add_circle_outline,
                              color: AppColors.kYellowColor,
                            )),
                      ],
                    ))
                  ],
                ),
                children: [HistortransList()],
              );
            })),
        // ===============================Envoyer Argent============================
        Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            decoration: BoxDecoration(
                color: AppColors.kBlackColor.withOpacity(0.5),
                borderRadius: BorderRadius.circular(kDefaultPadding / 2)),
            child: Consumer<UserStateProvider>(
                builder: (context, userStateProvider, _) {
              return ExpansionTile(
                title: Row(
                  children: [
                    Icon(
                        userStateProvider.nominatedAdminData.isNotEmpty
                            ? Icons.check
                            : Icons.clear,
                        color: userStateProvider.nominatedAdminData.isNotEmpty
                            ? AppColors.kGreenColor
                            : AppColors.kRedColor),
                    const SizedBox(width: 20),
                    TextWidgets.textBold(
                        title: 'Envoie',
                        fontSize: 16,
                        textColor: AppColors.kWhiteColor),
                    // Expanded(
                    //     child: Row(
                    //   mainAxisAlignment: MainAxisAlignment.end,
                    //   children: [
                    //     IconButton(
                    //         onPressed: () {
                    //           showCupertinoModalPopup(
                    //               context: context,
                    //               builder: (context) {
                    //                 return Center(
                    //                   child: EnvoieAirtelmoneyPage(
                    //                     updatingData: false,
                    //                   ),
                    //                 );
                    //               });
                    //         },
                    //         icon: Icon(
                    //           Icons.add_circle_outline,
                    //           color: AppColors.kYellowColor,
                    //         )),
                    //   ],
                    // ))
                  ],
                ),
                children: [
                  Responsive(
                      mobile: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                EnvoieOrangemoneyPage(
                                  updatingData: false,
                                ),
                                EnvoieOrangemoneysPage(
                                  updatingData: false,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      tablet: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // Expanded(
                                //   child:
                                // procarousselImage(),
                                // //),
                                // //
                                // presentWidget(),
                                //),
                                EnvoieOrangemoneyPage(
                                  updatingData: false,
                                ),
                                EnvoieOrangemoneysPage(
                                  updatingData: false,
                                ),
                                //)
                              ],
                            ),
                          ),
                        ],
                      ),
                      web: Column(children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: EnvoieOrangemoneysPage(
                                      updatingData: false,
                                    ),
                                  ),
                                  Expanded(
                                      child: EnvoieOrangemoneysPage(
                                    updatingData: false,
                                  ))
                                ],
                              )
                            ],
                          ),
                        ),
                      ]))
                ],
              );
            })),
        // =================================Sorti=======================
        Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            decoration: BoxDecoration(
                color: AppColors.kBlackColor.withOpacity(0.5),
                borderRadius: BorderRadius.circular(kDefaultPadding / 2)),
            child: Consumer<UserStateProvider>(
                builder: (context, userStateProvider, _) {
              return ExpansionTile(
                title: Row(
                  children: [
                    Icon(
                        userStateProvider.employerData.isNotEmpty
                            ? Icons.check
                            : Icons.clear,
                        color: userStateProvider.employerData.isNotEmpty
                            ? AppColors.kGreenColor
                            : AppColors.kRedColor),
                    const SizedBox(width: 20),
                    TextWidgets.textBold(
                        title: 'Sorti',
                        fontSize: 16,
                        textColor: AppColors.kWhiteColor),
                    // Expanded(
                    //     child: Row(
                    //   mainAxisAlignment: MainAxisAlignment.end,
                    //   children: [
                    //     IconButton(
                    //         onPressed: () {
                    //           if (userStateProvider.employerData.length >= 2) {
                    //             return Message.showToast(
                    //                 msg:
                    //                     'Vous avez deja atteint la limite des employeurs');
                    //           }
                    //           showCupertinoModalPopup(
                    //               context: context,
                    //               builder: (context) {
                    //                 return Center(
                    //                   child: EnvoieArgentPage(
                    //                     updatingData: false,
                    //                   ),
                    //                 );
                    //               });
                    //         },
                    //         icon: Icon(
                    //           Icons.add_circle_outline,
                    //           color: AppColors.kYellowColor,
                    //         )),
                    //   ],
                    // ))
                  ],
                ),
                children: [
                  Responsive(
                      mobile: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SortiOrangemoneyPage(
                                  updatingData: false,
                                ),
                                SortiOrangemoneysPage(
                                  updatingData: false,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      tablet: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // Expanded(
                                //   child:
                                // procarousselImage(),
                                // //),
                                // //
                                // presentWidget(),
                                //),
                                SortiOrangemoneyPage(
                                  updatingData: false,
                                ),
                                SortiOrangemoneysPage(
                                  updatingData: false,
                                ),
                                //)
                              ],
                            ),
                          ),
                        ],
                      ),
                      web: Column(children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: SortiOrangemoneyPage(
                                      updatingData: false,
                                    ),
                                  ),
                                  Expanded(
                                      child: SortiOrangemoneysPage(
                                    updatingData: false,
                                  ))
                                ],
                              )
                            ],
                          ),
                        ),
                      ]))
                ],
              );
            })),
        //============Pret=============
        Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            decoration: BoxDecoration(
                color: AppColors.kBlackColor.withOpacity(0.5),
                borderRadius: BorderRadius.circular(kDefaultPadding / 2)),
            child: Consumer<UserStateProvider>(
                builder: (context, userStateProvider, _) {
              return ExpansionTile(
                title: Row(
                  children: [
                    Icon(
                        userStateProvider.creditHistoryData.isNotEmpty
                            ? Icons.check
                            : Icons.clear,
                        color: userStateProvider.creditHistoryData.isNotEmpty
                            ? AppColors.kGreenColor
                            : AppColors.kRedColor),
                    const SizedBox(width: 20),
                    TextWidgets.textBold(
                        title: 'Pret ',
                        fontSize: 16,
                        textColor: AppColors.kWhiteColor),
                    // Expanded(
                    //     child: Row(
                    //   mainAxisAlignment: MainAxisAlignment.end,
                    //   children: [
                    //     IconButton(
                    //         onPressed: () {
                    //           showCupertinoModalPopup(
                    //               context: context,
                    //               builder: (context) {
                    //                 return Center(
                    //                   child: PretPage(
                    //                     updatingData: false,
                    //                   ),
                    //                 );
                    //               });
                    //         },
                    //         icon: Icon(
                    //           Icons.add_circle_outline,
                    //           color: AppColors.kYellowColor,
                    //         )),
                    //   ],
                    // ))
                  ],
                ),
                children: [
                  Responsive(
                      mobile: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                PretOrangemoneyPage(
                                  updatingData: false,
                                ),
                                PretOrangemoneysPage(
                                  updatingData: false,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      tablet: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // Expanded(
                                //   child:
                                // procarousselImage(),
                                // //),
                                // //
                                // presentWidget(),
                                //),
                                PretOrangemoneyPage(
                                  updatingData: false,
                                ),
                                PretOrangemoneysPage(
                                  updatingData: false,
                                ),
                                //)
                              ],
                            ),
                          ),
                        ],
                      ),
                      web: Column(children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: PretOrangemoneyPage(
                                      updatingData: false,
                                    ),
                                  ),
                                  Expanded(
                                      child: PretOrangemoneysPage(
                                    updatingData: false,
                                  ))
                                ],
                              )
                            ],
                          ),
                        ),
                      ]))
                ],
              );
            })),

        // =================================Approvisionnement=======================
        Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            decoration: BoxDecoration(
                color: AppColors.kBlackColor.withOpacity(0.5),
                borderRadius: BorderRadius.circular(kDefaultPadding / 2)),
            child: Consumer<UserStateProvider>(
                builder: (context, userStateProvider, _) {
              return ExpansionTile(
                title: Row(
                  children: [
                    Icon(
                        userStateProvider.employerData.isNotEmpty
                            ? Icons.check
                            : Icons.clear,
                        color: userStateProvider.employerData.isNotEmpty
                            ? AppColors.kGreenColor
                            : AppColors.kRedColor),
                    const SizedBox(width: 20),
                    TextWidgets.textBold(
                        title: 'Approvisionnement',
                        fontSize: 16,
                        textColor: AppColors.kWhiteColor),
                    // Expanded(
                    //     child: Row(
                    //   mainAxisAlignment: MainAxisAlignment.end,
                    //   children: [
                    //     IconButton(
                    //         onPressed: () {
                    //           if (userStateProvider.employerData.length >= 2) {
                    //             return Message.showToast(
                    //                 msg:
                    //                     'Vous avez deja atteint la limite des employeurs');
                    //           }
                    //           showCupertinoModalPopup(
                    //               context: context,
                    //               builder: (context) {
                    //                 return Center(
                    //                   child: EnvoieArgentPage(
                    //                     updatingData: false,
                    //                   ),
                    //                 );
                    //               });
                    //         },
                    //         icon: Icon(
                    //           Icons.add_circle_outline,
                    //           color: AppColors.kYellowColor,
                    //         )),
                    //   ],
                    // ))
                  ],
                ),
                children: [
                  Responsive(
                      mobile: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ApprovisionnementOrangePage(
                                  updatingData: false,
                                ),
                                ApprovisionnementOrangesPage(
                                  updatingData: false,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      tablet: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // Expanded(
                                //   child:
                                // procarousselImage(),
                                // //),
                                // //
                                // presentWidget(),
                                //),
                                ApprovisionnementOrangePage(
                                  updatingData: false,
                                ),
                                ApprovisionnementOrangesPage(
                                  updatingData: false,
                                ),
                                //)
                              ],
                            ),
                          ),
                        ],
                      ),
                      web: Column(children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: ApprovisionnementOrangePage(
                                      updatingData: false,
                                    ),
                                  ),
                                  Expanded(
                                      child: ApprovisionnementOrangesPage(
                                    updatingData: false,
                                  ))
                                ],
                              )
                            ],
                          ),
                        ),
                      ]))
                ],
              );
            })),

        //============Emprunt=============
        Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            decoration: BoxDecoration(
                color: AppColors.kBlackColor.withOpacity(0.5),
                borderRadius: BorderRadius.circular(kDefaultPadding / 2)),
            child: Consumer<UserStateProvider>(
                builder: (context, userStateProvider, _) {
              return ExpansionTile(
                title: Row(
                  children: [
                    Icon(
                        userStateProvider.creditHistoryData.isNotEmpty
                            ? Icons.check
                            : Icons.clear,
                        color: userStateProvider.creditHistoryData.isNotEmpty
                            ? AppColors.kGreenColor
                            : AppColors.kRedColor),
                    const SizedBox(width: 20),
                    TextWidgets.textBold(
                        title: 'Emprunt ',
                        fontSize: 16,
                        textColor: AppColors.kWhiteColor),
                    // Expanded(
                    //     child: Row(
                    //   mainAxisAlignment: MainAxisAlignment.end,
                    //   children: [
                    //     IconButton(
                    //         onPressed: () {
                    //           showCupertinoModalPopup(
                    //               context: context,
                    //               builder: (context) {
                    //                 return Center(
                    //                   child: EmPruntPage(
                    //                     updatingData: false,
                    //                   ),
                    //                 );
                    //               });
                    //         },
                    //         icon: Icon(
                    //           Icons.add_circle_outline,
                    //           color: AppColors.kYellowColor,
                    //         )),
                    //   ],
                    // ))
                  ],
                ),
                children: [
                  //  isAsync: appStateProvider.isAsync,
                  // progressColor: AppColors.kYellowColor,
                  // child: SingleChildScrollView(
                  //     controller: _controller,
                  // child:
                  Responsive(
                      mobile: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                EmpruntOrangePage(
                                  updatingData: false,
                                ),
                                EmpruntOrangesPage(
                                  updatingData: false,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      tablet: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // Expanded(
                                //   child:
                                // procarousselImage(),
                                // //),
                                // //
                                // presentWidget(),
                                //),
                                EmpruntOrangePage(
                                  updatingData: false,
                                ),
                                EmpruntOrangesPage(
                                  updatingData: false,
                                ),
                                //)
                              ],
                            ),
                          ),
                        ],
                      ),
                      web: Column(children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: EmpruntOrangePage(
                                      updatingData: false,
                                    ),
                                  ),
                                  Expanded(
                                      child: EmpruntOrangesPage(
                                    updatingData: false,
                                  ))
                                ],
                              )
                            ],
                          ),
                        ),
                      ]))
                  //               ));
                  // },
                  //   builder: (context, appStateProvider, child) {
                  // return

                  // Row(
                  //   children: [
                  //     Expanded(
                  //       child: EmpruntAirtelPage(
                  //         updatingData: false,
                  //       ),
                  //     ),
                  //     Expanded(
                  //         child: EmpruntAirtelsPage(
                  //       updatingData: false,
                  //     ))
                  //   ],
                  // )
                ],
              );
            })),
      ],
    ),
  );
}
