import 'package:orion/Resources/AppStateProvider/menu_state_provider.dart';
import 'package:orion/Resources/AppStateProvider/app_stateprovider.dart';
import 'package:orion/Views/Guichet/Activites%20Bancaires/gestion_menu_ecobank.dart';
import 'package:orion/Views/Guichet/Activites%20Bancaires/gestion_menu_smico.dart';
import 'package:orion/Views/Guichet/Activites%20Bancaires/gestion_menu_tmb.dart';
import 'package:orion/Views/Guichet/Menu Mobile Money/gestion_menu_airtel.dart';
import 'package:orion/Views/Guichet/Menu Mobile Money/gestion_menu_orange.dart';
import 'package:orion/Views/Guichet/Menu Mobile Money/gestion_menu_vodacom.dart';
import 'package:orion/Views/Guichet//Activites Bancaires/gestion_menu_equity.dart';
import 'package:orion/Views/Guichet//Activites Bancaires/gestion_western_.dart';
import 'package:orion/Views/Guichet//Activites Bancaires/gestion_menu_finca.dart';
import 'package:orion/Resources/Components/card_title_subtitle_icon.dart';

import 'package:carousel_images/carousel_images.dart';
import 'package:carousel_pro/carousel_pro.dart';
import 'package:orion/Resources/Components/applogo.dart';

import 'package:orion/Views/Home/menu.dart';
import 'package:provider/provider.dart';

import 'package:orion/Resources/global_variables.dart';
import 'package:orion/Resources/responsive.dart';
import 'package:flutter/material.dart';

class AcceuilOrionPage extends StatefulWidget {
  const AcceuilOrionPage({Key? key}) : super(key: key);

  @override
  _AcceuilOrionPageState createState() => _AcceuilOrionPageState();
}

class _AcceuilOrionPageState extends State<AcceuilOrionPage> {
  @override
  void initState() {
    super.initState();
    Provider.of<AppStateProvider>(context, listen: false)
        .initUI(context: context);
    // Provider.of<UserStateProvider>(context, listen: false)
    //     .tryGetOnline(context: context);
  }

  final ScrollController _controller = ScrollController();

  @override
  Widget build(BuildContext context) {
    return Consumer<MenuStateProvider>(
        builder: (context, menuStateProvider, child) {
      return Scaffold(
          // appBar: AppBar(
          //   title: Row(children: [
          //     const AppLogo(size: Size(100, 100)),
          //     Text(menuStateProvider.currentMenu == null ||
          //             menuStateProvider.currentMenu == 'Accueil'
          //         ? 'Orion'
          //         : menuStateProvider.currentMenu),
          //     if (Responsive.isWeb(context))
          //       Expanded(
          //         child: Consumer<MenuStateProvider>(
          //             builder: (context, menuStateProvider, child) {
          //           return Row(
          //             mainAxisAlignment: MainAxisAlignment.end,
          //             children:
          //                 List.generate(menuStateProvider.menu.length, (index) {
          //               return MenuItem(
          //                   title: menuStateProvider.menu[index].title,
          //                   icon: menuStateProvider.menu[index].icon,
          //                   textColor: AppColors.kWhiteColor,
          //                   hoverColor: AppColors.kYellowColor,
          //                   backColor: Colors.transparent);
          //             }),
          //           );
          //         }),
          //       ),
          //   ]),
          // ),
          // drawer: Responsive.isWeb(context)
          //     ? null
          //     : const Drawer(
          //         child: MenuWidget(),
          //       ),
          body: SafeArea(
              child: SingleChildScrollView(
                  controller: _controller,
                  child: Responsive(
                      mobile: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // Row(
                                //   children: [
                                //     menuStateProvider.activePage,
                                //   ],
                                // ),
                                procarousselImage(),
                                presentWidget(),

                                // Expanded(
                                //   child:
                                // ),
                                // Expanded(child:
                                // loanCalculationWidget()
                              ],
                            ),
                          ),
                        ],
                      ),
                      // mobile: Column(
                      //   children: [
                      //     Expanded(
                      //       flex: 2,
                      //       child: procarousselImage(),
                      //     ),

                      //     //carousselImage(),
                      //     Expanded(
                      //       flex: 2,
                      //       child: presentWidget(),
                      //     ),
                      //     Expanded(
                      //       flex: 2,
                      //       child: loanCalculationWidget(),
                      //     ),
                      //   ],
                      // ),
                      tablet: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Row(
                          //   children: [
                          //     menuStateProvider.activePage,
                          //   ],
                          // ),
                          // Expanded(
                          //   flex: 2,
                          //child:
                          procarousselImage(),
                          // ),
                          // Expanded(
                          //   flex: 2,
                          //   child: carousselImage(),
                          // ),
                          // Expanded(
                          //   flex: 2,
                          //child:
                          presentWidget(),
                          //

                          // Expanded(
                          //   child:
                          //loanCalculationWidget(),
                          // )
                        ],
                      ),
                      web: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Row(
                            //   children: [
                            //     menuStateProvider.activePage,
                            //   ],
                            // ),
                            procarousselImage(),
                            //carousselImage(),
                            presentWidget(),

                            Row(
                              children: [
                                // Expanded(
                                //   flex: 2,
                                //   child: loanCalculationWidget(),
                                // ),
                              ],
                            )
                          ])))));
    });
  }

  procarousselImage() {
    return Container(
      height: 300,
      child: Carousel(
        boxFit: BoxFit.cover,
        autoplay: true,
        animationCurve: Curves.fastOutSlowIn,
        animationDuration: Duration(milliseconds: 1000),
        dotSize: 6.0,
        dotIncreasedColor: Color(0xFFFF335C),
        dotBgColor: Colors.transparent,
        dotPosition: DotPosition.topRight,
        dotVerticalPadding: 10.0,
        showIndicator: true,
        indicatorBgPadding: 7.0,
        images: [
          NetworkImage(
            'Assets/Images/Orion/congo.jpg',
          ),
          NetworkImage(
            'Assets/Images/Orion/canal.png',
          ),
          NetworkImage(
            'Assets/Images/Orion/mpesa.png',
          ),
          NetworkImage(
            'Assets/Images/Orion/airtelm.png',
          ),
          NetworkImage(
            'Assets/Images/Orion/western.png',
          ),
          NetworkImage(
            'Assets/Images/Orion/fina.png',
          ),
          NetworkImage(
            'Assets/Images/Orion/equit.png',
          ),
          NetworkImage(
            'Assets/Images/Orion/smico.png',
          ),
          ExactAssetImage(
            'Assets/Images/Orion/hopital.jpg',
          ),
          ExactAssetImage(
            'Assets/Images/Orion/sbt.png',
          ),
          ExactAssetImage(
            'Assets/Images/Orion/dhl.png',
          ),
          ExactAssetImage(
            'Assets/Images/Orion/tmb.png',
          ),
          ExactAssetImage(
            'Assets/Images/Orion/orangem.png',
          ),
          ExactAssetImage(
            'Assets/Images/Orion/ecobank.png',
          ),
        ],
      ),
    );
  }

  presentWidget() {
    return Container(
      //height: 400,
      padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 0),
      child: Column(
        children: [
          // Container(
          //   width: double.maxFinite,
          //   // height: 300,
          //   child: Stack(
          //     children: [
          //       Positioned(
          //           top: 0,
          //           left: 0,
          //           right: 0,
          //           bottom: 0,
          //           child: Image.asset(
          //             'Assets/Images/Orion/okapi.PNG',
          //             fit: BoxFit.cover,
          //           )),
          //       Container(
          //           width: double.maxFinite,
          //           padding: const EdgeInsets.all(10),
          //           decoration: BoxDecoration(
          //             color: Colors.black.withOpacity(0.6),
          //           ),
          //           child: Column(
          //             crossAxisAlignment: !Responsive.isMobile(context)
          //                 ? CrossAxisAlignment.start
          //                 : CrossAxisAlignment.center,
          //             children: [
          //               TextWidgets.textBold(
          //                   title: 'Orion',
          //                   fontSize: 50,
          //                   textColor: AppColors.kWhiteColor),
          //               const SizedBox(height: 20),
          //               TextWidgets.text500(
          //                   align: !Responsive.isMobile(context)
          //                       ? TextAlign.left
          //                       : TextAlign.center,
          //                   title:
          //                       'Lorsque l\'informatique et la gestion des affaires se rancontre',
          //                   fontSize: 25,
          //                   textColor: AppColors.kWhiteColor),
          //               const SizedBox(height: 40),
          //               TextWidgets.text300(
          //                   align: !Responsive.isMobile(context)
          //                       ? TextAlign.left
          //                       : TextAlign.center,
          //                   title:
          //                       'Creez votre guichet Mobile money, SMICO et Western Union, Envoyer de l\'argent gerer votre caisse et transfer inter-agent ici',
          //                   fontSize: 20,
          //                   textColor: AppColors.kWhiteColor),
          //               const SizedBox(height: 10),
          //               // Consumer<MenuStateProvider>(
          //               //     builder: (context, menuStateProvider, child) {
          //               //   return Row(
          //               //     mainAxisAlignment: MainAxisAlignment.end,
          //               //     children: List.generate(
          //               //         menuStateProvider.menu.length, (index) {
          //               //       return MenuItem(
          //               //           title: menuStateProvider.menu[index].title,
          //               //           icon: menuStateProvider.menu[index].icon,
          //               //           textColor: AppColors.kWhiteColor,
          //               //           hoverColor: AppColors.kYellowColor,
          //               //           backColor: Colors.transparent);
          //               //     }),
          //               //   );
          //               // }),
          //               // SizedBox(
          //               //   width: 300,
          //               //   child: CustomButton(
          //               //     text: 'En savoir plus',
          //               //     backColor: AppColors.kYellowColor,
          //               //     textColor: AppColors.kBlackColor,
          //               //     callback: () {},
          //               //   ),
          //               // ),
          //             ],
          //           )),
          //     ],
          //   ),
          // ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10),
            child: Container(
              width: double.maxFinite,
              decoration: BoxDecoration(
                  border: Border.all(color: Colors.transparent, width: 0)),
              child: Wrap(
                  alignment: WrapAlignment.spaceAround,
                  // crossAxisAlignment: WrapCrossAlignment.start,
                  runAlignment: WrapAlignment.spaceAround,
                  direction: Axis.horizontal,
                  // textDirection: TextDirection.ltr,
                  children: [
                    CardWithIconTitleSubtitle(
                        balance: {
                          "virtuel_CDF": "CDF: 100",
                          "virtuel_USD": "USD: 200",
                          "cash_CDF": "CDF: 300",
                          "cash_USD": "USD: 400"
                        },
                        width:
                            !Responsive.isWeb(context) ? double.maxFinite : 300,
                        //icon: Icons.attach_money,
                        title: 'Airtel Money',
                        image: Image.asset('Assets/Images/Orion/airtelm.png'),
                        subtitle:
                            "Transferez de l'argent rapidement a vos clients Airtel Money avec Orion",
                        title2: 'Compte 990268381 - Destin Kabote',
                        title3: '',
                        subtitle1: 'Soldes Cash',
                        subtitle2: 'Soldes Virtuel',
                        page: const GestionAirtelPage(),
                        iconColor: AppColors.kGreyColor,
                        titleColor: AppColors.kBlackColor,
                        subtitleColor: AppColors.kBlackColor),
                    CardWithIconTitleSubtitle(
                        width:
                            !Responsive.isWeb(context) ? double.maxFinite : 300,
                        //icon: Icons.attach_money,
                        title: 'Vodacom M-PESA',
                        image: Image.asset('Assets/Images/Orion/mpesa.png'),
                        balance: {
                          "virtuel_CDF": "CDF: 100",
                          "virtuel_USD": "USD: 200",
                          "cash_CDF": "CDF: 300",
                          "cash_USD": "USD: 400"
                        },
                        subtitle:
                            "Transferez de l'argent rapidement a vos clients M-PESA avec Orion",
                        title2: 'Compte 990268381 - Destin Kabote',
                        title3: '',
                        subtitle1: 'Soldes Cash',
                        subtitle2: 'Soldes Virtuel',
                        page: const GestionVodacomPage(),
                        iconColor: AppColors.kGreyColor,
                        titleColor: AppColors.kBlackColor,
                        subtitleColor: AppColors.kBlackColor),
                    CardWithIconTitleSubtitle(
                        width:
                            !Responsive.isWeb(context) ? double.maxFinite : 300,
                        //icon: Icons.attach_money,
                        title: 'Orange Money',
                        image: Image.asset('Assets/Images/Orion/orangem.png'),
                        balance: {
                          "virtuel_CDF": "CDF: 100",
                          "virtuel_USD": "USD: 200",
                          "cash_CDF": "CDF: 300",
                          "cash_USD": "USD: 400"
                        },
                        subtitle:
                            "Recevez et transeferez via Orange money de partout et assurer la tracabilite de vos rapport.",
                        title2: 'Compte 990268381 - Destin Kabote',
                        title3: '',
                        subtitle1: 'Soldes Cash',
                        subtitle2: 'Soldes Virtuel',
                        page: const GestionOrangePage(),
                        iconColor: AppColors.kGreyColor,
                        titleColor: AppColors.kBlackColor,
                        subtitleColor: AppColors.kBlackColor),
                    CardWithIconTitleSubtitle(
                        width:
                            !Responsive.isWeb(context) ? double.maxFinite : 300,
                        //icon: Icons.attach_money,
                        title: 'Western Union',
                        image: Image.asset('Assets/Images/Orion/western.png'),
                        balance: {
                          "virtuel_CDF": "CDF: 100",
                          "virtuel_USD": "USD: 200",
                          "cash_CDF": "CDF: 300",
                          "cash_USD": "USD: 400"
                        },
                        subtitle:
                            "Transferez de l'argent rapidement dans le compte bancaire de vos clients avec Orion",
                        title2: 'Compte 990268381 - Destin Kabote',
                        title3: '',
                        subtitle1: 'Soldes Cash',
                        subtitle2: 'Soldes Virtuel',
                        page: const gestionWesternPage(),
                        iconColor: AppColors.kGreyColor,
                        titleColor: AppColors.kBlackColor,
                        subtitleColor: AppColors.kBlackColor),
                    CardWithIconTitleSubtitle(
                        width:
                            !Responsive.isWeb(context) ? double.maxFinite : 300,
                        //icon: Icons.attach_money,
                        title: 'FINCA',
                        image: Image.asset('Assets/Images/Orion/fina.png'),
                        balance: {
                          "virtuel_CDF": "CDF: 100",
                          "virtuel_USD": "USD: 200",
                          "cash_CDF": "CDF: 300",
                          "cash_USD": "USD: 400"
                        },
                        subtitle:
                            "Transferez de l'argent rapidement dans le compte bancaire de vos clients avec Orion",
                        title2: 'Compte 990268381 - Destin Kabote',
                        title3: '',
                        subtitle1: 'Soldes Cash',
                        subtitle2: 'Soldes Virtuel',
                        page: const gestionfincaPage(),
                        iconColor: AppColors.kGreyColor,
                        titleColor: AppColors.kBlackColor,
                        subtitleColor: AppColors.kBlackColor),
                    CardWithIconTitleSubtitle(
                        width:
                            !Responsive.isWeb(context) ? double.maxFinite : 300,
                        //icon: Icons.attach_money,
                        title: 'Equity BCDC',
                        image: Image.asset('Assets/Images/Orion/equit.png'),
                        balance: {
                          "virtuel_CDF": "CDF: 100",
                          "virtuel_USD": "USD: 200",
                          "cash_CDF": "CDF: 300",
                          "cash_USD": "USD: 400"
                        },
                        subtitle:
                            "Transferez de l'argent rapidement dans le compte bancaire de vos clients avec Orion",
                        title2: 'Compte 990268381 - Destin Kabote',
                        title3: '',
                        subtitle1: 'Soldes Cash',
                        subtitle2: 'Soldes Virtuel',
                        page: const GestionEquityPage(),
                        iconColor: AppColors.kGreyColor,
                        titleColor: AppColors.kBlackColor,
                        subtitleColor: AppColors.kBlackColor),
                    CardWithIconTitleSubtitle(
                        width:
                            !Responsive.isWeb(context) ? double.maxFinite : 300,
                        // icon: Icons.attach_money,
                        title: 'SMICO',
                        image: Image.asset('Assets/Images/Orion/smico.png'),
                        balance: {
                          "virtuel_CDF": "CDF: 100",
                          "virtuel_USD": "USD: 200",
                          "cash_CDF": "CDF: 300",
                          "cash_USD": "USD: 400"
                        },
                        subtitle:
                            "Transferez de l'argent rapidement dans le compte bancaire de vos clients avec Orion",
                        title2: 'Compte 990268381 - Destin Kabote',
                        title3: '',
                        subtitle1: 'Soldes Cash',
                        subtitle2: 'Soldes Virtuel',
                        page: const GestionSmicoPage(),
                        iconColor: AppColors.kGreyColor,
                        titleColor: AppColors.kBlackColor,
                        subtitleColor: AppColors.kBlackColor),
                    CardWithIconTitleSubtitle(
                        width:
                            !Responsive.isWeb(context) ? double.maxFinite : 300,
                        //icon: Icons.attach_money,
                        title: 'TMB, Pepele Mobile',
                        image: Image.asset('Assets/Images/Orion/tmb.png'),
                        balance: {
                          "virtuel_CDF": "CDF: 100",
                          "virtuel_USD": "USD: 200",
                          "cash_CDF": "CDF: 300",
                          "cash_USD": "USD: 400"
                        },
                        subtitle:
                            "Transferez de l'argent rapidement dans le compte bancaire de vos clients avec Orion",
                        title2: 'Compte 990268381 - Destin Kabote',
                        title3: '',
                        subtitle1: 'Soldes Cash',
                        subtitle2: 'Soldes Virtuel',
                        page: const GestionTmbPage(),
                        iconColor: AppColors.kGreyColor,
                        titleColor: AppColors.kBlackColor,
                        subtitleColor: AppColors.kBlackColor),
                    CardWithIconTitleSubtitle(
                        width:
                            !Responsive.isWeb(context) ? double.maxFinite : 300,
                        //icon: Icons.attach_money,
                        title: 'Ecobank',
                        image: Image.asset('Assets/Images/Orion/ecobank.png'),
                        balance: {
                          "virtuel_CDF": "CDF: 100",
                          "virtuel_USD": "USD: 200",
                          "cash_CDF": "CDF: 300",
                          "cash_USD": "USD: 400"
                        },
                        subtitle:
                            "Transferez de l'argent rapidement dans le compte bancaire de vos clients avec Orion",
                        title2: 'Compte 990268381 - Destin Kabote',
                        title3: '',
                        subtitle1: 'Soldes Cash',
                        subtitle2: 'Soldes Virtuel',
                        page: const GestionEcobankPage(),
                        iconColor: AppColors.kGreyColor,
                        titleColor: AppColors.kBlackColor,
                        subtitleColor: AppColors.kBlackColor),
                    CardWithIconTitleSubtitle(
                        width:
                            !Responsive.isWeb(context) ? double.maxFinite : 300,
                        // icon: Icons.attach_money,
                        title: 'SBT',
                        image: Image.asset('Assets/Images/Orion/sbt.png'),
                        balance: {
                          "virtuel_CDF": "CDF: 100",
                          "virtuel_USD": "USD: 200",
                          "cash_CDF": "CDF: 300",
                          "cash_USD": "USD: 400"
                        },
                        subtitle:
                            "Transferez de l'argent rapidement dans le compte bancaire de vos clients avec Orion",
                        title2: 'Compte 990268381 - Destin Kabote',
                        title3: '',
                        subtitle1: 'Soldes Cash',
                        subtitle2: 'Soldes Virtuel',
                        page: const GestionEquityPage(),
                        iconColor: AppColors.kGreyColor,
                        titleColor: AppColors.kBlackColor,
                        subtitleColor: AppColors.kBlackColor),
                    CardWithIconTitleSubtitle(
                        width:
                            !Responsive.isWeb(context) ? double.maxFinite : 300,
                        //icon: Icons.attach_money,
                        title: 'DHL',
                        image: Image.asset('Assets/Images/Orion/dhl.png'),
                        balance: {
                          "virtuel_CDF": "CDF: 100",
                          "virtuel_USD": "USD: 200",
                          "cash_CDF": "CDF: 300",
                          "cash_USD": "USD: 400"
                        },
                        subtitle:
                            "Transferez de l'argent rapidement dans le compte bancaire de vos clients avec Orion",
                        title2: 'Compte 990268381 - Destin Kabote',
                        title3: '',
                        subtitle1: 'Soldes Cash',
                        subtitle2: 'Soldes Virtuel',
                        page: GestionEquityPage(),
                        iconColor: AppColors.kGreyColor,
                        titleColor: AppColors.kBlackColor,
                        subtitleColor: AppColors.kBlackColor),
                    CardWithIconTitleSubtitle(
                        width:
                            !Responsive.isWeb(context) ? double.maxFinite : 300,
                        // icon: Icons.money,
                        title: 'Agence de Voyage',
                        image: Image.asset('Assets/Images/Orion/congo.jpg'),
                        balance: {
                          "virtuel_CDF": "CDF: 100",
                          "virtuel_USD": "USD: 200",
                          "cash_CDF": "CDF: 300",
                          "cash_USD": "USD: 400"
                        },
                        subtitle:
                            "Passez les commandes de vos billets CAA, Congo Airways, Air Congo, Kenya Airways et Ethiopian Airlines Ici.",
                        title2: 'Compte 990268381 - Destin Kabote',
                        title3: '',
                        subtitle1: 'Soldes Cash',
                        subtitle2: 'Soldes Virtuel',
                        page: GestionEquityPage(),
                        iconColor: AppColors.kGreyColor,
                        titleColor: AppColors.kBlackColor,
                        subtitleColor: AppColors.kBlackColor),
                    CardWithIconTitleSubtitle(
                        width:
                            !Responsive.isWeb(context) ? double.maxFinite : 300,
                        //icon: Icons.money,
                        title: 'Bouquet CANAL +',
                        image: Image.asset('Assets/Images/Orion/canal.png'),
                        balance: {
                          "virtuel_CDF": "CDF: 100",
                          "virtuel_USD": "USD: 200",
                          "cash_CDF": "CDF: 300",
                          "cash_USD": "USD: 400"
                        },
                        subtitle:
                            "Passez les commandes de vos Bouquet CANAL + ici .",
                        title2: 'Compte 990268381 - Destin Kabote',
                        title3: '',
                        subtitle1: 'Soldes Cash',
                        subtitle2: 'Soldes Virtuel',
                        page: GestionEquityPage(),
                        iconColor: AppColors.kGreyColor,
                        titleColor: AppColors.kBlackColor,
                        subtitleColor: AppColors.kBlackColor),
                    CardWithIconTitleSubtitle(
                        width:
                            !Responsive.isWeb(context) ? double.maxFinite : 300,
                        // icon: Icons.room_preferences_outlined,
                        title: 'Hopital',
                        image: Image.asset('Assets/Images/Orion/hopital.jpg'),
                        balance: {
                          "virtuel_CDF": "CDF: 100",
                          "virtuel_USD": "USD: 200",
                          "cash_CDF": "CDF: 300",
                          "cash_USD": "USD: 400"
                        },
                        subtitle:
                            "Commandez et Beneficiez des soins medicaux de qualites avec un personnel hotement qualifiez ici ",
                        title2: 'Compte 990268381 - Destin Kabote',
                        title3: '',
                        subtitle1: 'Soldes Cash',
                        subtitle2: 'Soldes Virtuel',
                        page: GestionEquityPage(),
                        iconColor: AppColors.kGreyColor,
                        titleColor: AppColors.kBlackColor,
                        subtitleColor: AppColors.kBlackColor),
                  ]),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 0),
            child: Container(
              padding: EdgeInsets.zero,
              // child: Column(
              //     crossAxisAlignment: CrossAxisAlignment.start,
              //     children: [
              //       TextWidgets.text300(
              //           title:
              //               'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
              //           fontSize: 16,
              //           textColor: AppColors.kWhiteColor),
              //       const SizedBox(height: 10),
              //       TextWidgets.text300(
              //           title:
              //               'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
              //           fontSize: 16,
              //           textColor: AppColors.kWhiteColor),
              //       const SizedBox(height: 10),
              //       TextWidgets.text300(
              //           title:
              //               'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
              //           fontSize: 16,
              //           textColor: AppColors.kWhiteColor),
              //     ]),
            ),
          )
        ],
      ),
    );
  }

  sliderWidget({
    required Function onChange,
    required double value,
    required double min,
    required double max,
    required int division,
  }) {
    return Slider(
      activeColor: AppColors.kYellowColor.withOpacity(1),
      inactiveColor: AppColors.kGreyColor.withOpacity(0.1),
      value: value,
      label: '$value',
      mouseCursor: MouseCursor.defer,
      thumbColor: AppColors.kBlackColor,
      divisions: division,
      min: min,
      max: max,
      onChanged: (value) {
        onChange(value);
      },
    );
  }
}
