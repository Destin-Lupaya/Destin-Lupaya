import 'package:orion/Resources/AppStateProvider/menu_state_provider.dart';
import 'package:orion/Resources/AppStateProvider/user_stateprovider.dart';
import 'package:orion/Resources/Components/applogo.dart';
import 'package:orion/Resources/Components/texts.dart';
import 'package:orion/Resources/responsive.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

import '../../Resources/global_variables.dart';

class MenuWidget extends StatefulWidget {
  const MenuWidget({Key? key}) : super(key: key);

  @override
  _MenuWidgetState createState() => _MenuWidgetState();
}

class _MenuWidgetState extends State<MenuWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
        color: AppColors.kBlackColor,
        padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 0),
        child: Consumer<MenuStateProvider>(
            builder: (context, menuStateProvider, child) {
          return Column(
            children: [
              const SizedBox(height: 20),
              Consumer<UserStateProvider>(
                  builder: (context, userStateProvider, _) {
                return Card(
                  color: AppColors.kBlackColor.withOpacity(0.5),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(kDefaultPadding / 2)),
                  child: Container(
                    alignment: Alignment.center,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 10),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Center(
                          child: Container(
                            width: 90,
                            height: 90,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(1000),
                                border: Border.all(
                                  color: AppColors.kWhiteColor,
                                  width: 2,
                                )),
                            child: Stack(
                              children: [
                                const AppLogo(
                                  size: Size(80, 80),
                                ),
                                Positioned(
                                  left: 0,
                                  right: 0,
                                  bottom: 0,
                                  child: Center(
                                    child: Container(
                                      padding: const EdgeInsets.all(8),
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: AppColors.kBlackColor
                                            .withOpacity(0.5),
                                      ),
                                      child: Icon(Icons.camera_alt,
                                          color: AppColors.kYellowColor),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        TextWidgets.textBold(
                            title: userStateProvider.clientData != null
                                ? '${userStateProvider.clientData!.fname} ${userStateProvider.clientData!.lname}'
                                : 'Orion',
                            fontSize: 16,
                            textColor: AppColors.kWhiteColor),
                        const SizedBox(
                          height: 10,
                        ),
                        TextWidgets.text300(
                            title: userStateProvider.clientData != null
                                ? '${userStateProvider.clientData!.telephone ?? userStateProvider.clientData!.email}'
                                : 'contact@orion.org',
                            fontSize: 12,
                            textColor: AppColors.kWhiteColor),
                      ],
                    ),
                  ),
                );
              }),
              Expanded(
                child: ListView.builder(
                    padding: EdgeInsets.zero,
                    itemCount: menuStateProvider.menu.length,
                    itemBuilder: (context, int index) {
                      return MenuItem(
                          title: menuStateProvider.menu[index].title,
                          icon: menuStateProvider.menu[index].icon,
                          textColor: AppColors.kBlackLightColor,
                          hoverColor: AppColors.kYellowColor,
                          backColor: Colors.white);
                    }),
              ),
            ],
          );
        }));
  }
}

class MenuItem extends StatefulWidget {
  final String title;
  final IconData icon;
  Color textColor;
  Color hoverColor;
  Color backColor;
  MenuItem(
      {required this.title,
      required this.icon,
      required this.backColor,
      required this.hoverColor,
      required this.textColor});

  @override
  _MenuItemState createState() => _MenuItemState();
}

class _MenuItemState extends State<MenuItem> {
  bool isButtonHovered = false;
  @override
  Widget build(BuildContext context) {
    return Consumer<MenuStateProvider>(
        builder: (context, menuStateProvider, child) {
      return GestureDetector(
        onTap: () {
          if (!Responsive.isWeb(context)) {
            Navigator.pop(context);
          }
          if (menuStateProvider.currentMenu == widget.title) {
            return;
          }
          menuStateProvider.changeMenu(newMenuValue: widget.title);
        },
        child: MouseRegion(
          // cursor: MouseCursor.,
          onHover: (value) => setState(() {
            isButtonHovered = true;
          }),
          onEnter: (value) => setState(() {
            isButtonHovered = true;
          }),
          onExit: (value) => setState(() {
            isButtonHovered = false;
          }),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 5),
            decoration: BoxDecoration(
              color: menuStateProvider.currentMenu == widget.title
                  ? AppColors.kWhiteColor.withOpacity(0.10)
                  : widget.backColor,
              borderRadius:
                  BorderRadius.circular(!Responsive.isWeb(context) ? 0 : 10),
            ),
            // menuStateProvider.currentMenu == widget.title || isButtonHovered
            //     ? widget.textColor
            //     : widget.backColor,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      !Responsive.isWeb(context)
                          ? Icon(
                              widget.icon,
                              color: menuStateProvider.currentMenu ==
                                          widget.title ||
                                      isButtonHovered
                                  ? widget.hoverColor
                                  : widget.textColor,
                            )
                          : Container(),
                      !Responsive.isWeb(context)
                          ? const SizedBox(width: 16.0)
                          : Container(),
                      Container(
                          padding: EdgeInsets.zero,
                          child: Text(
                            widget.title,
                            style: TextStyle(
                                color: menuStateProvider.currentMenu ==
                                            widget.title ||
                                        isButtonHovered
                                    ? widget.hoverColor
                                    : widget.textColor,
                                fontSize: 14,
                                fontWeight: FontWeight.bold),
                          ))
                    ],
                  ),
                ),
                !Responsive.isWeb(context)
                    ? const Divider(
                        height: 2,
                        color: Colors.black45,
                        thickness: 1,
                      )
                    : Container()
              ],
            ),
          ),
        ),
      );
    });
  }
}
