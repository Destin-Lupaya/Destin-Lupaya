import 'package:orion/Resources/AppStateProvider/app_stateprovider.dart';
import 'package:orion/Resources/AppStateProvider/user_stateprovider.dart';
import 'package:orion/Resources/Components/button.dart';
import 'package:orion/Resources/Components/card.dart';
import 'package:orion/Resources/Components/dropdown_button.dart';
import 'package:orion/Resources/Components/empty_model.dart';
import 'package:orion/Resources/Components/modal_progress.dart';
import 'package:orion/Resources/Components/text_fields.dart';
import 'package:orion/Resources/Components/texts.dart';
import 'package:orion/Resources/Models/client_model.dart';
import 'package:orion/Resources/global_variables.dart';
import 'package:orion/Resources/responsive.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class PersonalInfoPage extends StatefulWidget {
  const PersonalInfoPage({Key? key}) : super(key: key);

  @override
  _PersonalInfoPageState createState() => _PersonalInfoPageState();
}

class _PersonalInfoPageState extends State<PersonalInfoPage> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<UserStateProvider>(
        builder: (context, userStateProvider, child) {
      return userStateProvider.personalInfoUser != null
          ? Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: TextWidgets.textWithLabel(
                          title: 'Nom',
                          fontSize: 14,
                          textColor: AppColors.kWhiteColor,
                          value:
                              userStateProvider.personalInfoUser!.fname.trim()),
                    ),
                    Expanded(
                      child: TextWidgets.textWithLabel(
                          title: 'Post-nom',
                          fontSize: 14,
                          textColor: AppColors.kWhiteColor,
                          value:
                              userStateProvider.personalInfoUser!.lname.trim()),
                    ),
                    Expanded(
                        child: TextWidgets.textWithLabel(
                            title: 'Prenom',
                            fontSize: 14,
                            textColor: AppColors.kWhiteColor,
                            value: userStateProvider.personalInfoUser!.pname !=
                                        'null' &&
                                    userStateProvider.personalInfoUser!.pname !=
                                        null
                                ? userStateProvider.personalInfoUser!.pname!
                                : '')),
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: TextWidgets.textWithLabel(
                          title: 'Date de naissance',
                          fontSize: 14,
                          textColor: AppColors.kWhiteColor,
                          value: userStateProvider.personalInfoUser!.dob !=
                                      'null' &&
                                  userStateProvider.personalInfoUser!.dob !=
                                      null
                              ? userStateProvider.personalInfoUser!.dob!
                              : ''),
                      //userStateProvider.personalInfoUser!.dob!.trim()),
                    ),
                    Expanded(
                      child: TextWidgets.textWithLabel(
                          title: 'Sexe',
                          fontSize: 14,
                          textColor: AppColors.kWhiteColor,
                          value: userStateProvider.personalInfoUser!.genre !=
                                      'null' &&
                                  userStateProvider.personalInfoUser!.genre !=
                                      null
                              ? userStateProvider.personalInfoUser!.genre!
                              : ''),
                    ),
                    Expanded(
                        child: TextWidgets.textWithLabel(
                            title: 'Etat civil',
                            fontSize: 14,
                            textColor: AppColors.kWhiteColor,
                            value: userStateProvider
                                            .personalInfoUser!.marriagestatus !=
                                        'null' &&
                                    userStateProvider
                                            .personalInfoUser!.marriagestatus !=
                                        null
                                ? userStateProvider
                                    .personalInfoUser!.marriagestatus!
                                : '')),
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                        child: TextWidgets.textWithLabel(
                            title: 'Pays de residence',
                            fontSize: 14,
                            textColor: AppColors.kWhiteColor,
                            value: userStateProvider
                                            .personalInfoUser!.country !=
                                        'null' &&
                                    userStateProvider
                                            .personalInfoUser!.country !=
                                        null
                                ? userStateProvider.personalInfoUser!.country!
                                : '')),
                    Expanded(
                        child: TextWidgets.textWithLabel(
                            title: 'Adresse',
                            fontSize: 14,
                            textColor: AppColors.kWhiteColor,
                            value: userStateProvider
                                            .personalInfoUser!.address !=
                                        'null' &&
                                    userStateProvider
                                            .personalInfoUser!.address !=
                                        null
                                ? userStateProvider.personalInfoUser!.address!
                                : '')),
                    Expanded(child: Container())
                  ],
                ),
              ],
            )
          : EmptyModel(color: AppColors.kGreyColor);
    });
  }
}

class AddPersonalInfo extends StatefulWidget {
  const AddPersonalInfo({Key? key}) : super(key: key);

  @override
  _AddPersonalInfoState createState() => _AddPersonalInfoState();
}

class _AddPersonalInfoState extends State<AddPersonalInfo> {
  final TextEditingController _nomCtrller = TextEditingController();
  final TextEditingController _postnomCtrller = TextEditingController();
  final TextEditingController _prenomCtrller = TextEditingController();
  final TextEditingController _dateNaissCtrller = TextEditingController();
  final TextEditingController _paysCtrller = TextEditingController();
  final TextEditingController _adresseCtrller = TextEditingController();
  final TextEditingController _phoneCtrller = TextEditingController();
  final TextEditingController _emailCtrller = TextEditingController();
  String gender = "male";
  String maritalStatus = "Célibataire";
  String role = "";

  @override
  void initState() {
    super.initState();
    _nomCtrller.text = Provider.of<UserStateProvider>(context, listen: false)
        .clientData!
        .fname;
    _postnomCtrller.text =
        Provider.of<UserStateProvider>(context, listen: false)
            .clientData!
            .lname;
    _prenomCtrller.text = Provider.of<UserStateProvider>(context, listen: false)
            .clientData!
            .pname ??
        '';
    _dateNaissCtrller.text =
        Provider.of<UserStateProvider>(context, listen: false)
                .clientData!
                .dob ??
            '';
    _paysCtrller.text = Provider.of<UserStateProvider>(context, listen: false)
            .clientData!
            .country ??
        '';
    _adresseCtrller.text =
        Provider.of<UserStateProvider>(context, listen: false)
                .clientData!
                .address ??
            '';
    gender = Provider.of<UserStateProvider>(context, listen: false)
        .clientData!
        .genre!
        .toUpperCase();

    _phoneCtrller.text = Provider.of<UserStateProvider>(context, listen: false)
            .clientData!
            .telephone ??
        '';
    _emailCtrller.text = Provider.of<UserStateProvider>(context, listen: false)
            .clientData!
            .email ??
        '';
    role =
        Provider.of<UserStateProvider>(context, listen: false).clientData!.role;
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AppStateProvider>(builder: (context, appStateProvider, _) {
      return Material(
        color: AppColors.kTransparentColor,
        child: Container(
          // padding: const EdgeInsets.symmetric(horizontal: 10),
          width: Responsive.isMobile(context)
              ? MediaQuery.of(context).size.width
              : MediaQuery.of(context).size.width / 2,
          height: MediaQuery.of(context).size.height * .85,
          child: ModalProgress(
            progressColor: AppColors.kYellowColor,
            isAsync: appStateProvider.isAsync,
            child: ListView(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              children: [
                CardWidget(
                    backColor: AppColors.kBlackLightColor,
                    title: 'Informations personnelles',
                    content: Column(
                      children: [
                        TextFormFieldWidget(
                            backColor: AppColors.kTextFormBackColor,
                            hintText: 'Nom',
                            editCtrller: _nomCtrller,
                            textColor: AppColors.kWhiteColor,
                            maxLines: 1),
                        TextFormFieldWidget(
                            backColor: AppColors.kTextFormBackColor,
                            hintText: 'Post-nom',
                            editCtrller: _postnomCtrller,
                            textColor: AppColors.kWhiteColor,
                            maxLines: 1),
                        TextFormFieldWidget(
                            backColor: AppColors.kTextFormBackColor,
                            hintText: 'Prenom',
                            editCtrller: _prenomCtrller,
                            textColor: AppColors.kWhiteColor,
                            maxLines: 1),
                        GestureDetector(
                          child: TextFormFieldWidget(
                              backColor: AppColors.kTextFormBackColor,
                              hintText: 'Date de naissance',
                              isEnabled: false,
                              isObsCured: false,
                              editCtrller: _dateNaissCtrller,
                              textColor: AppColors.kWhiteColor,
                              maxLines: 1),
                          onTap: () async {
                            var picked = await showDatePicker(
                                context: context,
                                initialDate: DateTime.now()
                                    .subtract(const Duration(days: 365 * 100)),
                                firstDate: DateTime.now()
                                    .subtract(const Duration(days: 365 * 100)),
                                lastDate: DateTime.now()
                                    .subtract(const Duration(days: 365 * 18)));
                            if (picked == null) return;
                            _dateNaissCtrller.text =
                                picked.toString().substring(0, 10);
                            setState(() {});
                          },
                        ),
                        CustomDropdownButton(
                            value: gender,
                            hintText: 'Sexe',
                            callBack: (value) {},
                            items: const ["MALE", "FEMALE"]),
                        CustomDropdownButton(
                            value: maritalStatus,
                            hintText: 'Statut marital',
                            callBack: (value) {},
                            items: const [
                              "Célibataire",
                              "Marié(e)",
                              "De facto",
                              "Divorcée",
                              "Veuf(ve)"
                            ]),
                        TextFormFieldWidget(
                            backColor: AppColors.kTextFormBackColor,
                            hintText: 'Phone',
                            editCtrller: _phoneCtrller,
                            textColor: AppColors.kWhiteColor,
                            maxLines: 1),
                        TextFormFieldWidget(
                            backColor: AppColors.kTextFormBackColor,
                            hintText: 'E-mail',
                            editCtrller: _emailCtrller,
                            textColor: AppColors.kWhiteColor,
                            maxLines: 1),
                        TextFormFieldWidget(
                            backColor: AppColors.kTextFormBackColor,
                            hintText: 'Pays de residence',
                            editCtrller: _paysCtrller,
                            textColor: AppColors.kWhiteColor,
                            maxLines: 1),
                        TextFormFieldWidget(
                            backColor: AppColors.kTextFormBackColor,
                            hintText: 'Adresse de residence',
                            editCtrller: _adresseCtrller,
                            textColor: AppColors.kWhiteColor,
                            maxLines: 1),
                        Consumer<UserStateProvider>(
                            builder: (context, userStateProvider, _) {
                          return CustomButton(
                            text: 'Enregistrer',
                            textColor: AppColors.kBlackColor,
                            backColor: AppColors.kYellowColor,
                            callback: () {
                              Map userData = {
                                "userID": "0",
                                "id":
                                    userStateProvider.userId.toString().trim(),
                                "fname": _nomCtrller.text.trim().toUpperCase(),
                                "lname":
                                    _postnomCtrller.text.trim().toUpperCase(),
                                "pname":
                                    _prenomCtrller.text.trim().toUpperCase(),
                                "dob": _dateNaissCtrller.text.trim(),
                                "country":
                                    _paysCtrller.text.trim().toUpperCase(),
                                "address":
                                    _adresseCtrller.text.trim().toUpperCase(),
                                "genre": gender.trim(),
                                "marriagestatus": maritalStatus.trim(),
                                "telephone":
                                    _phoneCtrller.text.trim().toUpperCase(),
                                "email":
                                    _emailCtrller.text.trim().toLowerCase(),
                                "role": role,
                              };
                              // print(userData);
                              userStateProvider.addPersonalInfo(
                                  context: context,
                                  personalInfo: ClientModel.fromJson(userData),
                                  callback: () {
                                    Navigator.pop(context);
                                  });
                            },
                          );
                        })
                      ],
                    )),
              ],
            ),
          ),
        ),
      );
    });
  }
}
