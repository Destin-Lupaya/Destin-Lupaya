// import 'package:andema/Resources/AppStateProvider/app_stateprovider.dart';
// import 'package:andema/Resources/AppStateProvider/user_stateprovider.dart';
// import 'package:andema/Resources/Components/button.dart';
// import 'package:andema/Resources/Components/card.dart';
// import 'package:andema/Resources/Components/empty_model.dart';
// import 'package:andema/Resources/Components/modal_progress.dart';
// import 'package:andema/Resources/Components/text_fields.dart';
// import 'package:andema/Resources/Components/texts.dart';
// import 'package:andema/Resources/Models/nominated_admin.model.dart';
// import 'package:andema/Resources/global_variables.dart';
// import 'package:andema/Resources/responsive.dart';
// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';

// class AddNamedAdminPage extends StatelessWidget {
//   final TextEditingController _nomCtrller = TextEditingController(),
//       _relationCtrller = TextEditingController(),
//       _adresseCtrller = TextEditingController(),
//       _contactCtrller = TextEditingController(),
//       _emailCtrller = TextEditingController(),
//       _bankAccountNameCtrller = TextEditingController(),
//       _bankAccountNumberCtrller = TextEditingController();
//   AddNamedAdminPage({Key? key}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Consumer<AppStateProvider>(builder: (context, appStateProvider, _) {
//       return Material(
//         color: AppColors.kTransparentColor,
//         child: Container(
//           // padding: const EdgeInsets.symmetric(horizontal: 10),
//           width: Responsive.isMobile(context)
//               ? MediaQuery.of(context).size.width
//               : MediaQuery.of(context).size.width / 2,
//           height: MediaQuery.of(context).size.height * .85,
//           // color: AppColors.kBlackLightColor,
//           child: ModalProgress(
//             progressColor: AppColors.kYellowColor,
//             isAsync: appStateProvider.isAsync,
//             child: ListView(
//               shrinkWrap: true,
//               children: [
//                 CardWidget(
//                     backColor: AppColors.kBlackLightColor,
//                     title: 'Ajouter un administrateur nommé',
//                     content: Column(
//                       children: [
//                         TextFormFieldWidget(
//                             backColor: AppColors.kTextFormBackColor,
//                             hintText: 'Nom',
//                             editCtrller: _nomCtrller,
//                             textColor: AppColors.kWhiteColor,
//                             maxLines: 1),
//                         TextFormFieldWidget(
//                             backColor: AppColors.kTextFormBackColor,
//                             hintText: 'Relation',
//                             editCtrller: _relationCtrller,
//                             textColor: AppColors.kWhiteColor,
//                             maxLines: 1),
//                         TextFormFieldWidget(
//                             backColor: AppColors.kTextFormBackColor,
//                             hintText: 'Adresse',
//                             editCtrller: _adresseCtrller,
//                             textColor: AppColors.kWhiteColor,
//                             maxLines: 1),
//                         TextFormFieldWidget(
//                             backColor: AppColors.kTextFormBackColor,
//                             hintText: 'No telephone',
//                             editCtrller: _contactCtrller,
//                             textColor: AppColors.kWhiteColor,
//                             maxLines: 1),
//                         TextFormFieldWidget(
//                             backColor: AppColors.kTextFormBackColor,
//                             hintText: 'E-mail',
//                             editCtrller: _emailCtrller,
//                             textColor: AppColors.kWhiteColor,
//                             maxLines: 1),
//                         TextFormFieldWidget(
//                             backColor: AppColors.kTextFormBackColor,
//                             hintText: 'Nom du compte bancaire',
//                             editCtrller: _bankAccountNameCtrller,
//                             textColor: AppColors.kWhiteColor,
//                             maxLines: 1),
//                         TextFormFieldWidget(
//                             backColor: AppColors.kTextFormBackColor,
//                             hintText: 'Numero du compte bancaire',
//                             editCtrller: _bankAccountNumberCtrller,
//                             textColor: AppColors.kWhiteColor,
//                             maxLines: 1),
//                         Consumer<UserStateProvider>(
//                             builder: (context, userStateProvider, _) {
//                           return CustomButton(
//                             backColor: AppColors.kYellowColor,
//                             text: 'Enregistrer',
//                             textColor: AppColors.kBlackColor,
//                             callback: () {
//                               Map data = {
//                                 "nom": _nomCtrller.text.trim().toUpperCase(),
//                                 "relation":
//                                     _relationCtrller.text.trim().toUpperCase(),
//                                 "adresse":
//                                     _adresseCtrller.text.trim().toUpperCase(),
//                                 "contact":
//                                     _contactCtrller.text.trim().toUpperCase(),
//                                 "email":
//                                     _emailCtrller.text.trim().toUpperCase(),
//                                 "bankAccountName": _bankAccountNameCtrller.text
//                                     .trim()
//                                     .toUpperCase(),
//                                 "bankAccountNumber": _bankAccountNumberCtrller
//                                     .text
//                                     .trim()
//                                     .toUpperCase(),
//                               };
//                               userStateProvider.addNominatedAdminInfo(
//                                   context: context,
//                                   nominatedAdmin:
//                                       NominatedPersonModel.fromJson(data),
//                                   callback: () {
//                                     Navigator.pop(context);
//                                   });
//                             },
//                           );
//                         })
//                       ],
//                     ))
//               ],
//             ),
//           ),
//         ),
//       );
//     });
//   }
// }

// class NominatedAdminPage extends StatelessWidget {
//   const NominatedAdminPage({Key? key}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Consumer<UserStateProvider>(
//       builder: (context, userStateProvider, _) {
//         return userStateProvider.nominatedAdminData.isNotEmpty
//             ? Column(
//                 children: [
//                   Container(
//                     padding:
//                         const EdgeInsets.symmetric(horizontal: 5, vertical: 10),
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                       children: [
//                         Expanded(
//                           flex: 3,
//                           child: TextWidgets.text300(
//                               title: 'Nom',
//                               fontSize: 14,
//                               textColor: AppColors.kWhiteColor),
//                         ),
//                         Expanded(
//                           flex: 1,
//                           child: TextWidgets.text300(
//                               title: 'Relation',
//                               fontSize: 14,
//                               textColor: AppColors.kWhiteColor),
//                         ),
//                         Expanded(
//                           flex: 3,
//                           child: TextWidgets.text300(
//                               title: 'Adresse',
//                               fontSize: 14,
//                               textColor: AppColors.kWhiteColor),
//                         ),
//                         Expanded(
//                           flex: 2,
//                           child: TextWidgets.text300(
//                               title: 'Phone',
//                               fontSize: 14,
//                               textColor: AppColors.kWhiteColor),
//                         ),
//                         Expanded(
//                           flex: 3,
//                           child: TextWidgets.text300(
//                               title: 'Email',
//                               fontSize: 14,
//                               textColor: AppColors.kWhiteColor),
//                         )
//                       ],
//                     ),
//                   ),
//                   ListView.builder(itemBuilder: (context, int index) {
//                     return Container(
//                       padding: const EdgeInsets.symmetric(
//                           horizontal: 5, vertical: 10),
//                       child: Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                         children: [
//                           Expanded(
//                             flex: 3,
//                             child: TextWidgets.text300(
//                                 title: userStateProvider
//                                     .nominatedAdminData[index].nom
//                                     .trim(),
//                                 fontSize: 14,
//                                 textColor: AppColors.kWhiteColor),
//                           ),
//                           Expanded(
//                             flex: 1,
//                             child: TextWidgets.text300(
//                                 title: userStateProvider
//                                     .nominatedAdminData[index].relation
//                                     .trim(),
//                                 fontSize: 14,
//                                 textColor: AppColors.kWhiteColor),
//                           ),
//                           Expanded(
//                             flex: 3,
//                             child: TextWidgets.text300(
//                                 title: userStateProvider
//                                     .nominatedAdminData[index].adresse
//                                     .trim(),
//                                 fontSize: 14,
//                                 textColor: AppColors.kWhiteColor),
//                           ),
//                           Expanded(
//                             flex: 2,
//                             child: TextWidgets.text300(
//                                 title: userStateProvider
//                                     .nominatedAdminData[index].contact
//                                     .trim(),
//                                 fontSize: 14,
//                                 textColor: AppColors.kWhiteColor),
//                           ),
//                           Expanded(
//                             flex: 3,
//                             child: TextWidgets.text300(
//                                 title: userStateProvider
//                                     .nominatedAdminData[index].email!
//                                     .trim(),
//                                 fontSize: 14,
//                                 textColor: AppColors.kWhiteColor),
//                           )
//                         ],
//                       ),
//                     );
//                   })
//                 ],
//               )
//             : EmptyModel(color: AppColors.kGreyColor);
//       },
//     );
//   }
// }
