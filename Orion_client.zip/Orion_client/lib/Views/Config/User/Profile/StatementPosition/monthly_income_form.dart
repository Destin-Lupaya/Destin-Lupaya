import 'package:orion/Resources/AppStateProvider/app_stateprovider.dart';
import 'package:orion/Resources/AppStateProvider/user_stateprovider.dart';
import 'package:orion/Resources/Components/button.dart';
import 'package:orion/Resources/Components/card.dart';
import 'package:orion/Resources/Components/dropdown_button.dart';
import 'package:orion/Resources/Components/modal_progress.dart';
import 'package:orion/Resources/Components/text_fields.dart';
import 'package:orion/Resources/Models/statement_position.model.dart';
import 'package:orion/Resources/global_variables.dart';
import 'package:orion/Resources/responsive.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AddIncomePage extends StatefulWidget {
  final bool updatingData;
  final StatementPositionModel? statement;
  AddIncomePage({Key? key, required this.updatingData, this.statement})
      : super(key: key);

  @override
  State<AddIncomePage> createState() => _AddIncomePageState();
}

class _AddIncomePageState extends State<AddIncomePage> {
  final TextEditingController _priceCtrller = TextEditingController(),
      _detailsCtrller = TextEditingController();

  String type = "Salaire";
  @override
  void initState() {
    super.initState();
    if (widget.updatingData == true) {
      _priceCtrller.text = widget.statement!.montant.toString().trim();
      _detailsCtrller.text = widget.statement!.description.toString().trim();
      type = widget.statement!.type.toString().trim();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.kTransparentColor,
      child: Container(
          // padding: const EdgeInsets.symmetric(horizontal: 10),
          width: Responsive.isMobile(context)
              ? MediaQuery.of(context).size.width
              : MediaQuery.of(context).size.width / 2,
          height: MediaQuery.of(context).size.height * .85,
          // color: AppColors.kBlackLightColor,
          child: Consumer<AppStateProvider>(
              builder: (context, appStateProvider, child) {
            return ModalProgress(
              isAsync: appStateProvider.isAsync,
              progressColor: AppColors.kYellowColor,
              child: ListView(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  CardWidget(
                      backColor: AppColors.kBlackLightColor,
                      title: 'Ajouter dans les revenus mensuels',
                      content: Column(
                        children: [
                          CustomDropdownButton(
                              value: type,
                              hintText: 'Type de possession',
                              callBack: (value) {
                                type = value;
                                setState(() {});
                              },
                              items: const ["Salaire", "Dons", "Autres"]),
                          TextFormFieldWidget(
                              backColor: AppColors.kTextFormBackColor,
                              hintText: 'Details (besoins a satisfaire)',
                              editCtrller: _detailsCtrller,
                              textColor: AppColors.kWhiteColor,
                              maxLines: 1),
                          TextFormFieldWidget(
                              backColor: AppColors.kTextFormBackColor,
                              hintText: 'Montant',
                              editCtrller: _priceCtrller,
                              inputType: TextInputType.number,
                              textColor: AppColors.kWhiteColor,
                              maxLines: 1),
                          Consumer<UserStateProvider>(
                              builder: (context, userStateProvider, _) {
                            return CustomButton(
                              backColor: AppColors.kYellowColor,
                              text: 'Enregistrer',
                              textColor: AppColors.kBlackColor,
                              callback: () {
                                Map data = {
                                  "id": widget.updatingData == true
                                      ? widget.statement!.id!.toString()
                                      : "0",
                                  'type': type.trim(),
                                  'category': 'Income',
                                  'description': _detailsCtrller.text.trim(),
                                  'montant': _priceCtrller.text.trim(),
                                  'users_id': Provider.of<UserStateProvider>(
                                          context,
                                          listen: false)
                                      .userId,
                                };
                                userStateProvider.addStatementPosition(
                                    context: context,
                                    updatingData: widget.updatingData,
                                    statementPosition:
                                        StatementPositionModel.fromJson(data),
                                    callback: () {
                                      Navigator.pop(context);
                                    });
                              },
                            );
                          })
                        ],
                      ))
                ],
              ),
            );
          })),
    );
  }
}
