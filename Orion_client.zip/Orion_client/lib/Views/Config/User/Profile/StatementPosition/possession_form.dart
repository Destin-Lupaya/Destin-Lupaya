import 'package:orion/Resources/AppStateProvider/app_stateprovider.dart';
import 'package:orion/Resources/AppStateProvider/user_stateprovider.dart';
import 'package:orion/Resources/Components/button.dart';
import 'package:orion/Resources/Components/card.dart';
import 'package:orion/Resources/Components/dropdown_button.dart';
import 'package:orion/Resources/Components/modal_progress.dart';
import 'package:orion/Resources/Components/text_fields.dart';
import 'package:orion/Resources/Models/statement_position.model.dart';
import 'package:orion/Resources/global_variables.dart';
import 'package:orion/Resources/responsive.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AddPossessionPage extends StatefulWidget {
  final bool updatingData;
  final StatementPositionModel? statement;
  AddPossessionPage({Key? key, required this.updatingData, this.statement})
      : super(key: key);

  @override
  State<AddPossessionPage> createState() => _AddPossessionPageState();
}

class _AddPossessionPageState extends State<AddPossessionPage> {
  final TextEditingController _priceCtrller = TextEditingController(),
      _detailsCtrller = TextEditingController(),
      _dateCtrller = TextEditingController();

  String type = "Maison";
  @override
  void initState() {
    super.initState();
    if (widget.updatingData == true) {
      _priceCtrller.text = widget.statement!.montant.toString().trim();
      _detailsCtrller.text = widget.statement!.description.toString().trim();
      type = widget.statement!.type.toString().trim();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.kTransparentColor,
      child: Container(
          // padding: const EdgeInsets.symmetric(horizontal: 10),
          width: Responsive.isMobile(context)
              ? MediaQuery.of(context).size.width
              : MediaQuery.of(context).size.width / 2,
          height: MediaQuery.of(context).size.height * .85,
          // color: AppColors.kBlackLightColor,
          child: Consumer<AppStateProvider>(
              builder: (context, appStateProvider, child) {
            return ModalProgress(
              isAsync: appStateProvider.isAsync,
              progressColor: AppColors.kYellowColor,
              child: ListView(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  CardWidget(
                      backColor: AppColors.kBlackLightColor,
                      title: 'Ajouter les possessions',
                      content: Column(
                        children: [
                          CustomDropdownButton(
                              value: type,
                              hintText: 'Type de possession',
                              callBack: (value) {
                                type = value;
                                setState(() {});
                              },
                              items: const [
                                "Maison",
                                "Voiture",
                                "Marchandises",
                                "Compte bancaire",
                                "Autres"
                              ]),
                          TextFormFieldWidget(
                              backColor: AppColors.kTextFormWhiteColor,
                              hintText:
                                  'Details (Adresse ou Marque-model-plaque ou Numero du compte)',
                              editCtrller: _detailsCtrller,
                              textColor: AppColors.kWhiteColor,
                              maxLines: 1),
                          TextFormFieldWidget(
                              backColor: AppColors.kTextFormWhiteColor,
                              hintText: 'Prix estimé',
                              editCtrller: _priceCtrller,
                              inputType: TextInputType.number,
                              textColor: AppColors.kWhiteColor,
                              maxLines: 1),
                          GestureDetector(
                            child: TextFormFieldWidget(
                                backColor: AppColors.kTextFormBackColor,
                                hintText: 'Date d\'acquisition',
                                isEnabled: false,
                                isObsCured: false,
                                editCtrller: _dateCtrller,
                                textColor: AppColors.kWhiteColor,
                                maxLines: 1),
                            onTap: () async {
                              var picked = await showDatePicker(
                                  context: context,
                                  initialDate: DateTime.now()
                                      .subtract(const Duration(days: 365 * 20)),
                                  firstDate: DateTime.now()
                                      .subtract(const Duration(days: 365 * 20)),
                                  lastDate: DateTime.now());
                              if (picked == null) return;
                              _dateCtrller.text =
                                  picked.toString().substring(0, 10);
                              setState(() {});
                            },
                          ),
                          Consumer<UserStateProvider>(
                              builder: (context, userStateProvider, _) {
                            return CustomButton(
                              backColor: AppColors.kYellowColor,
                              text: 'Enregistrer',
                              textColor: AppColors.kBlackColor,
                              callback: () {
                                Map data = {
                                  "id": widget.updatingData == true
                                      ? widget.statement!.id!.toString()
                                      : "0",
                                  'type': type.trim(),
                                  'category': 'Possession',
                                  'description': _detailsCtrller.text.trim(),
                                  'montant': _priceCtrller.text.trim(),
                                  'startDate': _dateCtrller.text.trim(),
                                  'users_id': Provider.of<UserStateProvider>(
                                          context,
                                          listen: false)
                                      .userId,
                                };
                                userStateProvider.addStatementPosition(
                                    context: context,
                                    updatingData: widget.updatingData,
                                    statementPosition:
                                        StatementPositionModel.fromJson(data),
                                    callback: () {
                                      Navigator.pop(context);
                                    });
                              },
                            );
                          })
                        ],
                      ))
                ],
              ),
            );
          })),
    );
  }
}
