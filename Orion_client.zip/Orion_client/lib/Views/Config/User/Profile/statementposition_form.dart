import 'package:orion/Resources/AppStateProvider/user_stateprovider.dart';
import 'package:orion/Resources/Components/empty_model.dart';
import 'package:orion/Resources/Components/texts.dart';
import 'package:orion/Resources/global_variables.dart';
import 'package:orion/Views/Config/User/Profile/StatementPosition/debts_form.dart';
import 'package:orion/Views/Config/User/Profile/StatementPosition/monthly_expenses_form.dart';
import 'package:orion/Views/Config/User/Profile/StatementPosition/monthly_income_form.dart';
import 'package:orion/Views/Config/User/Profile/StatementPosition/possession_form.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class StatementPositionPage extends StatelessWidget {
  final String category;
  const StatementPositionPage({Key? key, required this.category})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    // return Container();
    return Consumer<UserStateProvider>(
      builder: (context, userStateProvider, child) {
        return userStateProvider.statementPositionData
                .where((statement) =>
                    statement.category.trim().toLowerCase() ==
                    category.trim().toLowerCase())
                .toList()
                .isNotEmpty
            ? Column(
                children: [
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          flex: 2,
                          child: TextWidgets.text300(
                              title: 'Type',
                              fontSize: 14,
                              textColor: AppColors.kWhiteColor),
                        ),
                        Expanded(
                          flex: 4,
                          child: TextWidgets.text300(
                              title: 'Details',
                              fontSize: 14,
                              textColor: AppColors.kWhiteColor),
                        ),
                        Expanded(
                          flex: 2,
                          child: TextWidgets.text300(
                              title: 'Montant',
                              fontSize: 14,
                              textColor: AppColors.kWhiteColor),
                        ),
                        Expanded(
                          flex: 2,
                          child: TextWidgets.text300(
                              title: 'Action',
                              fontSize: 14,
                              textColor: AppColors.kWhiteColor),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 10),
                    child: ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: userStateProvider.statementPositionData
                            .where((statement) =>
                                statement.category.trim().toLowerCase() ==
                                category.trim().toLowerCase())
                            .toList()
                            .length,
                        itemBuilder: (context, int index) {
                          return Column(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 5, vertical: 10),
                                color: index % 2 == 0
                                    ? AppColors.kWhiteColor.withOpacity(0.03)
                                    : AppColors.kTransparentColor,
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Expanded(
                                      flex: 2,
                                      child: TextWidgets.text300(
                                          title: userStateProvider
                                              .statementPositionData
                                              .where((statement) =>
                                                  statement.category
                                                      .trim()
                                                      .toLowerCase() ==
                                                  category.trim().toLowerCase())
                                              .toList()[index]
                                              .type
                                              .trim(),
                                          fontSize: 14,
                                          textColor: AppColors.kWhiteColor),
                                    ),
                                    Expanded(
                                      flex: 4,
                                      child: TextWidgets.text300(
                                          title: userStateProvider
                                              .statementPositionData
                                              .where((statement) =>
                                                  statement.category
                                                      .trim()
                                                      .toLowerCase() ==
                                                  category.trim().toLowerCase())
                                              .toList()[index]
                                              .description
                                              .trim(),
                                          fontSize: 14,
                                          textColor: AppColors.kWhiteColor),
                                    ),
                                    Expanded(
                                      flex: 2,
                                      child: TextWidgets.text300(
                                          title:
                                              "${userStateProvider.statementPositionData.where((statement) => statement.category.trim().toLowerCase() == category.trim().toLowerCase()).toList()[index].montant.toString().trim()}\$",
                                          fontSize: 14,
                                          textColor: AppColors.kWhiteColor),
                                    ),
                                    Expanded(
                                      flex: 2,
                                      child: Row(
                                        children: [
                                          GestureDetector(
                                            onTap: () {
                                              if (category
                                                      .trim()
                                                      .toLowerCase() ==
                                                  'liabilities') {
                                                showCupertinoModalPopup(
                                                    context: context,
                                                    builder: (context) {
                                                      return Center(
                                                        child: AddDebtPage(
                                                          updatingData: true,
                                                          statement: userStateProvider
                                                              .statementPositionData
                                                              .where((statement) =>
                                                                  statement
                                                                      .category
                                                                      .trim()
                                                                      .toLowerCase() ==
                                                                  category
                                                                      .trim()
                                                                      .toLowerCase())
                                                              .toList()[index],
                                                        ),
                                                      );
                                                    });
                                              }
                                              if (category
                                                      .trim()
                                                      .toLowerCase() ==
                                                  'possession') {
                                                showCupertinoModalPopup(
                                                    context: context,
                                                    builder: (context) {
                                                      return Center(
                                                        child:
                                                            AddPossessionPage(
                                                          updatingData: true,
                                                          statement: userStateProvider
                                                              .statementPositionData
                                                              .where((statement) =>
                                                                  statement
                                                                      .category
                                                                      .trim()
                                                                      .toLowerCase() ==
                                                                  category
                                                                      .trim()
                                                                      .toLowerCase())
                                                              .toList()[index],
                                                        ),
                                                      );
                                                    });
                                              }
                                              if (category
                                                      .trim()
                                                      .toLowerCase() ==
                                                  'income') {
                                                showCupertinoModalPopup(
                                                    context: context,
                                                    builder: (context) {
                                                      return Center(
                                                        child: AddIncomePage(
                                                          updatingData: true,
                                                          statement: userStateProvider
                                                              .statementPositionData
                                                              .where((statement) =>
                                                                  statement
                                                                      .category
                                                                      .trim()
                                                                      .toLowerCase() ==
                                                                  category
                                                                      .trim()
                                                                      .toLowerCase())
                                                              .toList()[index],
                                                        ),
                                                      );
                                                    });
                                              }
                                              if (category
                                                      .trim()
                                                      .toLowerCase() ==
                                                  'expenses') {
                                                showCupertinoModalPopup(
                                                    context: context,
                                                    builder: (context) {
                                                      return Center(
                                                        child:
                                                            AddMonthlyExpensesPage(
                                                          updatingData: true,
                                                          statement: userStateProvider
                                                              .statementPositionData
                                                              .where((statement) =>
                                                                  statement
                                                                      .category
                                                                      .trim()
                                                                      .toLowerCase() ==
                                                                  category
                                                                      .trim()
                                                                      .toLowerCase())
                                                              .toList()[index],
                                                        ),
                                                      );
                                                    });
                                              }
                                            },
                                            child: Icon(Icons.edit,
                                                color: AppColors.kGreenColor),
                                          ),
                                          const SizedBox(width: 10),
                                          GestureDetector(
                                            child: Icon(Icons.delete,
                                                color: AppColors.kRedColor),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Divider(
                                  height: 2,
                                  thickness: 1,
                                  color: AppColors.kWhiteColor.withOpacity(0.4))
                            ],
                          );
                        }),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextWidgets.text300(
                          title: "Total: ",
                          fontSize: 14,
                          textColor: AppColors.kWhiteColor),
                      TextWidgets.textBold(
                          title:
                              "${userStateProvider.sumData(data: userStateProvider.statementPositionData.where((statement) => statement.category.trim().toLowerCase() == category.trim().toLowerCase()).toList()).toString().trim()}\$",
                          fontSize: 14,
                          textColor: AppColors.kWhiteColor),
                    ],
                  )
                ],
              )
            : EmptyModel(color: AppColors.kGreyColor);
      },
    );
  }
}
