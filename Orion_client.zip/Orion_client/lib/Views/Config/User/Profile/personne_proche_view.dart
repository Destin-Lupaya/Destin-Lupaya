import 'package:orion/Resources/AppStateProvider/app_stateprovider.dart';
import 'package:orion/Resources/AppStateProvider/user_stateprovider.dart';
import 'package:orion/Resources/Components/button.dart';
import 'package:orion/Resources/Components/card.dart';
import 'package:orion/Resources/Components/empty_model.dart';
import 'package:orion/Resources/Components/modal_progress.dart';
import 'package:orion/Resources/Components/text_fields.dart';
import 'package:orion/Resources/Components/texts.dart';
import 'package:orion/Resources/Models/nearest_person.model.dart';
import 'package:orion/Resources/Models/payable_person.model.dart';
import 'package:orion/Resources/global_variables.dart';
import 'package:orion/Resources/responsive.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AddPersonneProchePage extends StatelessWidget {
  final TextEditingController _nomCtrller = TextEditingController(),
      _relationCtrller = TextEditingController(),
      _adresseCtrller = TextEditingController(),
      _contactCtrller = TextEditingController(),
      _emailCtrller = TextEditingController();
  AddPersonneProchePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<AppStateProvider>(builder: (context, appStateProvider, _) {
      return Material(
        color: AppColors.kTransparentColor,
        child: Container(
          // padding: const EdgeInsets.symmetric(horizontal: 10),
          width: Responsive.isMobile(context)
              ? MediaQuery.of(context).size.width
              : MediaQuery.of(context).size.width / 2,
          height: MediaQuery.of(context).size.height * .85,
          // color: AppColors.kBlackLightColor,
          child: ModalProgress(
            progressColor: AppColors.kYellowColor,
            isAsync: appStateProvider.isAsync,
            child: ListView(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              children: [
                CardWidget(
                    backColor: AppColors.kBlackLightColor,
                    title: 'Ajouter une personne proche',
                    content: Column(
                      children: [
                        TextFormFieldWidget(
                            backColor: AppColors.kTextFormBackColor,
                            hintText: 'Nom',
                            editCtrller: _nomCtrller,
                            textColor: AppColors.kWhiteColor,
                            maxLines: 1),
                        TextFormFieldWidget(
                            backColor: AppColors.kTextFormBackColor,
                            hintText: 'Relation',
                            editCtrller: _relationCtrller,
                            textColor: AppColors.kWhiteColor,
                            maxLines: 1),
                        TextFormFieldWidget(
                            backColor: AppColors.kTextFormBackColor,
                            hintText: 'Adresse',
                            editCtrller: _adresseCtrller,
                            textColor: AppColors.kWhiteColor,
                            maxLines: 1),
                        TextFormFieldWidget(
                            backColor: AppColors.kTextFormBackColor,
                            hintText: 'No telephone',
                            editCtrller: _contactCtrller,
                            textColor: AppColors.kWhiteColor,
                            maxLines: 1),
                        TextFormFieldWidget(
                            backColor: AppColors.kTextFormBackColor,
                            hintText: 'E-mail',
                            editCtrller: _emailCtrller,
                            textColor: AppColors.kWhiteColor,
                            maxLines: 1),
                        Consumer<UserStateProvider>(
                            builder: (context, userStateProvider, _) {
                          return CustomButton(
                            backColor: AppColors.kYellowColor,
                            text: 'Enregistrer',
                            textColor: AppColors.kBlackColor,
                            callback: () {
                              Map data = {
                                "names": _nomCtrller.text.trim().toUpperCase(),
                                "relation":
                                    _relationCtrller.text.trim().toUpperCase(),
                                "dob":
                                    _contactCtrller.text.trim().toUpperCase(),
                                "address":
                                    _adresseCtrller.text.trim().toUpperCase(),
                                "telephone":
                                    _contactCtrller.text.trim().toUpperCase(),
                                "email":
                                    _emailCtrller.text.trim().toUpperCase(),
                                "userId": Provider.of<UserStateProvider>(
                                        context,
                                        listen: false)
                                    .userId
                                    .toString(),
                              };
                              userStateProvider.addPayablePersonInfo(
                                  context: context,
                                  nominatedAdmin:
                                      PayablePersonModel.fromJson(data),
                                  callback: () {
                                    Navigator.pop(context);
                                  });
                            },
                          );
                        })
                      ],
                    ))
              ],
            ),
          ),
        ),
      );
    });
  }
}

// class NearestPersonPage extends StatelessWidget {
//   const NearestPersonPage({Key? key}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Consumer<UserStateProvider>(
//       builder: (context, userStateProvider, _) {
//         return userStateProvider.nominatedAdminData != null
//             ? Column(
//                 children: [
//                   Container(
//                     padding:
//                         const EdgeInsets.symmetric(horizontal: 5, vertical: 10),
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                       children: [
//                         Expanded(
//                           flex: 3,
//                           child: TextWidgets.text300(
//                               title: 'Nom',
//                               fontSize: 14,
//                               textColor: AppColors.kWhiteColor),
//                         ),
//                         Expanded(
//                           flex: 1,
//                           child: TextWidgets.text300(
//                               title: 'Relation',
//                               fontSize: 14,
//                               textColor: AppColors.kWhiteColor),
//                         ),
//                         Expanded(
//                           flex: 3,
//                           child: TextWidgets.text300(
//                               title: 'Adresse',
//                               fontSize: 14,
//                               textColor: AppColors.kWhiteColor),
//                         ),
//                         Expanded(
//                           flex: 2,
//                           child: TextWidgets.text300(
//                               title: 'Phone',
//                               fontSize: 14,
//                               textColor: AppColors.kWhiteColor),
//                         ),
//                         Expanded(
//                           flex: 3,
//                           child: TextWidgets.text300(
//                               title: 'Email',
//                               fontSize: 14,
//                               textColor: AppColors.kWhiteColor),
//                         )
//                       ],
//                     ),
//                   ),
//                   Container(
//                     padding:
//                         const EdgeInsets.symmetric(horizontal: 5, vertical: 10),
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                       children: [
//                         Expanded(
//                           flex: 3,
//                           child: TextWidgets.text300(
//                               title: userStateProvider.nearestPersonData!.nom
//                                   .trim(),
//                               fontSize: 14,
//                               textColor: AppColors.kWhiteColor),
//                         ),
//                         Expanded(
//                           flex: 1,
//                           child: TextWidgets.text300(
//                               title: userStateProvider
//                                   .nearestPersonData!.relation
//                                   .trim(),
//                               fontSize: 14,
//                               textColor: AppColors.kWhiteColor),
//                         ),
//                         Expanded(
//                           flex: 3,
//                           child: TextWidgets.text300(
//                               title: userStateProvider
//                                   .nearestPersonData!.adresse
//                                   .trim(),
//                               fontSize: 14,
//                               textColor: AppColors.kWhiteColor),
//                         ),
//                         Expanded(
//                           flex: 2,
//                           child: TextWidgets.text300(
//                               title: userStateProvider
//                                   .nearestPersonData!.contact
//                                   .trim(),
//                               fontSize: 14,
//                               textColor: AppColors.kWhiteColor),
//                         ),
//                         Expanded(
//                           flex: 3,
//                           child: TextWidgets.text300(
//                               title: userStateProvider.nearestPersonData!.email
//                                   .trim(),
//                               fontSize: 14,
//                               textColor: AppColors.kWhiteColor),
//                         )
//                       ],
//                     ),
//                   )
//                 ],
//               )
//             : EmptyModel(color: AppColors.kGreyColor);
//       },
//     );
//   }
// }
