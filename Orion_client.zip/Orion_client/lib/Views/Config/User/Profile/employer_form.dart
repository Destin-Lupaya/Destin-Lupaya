import 'package:orion/Resources/AppStateProvider/app_stateprovider.dart';
import 'package:orion/Resources/AppStateProvider/user_stateprovider.dart';
import 'package:orion/Resources/Components/button.dart';
import 'package:orion/Resources/Components/card.dart';
import 'package:orion/Resources/Components/empty_model.dart';
import 'package:orion/Resources/Components/modal_progress.dart';
import 'package:orion/Resources/Components/radio_button.dart';
import 'package:orion/Resources/Components/text_fields.dart';
import 'package:orion/Resources/Components/texts.dart';
import 'package:orion/Resources/Helpers/date_parser.dart';
import 'package:orion/Resources/Models/employer_model.dart';
import 'package:orion/Resources/global_variables.dart';
import 'package:orion/Resources/responsive.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AddEmployerPage extends StatefulWidget {
  final bool updatingData;
  final EmployerModel? employer;
  const AddEmployerPage({Key? key, required this.updatingData, this.employer})
      : super(key: key);

  @override
  State<AddEmployerPage> createState() => _AddEmployerPageState();
}

class _AddEmployerPageState extends State<AddEmployerPage> {
  final TextEditingController _nomCtrller = TextEditingController(),
      _occupationCtrller = TextEditingController(),
      _adresseCtrller = TextEditingController(),
      _beginDateCtrller = TextEditingController(),
      _endDateCtrller = TextEditingController(),
      _contactCtrller = TextEditingController(),
      _previousEmployerCtrller = TextEditingController(),
      _previousEmployerDurationCtrller = TextEditingController();
  bool isActualEmployer = false;
  @override
  void initState() {
    super.initState();
    if (widget.updatingData == true) {
      _nomCtrller.text = widget.employer!.names.trim();
      _occupationCtrller.text = widget.employer!.domain.trim();
      _adresseCtrller.text = widget.employer!.address.trim();
      _beginDateCtrller.text = widget.employer!.startContract.trim();
      _endDateCtrller.text = widget.employer!.EndContract!.trim();
      _contactCtrller.text = widget.employer!.telephone.trim();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AppStateProvider>(builder: (context, appStateProvider, _) {
      return Material(
        color: AppColors.kTransparentColor,
        child: Container(
          padding: EdgeInsets.zero,
          width: Responsive.isMobile(context)
              ? MediaQuery.of(context).size.width
              : MediaQuery.of(context).size.width / 2,
          height: MediaQuery.of(context).size.height * .85,
          // color: AppColors.kBlackLightColor,
          child: ModalProgress(
            progressColor: AppColors.kYellowColor,
            isAsync: appStateProvider.isAsync,
            child: ListView(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              children: [
                CardWidget(
                    backColor: AppColors.kBlackLightColor,
                    title: 'Ajouter un employeur',
                    content: Column(
                      children: [
                        TextFormFieldWidget(
                            backColor: AppColors.kTextFormBackColor,
                            hintText: 'Nom',
                            editCtrller: _nomCtrller,
                            textColor: AppColors.kWhiteColor,
                            maxLines: 1),
                        TextFormFieldWidget(
                            backColor: AppColors.kTextFormBackColor,
                            hintText: 'Domaine',
                            editCtrller: _occupationCtrller,
                            textColor: AppColors.kWhiteColor,
                            maxLines: 1),
                        GestureDetector(
                          child: TextFormFieldWidget(
                              backColor: AppColors.kTextFormBackColor,
                              hintText: 'Date de debut du contrat',
                              isEnabled: false,
                              isObsCured: false,
                              editCtrller: _beginDateCtrller,
                              textColor: AppColors.kWhiteColor,
                              maxLines: 1),
                          onTap: () async {
                            var picked = await showDatePicker(
                                context: context,
                                initialDate: DateTime.now()
                                    .subtract(const Duration(days: 365 * 20)),
                                firstDate: DateTime.now()
                                    .subtract(const Duration(days: 365 * 20)),
                                lastDate: DateTime.now());
                            if (picked == null) return;
                            _beginDateCtrller.text =
                                picked.toString().substring(0, 10);
                            setState(() {});
                          },
                        ),
                        isActualEmployer == false
                            ? GestureDetector(
                                child: TextFormFieldWidget(
                                    backColor: AppColors.kTextFormBackColor,
                                    hintText: 'Date de fin du contrat',
                                    isEnabled: false,
                                    isObsCured: false,
                                    editCtrller: _endDateCtrller,
                                    textColor: AppColors.kWhiteColor,
                                    maxLines: 1),
                                onTap: () async {
                                  var picked = await showDatePicker(
                                      context: context,
                                      initialDate: DateTime.now().subtract(
                                          const Duration(days: 365 * 20)),
                                      firstDate: DateTime.now().subtract(
                                          const Duration(days: 365 * 20)),
                                      lastDate: DateTime.now());
                                  if (picked == null) return;
                                  _endDateCtrller.text =
                                      picked.toString().substring(0, 10);
                                  setState(() {});
                                },
                              )
                            : Container(),
                        TextFormFieldWidget(
                            backColor: AppColors.kTextFormBackColor,
                            hintText: 'Adresse',
                            editCtrller: _adresseCtrller,
                            textColor: AppColors.kWhiteColor,
                            maxLines: 1),
                        TextFormFieldWidget(
                            backColor: AppColors.kTextFormBackColor,
                            hintText: 'No telephone',
                            editCtrller: _contactCtrller,
                            textColor: AppColors.kWhiteColor,
                            maxLines: 1),
                        Row(
                          children: [
                            CustomRadioButton(
                                value: isActualEmployer,
                                label: "Employeur actuel",
                                textColor: AppColors.kWhiteColor,
                                callBack: () {
                                  isActualEmployer = !isActualEmployer;
                                  _endDateCtrller.text = '';
                                  setState(() {});
                                }),
                          ],
                        ),
                        Consumer<UserStateProvider>(
                            builder: (context, userStateProvider, _) {
                          return CustomButton(
                            backColor: AppColors.kYellowColor,
                            text: 'Enregistrer',
                            textColor: AppColors.kBlackColor,
                            callback: () {
                              if (isActualEmployer == false &&
                                  _endDateCtrller.text.isEmpty) {
                                return Message.showToast(
                                    msg:
                                        'Veuillez entrer une date de fin contrat');
                              }
                              if (userStateProvider.employerData
                                  .where((employer) {
                                    return employer.EndContract == null ||
                                        employer.EndContract == 'null';
                                  })
                                  .toList()
                                  .isNotEmpty) {
                                return Message.showToast(
                                    msg:
                                        'Vous avez deja defini un employeur actuel');
                              }
                              if (userStateProvider.employerData.length >= 2) {
                                return Message.showToast(
                                    msg:
                                        'Vous avez deja atteint la limite des employeurs');
                              }
                              Map data = {
                                "id": widget.updatingData == true
                                    ? widget.employer!.id!.toString()
                                    : "0",
                                "names": _nomCtrller.text.trim().toUpperCase(),
                                "domain": _occupationCtrller.text
                                    .trim()
                                    .toUpperCase(),
                                "startContract": _beginDateCtrller.text.trim(),
                                "EndContract": _endDateCtrller.text.trim(),
                                "address":
                                    _adresseCtrller.text.trim().toUpperCase(),
                                "telephone":
                                    _contactCtrller.text.trim().toUpperCase(),
                                "email":
                                    _contactCtrller.text.trim().toUpperCase(),
                                'users_id': Provider.of<UserStateProvider>(
                                        context,
                                        listen: false)
                                    .userId
                                    .toString()
                              };
                              userStateProvider.addEmployerInfo(
                                  context: context,
                                  employer: EmployerModel.fromJson(data),
                                  updatingData: widget.updatingData,
                                  callback: () {
                                    Navigator.pop(context);
                                  });
                            },
                          );
                        })
                      ],
                    ))
              ],
            ),
          ),
        ),
      );
    });
  }
}

class EmployerPage extends StatefulWidget {
  const EmployerPage({Key? key}) : super(key: key);

  @override
  _EmployerPageState createState() => _EmployerPageState();
}

class _EmployerPageState extends State<EmployerPage> {
  @override
  Widget build(BuildContext context) {
    return Consumer<UserStateProvider>(
      builder: (context, userStateProvider, child) {
        return userStateProvider.employerData.isNotEmpty
            ? Column(
                children: [
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          flex: 3,
                          child: TextWidgets.text300(
                              title: 'Nom',
                              fontSize: 14,
                              textColor: AppColors.kWhiteColor),
                        ),
                        Expanded(
                          flex: 2,
                          child: TextWidgets.text300(
                              title: 'Occupation',
                              fontSize: 14,
                              textColor: AppColors.kWhiteColor),
                        ),
                        Expanded(
                          flex: 2,
                          child: TextWidgets.text300(
                              title: 'Debut du contrat',
                              fontSize: 14,
                              textColor: AppColors.kWhiteColor),
                        ),
                        Expanded(
                          flex: 2,
                          child: TextWidgets.text300(
                              title: 'Phone',
                              fontSize: 14,
                              textColor: AppColors.kWhiteColor),
                        ),
                        Expanded(
                          flex: 3,
                          child: TextWidgets.text300(
                              title: 'Adresse',
                              fontSize: 14,
                              textColor: AppColors.kWhiteColor),
                        ),
                        TextWidgets.text300(
                            title: 'Actions',
                            fontSize: 14,
                            textColor: AppColors.kWhiteColor)
                      ],
                    ),
                  ),
                  ListView.builder(
                      itemCount: userStateProvider.employerData.length,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemBuilder: (context, int index) {
                        return Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 5, vertical: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                flex: 3,
                                child: TextWidgets.text300(
                                    title: userStateProvider
                                        .employerData[index].names
                                        .trim(),
                                    fontSize: 14,
                                    textColor: AppColors.kWhiteColor),
                              ),
                              Expanded(
                                flex: 2,
                                child: TextWidgets.text300(
                                    title: userStateProvider
                                        .employerData[index].domain
                                        .trim(),
                                    fontSize: 14,
                                    textColor: AppColors.kWhiteColor),
                              ),
                              Expanded(
                                flex: 2,
                                child: TextWidgets.text300(
                                    title: parseDate(
                                        date: userStateProvider
                                            .employerData[index].startContract
                                            .trim()),
                                    fontSize: 14,
                                    textColor: AppColors.kWhiteColor),
                              ),
                              Expanded(
                                flex: 2,
                                child: TextWidgets.text300(
                                    title: userStateProvider
                                        .employerData[index].telephone
                                        .trim(),
                                    fontSize: 14,
                                    textColor: AppColors.kWhiteColor),
                              ),
                              Expanded(
                                flex: 3,
                                child: TextWidgets.text300(
                                    title: userStateProvider
                                        .employerData[index].address
                                        .trim(),
                                    fontSize: 14,
                                    textColor: AppColors.kWhiteColor),
                              ),
                              Row(
                                children: [
                                  GestureDetector(
                                    onTap: () {
                                      showCupertinoModalPopup(
                                          context: context,
                                          builder: (context) {
                                            return Center(
                                              child: AddEmployerPage(
                                                updatingData: true,
                                                employer: userStateProvider
                                                    .employerData[index],
                                              ),
                                            );
                                          });
                                    },
                                    child: Icon(Icons.edit,
                                        color: AppColors.kGreenColor),
                                  ),
                                  const SizedBox(width: 10),
                                  GestureDetector(
                                    child: Icon(Icons.delete,
                                        color: AppColors.kRedColor),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        );
                      })
                ],
              )
            : EmptyModel(color: AppColors.kGreyColor);
      },
    );
  }
}
