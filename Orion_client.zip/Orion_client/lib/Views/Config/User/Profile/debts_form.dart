// import 'package:andema/Resources/AppStateProvider/app_stateprovider.dart';
// import 'package:andema/Resources/AppStateProvider/user_stateprovider.dart';
// import 'package:andema/Resources/Components/button.dart';
// import 'package:andema/Resources/Components/card.dart';
// import 'package:andema/Resources/Components/dropdown_button.dart';
// import 'package:andema/Resources/Components/empty_model.dart';
// import 'package:andema/Resources/Components/modal_progress.dart';
// import 'package:andema/Resources/Components/text_fields.dart';
// import 'package:andema/Resources/Models/statement_position.model.dart';
// import 'package:andema/Resources/global_variables.dart';
// import 'package:andema/Resources/responsive.dart';
// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';

// class AddDebtPage extends StatefulWidget {
//   AddDebtPage({Key? key}) : super(key: key);

//   @override
//   State<AddDebtPage> createState() => _AddDebtPageState();
// }

// class _AddDebtPageState extends State<AddDebtPage> {
//   final TextEditingController _priceCtrller = TextEditingController(),
//       _detailsCtrller = TextEditingController();

//   String type = "Maison";

//   @override
//   Widget build(BuildContext context) {
//     return Material(
//       color: AppColors.kTransparentColor,
//       child: Container(
//           // padding: const EdgeInsets.symmetric(horizontal: 10),
//           width: Responsive.isMobile(context)
//               ? MediaQuery.of(context).size.width
//               : MediaQuery.of(context).size.width / 2,
//           height: MediaQuery.of(context).size.height * .85,
//           // color: AppColors.kBlackLightColor,
//           child: Consumer<AppStateProvider>(
//               builder: (context, appStateProvider, child) {
//             return ModalProgress(
//               isAsync: appStateProvider.isAsync,
//               progressColor: AppColors.kYellowColor,
//               child: ListView(
//                 shrinkWrap: true,
//                 children: [
//                   CardWidget(
//                       backColor: AppColors.kBlackLightColor,
//                       title: 'Ajouter dans les dettes',
//                       content: Column(
//                         children: [
//                           CustomDropdownButton(
//                               value: type,
//                               hintText: 'Type de possession',
//                               callBack: (value) {
//                                 type = value;
//                                 setState(() {});
//                               },
//                               items: const [
//                                 "Maison",
//                                 "Voiture",
//                                 "Taxes",
//                                 "Autres debiteurs",
//                                 "Autres"
//                               ]),
//                           TextFormFieldWidget(
//                               backColor: AppColors.kTextFormBackColor,
//                               hintText: 'Details (besoins a satisfaire)',
//                               editCtrller: _detailsCtrller,
//                               textColor: AppColors.kWhiteColor,
//                               maxLines: 1),
//                           TextFormFieldWidget(
//                               backColor: AppColors.kTextFormBackColor,
//                               hintText: 'Montant',
//                               editCtrller: _priceCtrller,
//                               inputType: TextInputType.number,
//                               textColor: AppColors.kWhiteColor,
//                               maxLines: 1),
//                           Consumer<UserStateProvider>(
//                               builder: (context, userStateProvider, _) {
//                             return CustomButton(
//                               backColor: AppColors.kYellowColor,
//                               text: 'Enregistrer',
//                               textColor: AppColors.kBlackColor,
//                               callback: () {
//                                 Map data = {
//                                   'type': type.trim(),
//                                   'category': 'Liabilities',
//                                   'description': _detailsCtrller.text.trim(),
//                                   'montant': _priceCtrller.text.trim(),
//                                   'user_id': Provider.of<UserStateProvider>(
//                                           context,
//                                           listen: false)
//                                       .userId,
//                                 };
//                                 userStateProvider.addStatementPosition(
//                                     context: context,
//                                     statementPosition:
//                                         StatementPositionModel.fromJson(data),
//                                     callback: () {
//                                       Navigator.pop(context);
//                                     });
//                               },
//                             );
//                           })
//                         ],
//                       ))
//                 ],
//               ),
//             );
//           })),
//     );
//   }
// }
