import 'package:orion/Resources/AppStateProvider/menu_state_provider.dart';
import 'package:orion/Resources/AppStateProvider/user_stateprovider.dart';
import 'package:orion/Resources/Components/button.dart';
import 'package:orion/Resources/global_variables.dart';
import 'package:orion/main.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class SettingPage extends StatefulWidget {
  const SettingPage({Key? key}) : super(key: key);

  @override
  _SettingPageState createState() => _SettingPageState();
}

class _SettingPageState extends State<SettingPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: SingleChildScrollView(
        child: Column(
          children: [
            CustomButton(
                text: 'Logout',
                backColor: AppColors.kRedColor,
                textColor: AppColors.kWhiteColor,
                callback: () {
                  prefs.clear();
                  Provider.of<MenuStateProvider>(context, listen: false)
                      .initMenu(context: context);
                  Provider.of<UserStateProvider>(context, listen: false)
                      .logOut();
                }),
          ],
        ),
      )),
    );
  }
}
