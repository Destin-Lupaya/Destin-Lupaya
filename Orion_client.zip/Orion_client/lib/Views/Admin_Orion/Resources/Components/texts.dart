import 'package:flutter/material.dart';

class TextWidgets {
  static textNormal(
      {required String title,
      required double fontSize,
      required Color textColor,
      TextAlign align = TextAlign.left}) {
    return Container(
      // width: double.maxFinite,
      padding: EdgeInsets.zero,
      child: Text(
        title,
        textAlign: align,
        style: TextStyle(fontSize: fontSize, color: textColor),
      ),
    );
  }

  static text300(
      {required String title,
      required double fontSize,
      required Color textColor,
      TextAlign align = TextAlign.left}) {
    return Container(
      padding: EdgeInsets.zero,
      child: Text(
        title,
        textAlign: align,
        style: TextStyle(
            fontSize: fontSize, fontWeight: FontWeight.w300, color: textColor),
      ),
    );
  }

  static text500(
      {required String title,
      required double fontSize,
      required Color textColor,
      TextAlign align = TextAlign.left}) {
    return Container(
      padding: EdgeInsets.zero,
      child: Text(
        title,
        textAlign: align,
        style: TextStyle(
            fontSize: fontSize, fontWeight: FontWeight.w500, color: textColor),
      ),
    );
  }

  static textBold(
      {required String title,
      required double fontSize,
      required Color textColor,
      TextAlign align = TextAlign.left}) {
    return Container(
      padding: EdgeInsets.zero,
      child: Text(
        title,
        textAlign: align,
        style: TextStyle(
            fontSize: fontSize, fontWeight: FontWeight.bold, color: textColor),
      ),
    );
  }
}
