import '../../Resources/global_variables.dart';
import 'package:flutter/material.dart';

class CustomDropdownButton extends StatelessWidget {
  final String value, hintText;
  final List<String> items;
  Function callBack;
  CustomDropdownButton(
      {Key? key,
      required this.value,
      required this.hintText,
      required this.callBack,
      required this.items})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            hintText,
          ),
          const SizedBox(
            height: 0,
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
                color: AppColors.kTextFormWhiteColor,
                borderRadius: BorderRadius.circular(kDefaultPadding / 4)),
            child: DropdownButton(
              underline: Container(),
              isExpanded: true,
              disabledHint: Text(
                hintText,
              ),
              items: items.map((element) {
                return DropdownMenuItem(
                  child: Text(element),
                  value: element,
                );
              }).toList(),
              onChanged: (value) {
                callBack(value);
              },
              value: value,
            ),
          ),
        ],
      ),
    );
  }
}

class DropdownButtonWithIndexValue extends StatelessWidget {
  final String value, hintText, valueColumn, indexColumn;
  final List items;
  Function callBack;
  DropdownButtonWithIndexValue(
      {Key? key,
      required this.value,
      required this.hintText,
      required this.valueColumn,
      required this.indexColumn,
      required this.callBack,
      required this.items})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            hintText,
          ),
          const SizedBox(
            height: 0,
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
                color: AppColors.kTextFormWhiteColor,
                borderRadius: BorderRadius.circular(kDefaultPadding / 4)),
            child: DropdownButton(
              underline: Container(),
              isExpanded: true,
              disabledHint: Text(
                hintText,
              ),
              items: items.map((element) {
                return DropdownMenuItem(
                  child: Text(element[valueColumn]),
                  value: element[indexColumn],
                );
              }).toList(),
              onChanged: (value) {
                callBack(value);
              },
              value: value,
            ),
          ),
        ],
      ),
    );
  }
}
