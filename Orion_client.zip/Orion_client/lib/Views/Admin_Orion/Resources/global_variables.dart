import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

double kDefaultPadding = 20;

class AppColors {
  static Color kPrimaryColor = Colors.blue.shade900;
  static Color kSecondaryColor = Colors.blue;
  static Color kBlackColor = Colors.black;
  static Color kBlackLightColor = const Color.fromRGBO(24, 24, 24, 1);
  static Color kWhiteColor = Colors.white;
  static Color kWhiteDarkColor = Colors.grey.shade400;
  static Color kGreenColor = Colors.green;
  static Color kRedColor = Colors.red;
  static Color kGreyColor = Colors.grey;
  // static Color kYellowColor = const Color.fromRGBO(255, 184, 57, 1);
  static Color kYellowColor = const Color.fromRGBO(255, 185, 35, 1);
  static Color kTextFormWhiteColor = Colors.white.withOpacity(0.05);
  static Color kTextFormBackColor = Colors.black.withOpacity(0.1);
  static Color kTransparentColor = Colors.transparent;
}

// class Theme {
//   // Enum themeVariant={"Light", Dark};

// }

class Navigation {
  static pushNavigate({required BuildContext context, required Widget page}) {
    Navigator.push(context, CupertinoPageRoute(builder: (context) => page));
  }

  static pushAndRemove({required BuildContext context, required Widget page}) {
    Navigator.pushAndRemoveUntil(context,
        CupertinoPageRoute(builder: (context) => page), (route) => false);
  }
}

class Message {
  static showToast({required String msg}) {
    Fluttertoast.showToast(toastLength: Toast.LENGTH_LONG, msg: msg);
  }
}

class BaseUrl {
  static String apiUrlOnline = "http://api-ohada.naledi.cd/api";
  static String apiUrl = "http://192.168.1.102:8000/api";
  //static String apiUrl = "http://192.168.43.165:8000/api";
  static String getLogin = '$apiUrl/user/login/';
  static String addUser = '$apiUrl/users';

  static String getfeescommission = '$apiUrl/feescommission/';
  static String getConstitutionep = '$apiUrl/constitutionep/';
  static String getloantype = '$apiUrl/loantype/';
  static String loanTypeFees = '$apiUrl/loantypefees/';

  static String getComptes = '$apiUrl/config/comptes/';

  static String getSousCompte = '$apiUrl/config/souscomptescompany/';
  static String getSousCompteAll = '$apiUrl/config/souscomptes/';
  static String getCompte = '$apiUrl/config/comptes/';
  static String getCompany = '$apiUrl/company';
  static String getClasses = '$apiUrl/config/classes/';
}
