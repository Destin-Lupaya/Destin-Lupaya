import 'package:orion/Views/Admin_Orion/Resources/Models/Guichet/users_activities_model.dart';
import 'package:orion/Views/Admin_Orion/Resources/Models/menu_model.dart';

import 'package:orion/Views/Admin_Orion/Views/Config/Settings/settings.dart';
import 'package:orion/Views/Admin_Orion/Views/Config/User/create_user.dart';

import 'package:orion/Views/Admin_Orion/Views/Guichet/caisse.dart';
import 'package:orion/Views/Admin_Orion/Views/Guichet/create_activity.dart';
import 'package:orion/Views/Admin_Orion/Views/Guichet/users_activities.dart';
import 'package:orion/Views/Admin_Orion/Views/Reporting/Dashboard/home_dashboard_page.dart';

import 'package:flutter/material.dart';
import 'package:orion/Views/Guichet/gestionnaire_activite_orion.dart';
import 'package:orion/Views/Reporting/Dashboard/home_dash_page.dart';

class AdminMenuStateProvider extends ChangeNotifier {
  String currentMenu = 'Accueil';
  List<MenuModel> menu = [
    MenuModel(
        title: 'Activites', icon: Icons.settings, page: AcceuilOrionPage()),
    MenuModel(
        title: 'Accueil', icon: Icons.home_outlined, page: HomeDashboardPage()),
    MenuModel(
        title: 'Add  Users',
        icon: Icons.person,
        page: const CreateUserPage(
          updatingData: false,
        )),
    MenuModel(
        title: 'Creation des Activites',
        icon: Icons.settings,
        page: CreateActivityPage(
          updatingData: false,
        )),
    // MenuModel(
    //     title: 'Activites de l\'Utilisateur',
    //     icon: Icons.person,
    //     page: UsersActivitiesPage(
    //       updatingData: false,
    //     )),
    MenuModel(
        title: 'Creation Caisse',
        icon: Icons.settings,
        page: CreateCaissePage(
          updatingData: false,
        )),
    // MenuModel(
    //     title: 'My Profile', icon: Icons.person, page: const ProfilePage()),
    MenuModel(title: 'Settings', icon: Icons.settings, page: SettingsPage()),
  ];
  getActivePage() {
    activePage = menu
        .where((menu) {
          return menu.title.toLowerCase() == currentMenu.toLowerCase();
        })
        .toList()[0]
        .page;
  }

  Widget activePage = HomeDashboardPage();

  changeMenu({required String newMenuValue}) {
    currentMenu = newMenuValue;
    // return print(currentMenu);
    getActivePage();
    notifyListeners();
  }

  setDefault() {
    currentMenu = "Accueil";
    activePage = HomeDashboardPage();
    notifyListeners();
  }
}
