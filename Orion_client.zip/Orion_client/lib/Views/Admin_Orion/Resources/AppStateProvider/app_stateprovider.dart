import 'dart:convert';

import 'package:orion/Views/Admin_Orion/Resources/AppStateProvider/menu_state_provider.dart';
import 'package:orion/Views/Admin_Orion/Resources/global_variables.dart';
import 'package:orion/Views/Admin_Orion/Views/Login/login_page.dart';
import 'package:orion/Views/Admin_Orion/Views/Reporting/Dashboard/home_dashboard_page.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import 'package:flutter/widgets.dart';

//import '../../main.dart';

class adminAppStateProvider extends ChangeNotifier {
  bool isAsync = false;
  changeAppState() {
    isAsync = !isAsync;
    // print(isAsync);
    // print('changing state');
    notifyListeners();
  }

  // initUI({required BuildContext context}) {
  //   if (prefs.getString('userData') != null) {
  //     WidgetsBinding.instance!.addPostFrameCallback((timeStamp) {
  //       Provider.of<MenuStateProvider>(context, listen: false).setDefault();
  //     });
  //   }
  // }

  Future<Response> httpPost({required String url, required Map body}) async {
    try {
      Response response = await http.post(Uri.parse(url), body: body, headers: {
        "Accept": "application/json",
      });
      print(response.body);
      if (response.statusCode >= 200 && response.statusCode < 300) {
        return response;
      } else if (response.statusCode == 401) {
        return Response(response.body, response.statusCode);
      } else {
        return Response("error", 400);
      }
    } catch (error) {
      return Response("error", 400);
    }
  }

  Future<Response> httpPut({required String url, required Map body}) async {
    try {
      Response response = await http.put(Uri.parse(url), body: body, headers: {
        "Accept": "application/json",
      });
      print(response.body);
      if (response.statusCode >= 200 && response.statusCode < 300) {
        return response;
      } else if (response.statusCode == 401) {
        return Response(response.body, response.statusCode);
      } else {
        return Response("error", 400);
      }
    } catch (error) {
      return Response("error", 400);
    }
  }

  Future<Response> httpDelete({required String url, required Map body}) async {
    try {
      Response response = await http.delete(Uri.parse(url), headers: {
        "Accept": "application/json",
      });
      // print(response.body);
      if (response.statusCode >= 200 && response.statusCode < 300) {
        return response;
      } else if (response.statusCode == 401) {
        return Response(response.body, response.statusCode);
      } else {
        return Response("error", 400);
      }
    } catch (error) {
      return Response("error", 400);
    }
  }

  Future<Response> httpGet({required String url}) async {
    try {
      final response = await http.get(
        Uri.parse(url),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
      );
      if (response.statusCode >= 200 && response.statusCode < 300) {
        return response;
      } else {
        return Response("error", 400);
      }
    } catch (error) {
      return Response("error", 400);
    }
  }

  logOut({required BuildContext context}) {
    Provider.of<AdminMenuStateProvider>(context, listen: false).setDefault();
    Navigation.pushAndRemove(context: context, page: const adminLoginPage());
  }

  List sousCompte = [];
  fetchSousComptes({required BuildContext context}) async {
    Provider.of<adminAppStateProvider>(context, listen: false).changeAppState();
    var response =
        await Provider.of<adminAppStateProvider>(context, listen: false)
            .httpGet(url: BaseUrl.getSousCompteAll);
    Provider.of<adminAppStateProvider>(context, listen: false).changeAppState();
    if (response.body != "error") {
      var decoded = jsonDecode(response.body);
      sousCompte = decoded;
      Message.showToast(msg: 'Chargement des sous comptes terminés');
      notifyListeners();
    } else {
      print(response.statusCode);
      Message.showToast(msg: 'Error occured, try again later');
    }
  }
}
