import 'package:orion/Views/Admin_Orion/Resources/AppStateProvider/app_stateprovider.dart';
import 'package:orion/Views/Admin_Orion/Resources/Models/Guichet/activite_model.dart';
import 'package:orion/Views/Admin_Orion/Resources/Models/Guichet/create_activity_model.dart';

import 'package:orion/Views/Admin_Orion//Resources/global_variables.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:convert';
import 'package:orion/Views/Admin_Orion/Resources/Models/utilisateur_model.dart';
import 'package:file_picker/file_picker.dart';
//import '../../main.dart';

class AdminUserStateProvider extends ChangeNotifier {
  int userId = 1;
  List<ClientModel> users = [];
  ClientModel? clientData;

  //ClientModel? clientDatas;

  List usersData = [
    // ClientModel(
    //         names: "Destin Kabote Lupaya",
    //         fname: "Destin",
    //         lname: "Kabote",
    //         pname: "Destin",
    //         role: "Agent",
    //         email: "destin@naledi.cd",
    //         telephone: "098889798")
    //     .toJson(),
    // ClientModel(
    //         names: "Providence Kambale Luseko",
    //         fname: "Julio",
    //         lname: "Kambale",
    //         pname: "Julio",
    //         role: "Agent",
    //         email: "julio@naledi.cd",
    //         telephone: "0976703577")
    //     .toJson(),
    // ClientModel(
    //         names: "Arthur Kibasomba",
    //         fname: "Arthur",
    //         lname: "Mulao",
    //         pname: "Arthur",
    //         role: "Agent",
    //         email: "artur@naledi.cd",
    //         telephone: "7989869")
    //     .toJson(),
    // ClientModel(
    //         names: "Anthony Chibinda Kangoro",
    //         fname: "Anthony",
    //         lname: "Chibinda",
    //         pname: "Antonio",
    //         role: "Agent",
    //         email: "anthony@naledi.cd",
    //         telephone: "07898")
    //     .toJson(),
    // ClientModel(
    //         names: "Moise Bauma Luhuha",
    //         fname: "Moise",
    //         lname: "Bauma",
    //         pname: "Yosh",
    //         role: "Agent",
    //         email: "moise@naledi.cd",
    //         telephone: "970709")
    //     .toJson(),
    // ClientModel(
    //         names: "Patrick Kamanda ",
    //         fname: "Patick",
    //         lname: "Patrick",
    //         pname: "Patrick",
    //         role: "Agent",
    //         email: "patrick@naledi.cd",
    //         telephone: "89898")
    //     .toJson(),
  ];

  List customerrData = [
    ClientModel(
            names: "Airtel money",
            fname: "Goma",
            lname: "Kabote",
            pname: "Destin",
            role: "Agent",
            email: "destin@naledi.cd",
            username: "kabote",
            telephone: "098889798")
        .toJson(),
    ClientModel(
            names: "Orange Money",
            fname: "Goma",
            lname: "Kambale",
            pname: "Julio",
            role: "Agent",
            email: "julio@naledi.cd",
            username: "kabote",
            telephone: "0976703577")
        .toJson(),
    ClientModel(
            names: "M-PESA",
            fname: "Goma",
            lname: "Mulao",
            pname: "Arthur",
            role: "Agent",
            email: "artur@naledi.cd",
            username: "kabote",
            telephone: "7989869")
        .toJson(),
    ClientModel(
            names: "Western Union",
            fname: "Goma",
            lname: "Chibinda",
            pname: "Antonio",
            role: "Agent",
            username: "kabote",
            email: "anthony@naledi.cd",
            telephone: "07898")
        .toJson(),
    ClientModel(
            names: "FINCA",
            fname: "Goma",
            lname: "Bauma",
            pname: "Yosh",
            role: "Agent",
            username: "kabote",
            email: "moise@naledi.cd",
            telephone: "970709")
        .toJson(),
    ClientModel(
            names: "SMICO ",
            fname: "Goma",
            lname: "Patrick",
            pname: "Patrick",
            role: "Agent",
            email: "patrick@naledi.cd",
            username: "kabote",
            telephone: "89898")
        .toJson(),
    ClientModel(
            names: "TMB ",
            fname: "Goma",
            lname: "Patrick",
            pname: "Patrick",
            role: "Agent",
            email: "patrick@naledi.cd",
            username: "kabote",
            telephone: "89898")
        .toJson(),
    ClientModel(
            names: "DHL ",
            fname: "Goma",
            lname: "Patrick",
            pname: "Patrick",
            role: "Agent",
            email: "patrick@naledi.cd",
            username: "kabote",
            telephone: "89898")
        .toJson(),
    ClientModel(
            names: "SBT ",
            fname: "Goma",
            lname: "Patrick",
            pname: "Patrick",
            role: "Agent",
            email: "patrick@naledi.cd",
            telephone: "89898",
            username: "kabote")
        .toJson(),
  ];

  List<PlatformFile> pickedFiles = [];

  addFiles(
      {required BuildContext context,
      required List<PlatformFile> picked,
      required Function callback}) async {
    if (picked.isEmpty) {
      return Message.showToast(msg: 'Veuillez choisir au moins un fichier');
    }
    Provider.of<adminAppStateProvider>(context, listen: false).changeAppState();
    // var response = await Provider.of<AppStateProvider>(context, listen: false)
    //     .httpPost(
    //         url: Uri(host: "http://192.169.2.137/andema/user/add"),
    // await Future.delayed(const Duration(seconds: 2));
    //         body: personalInfo.toJson());
    Provider.of<adminAppStateProvider>(context, listen: false).changeAppState();
    Message.showToast(msg: 'Informations ajoutees avec succes');
    picked.forEach((file) {
      pickedFiles.add(file);
    });
    // pickedFiles.add(picked);
    // print(creditHistoryData);
    callback();
    // if (response.statusCode == 200) {
    //   Message.showToast(msg: 'Informations ajoutees avec succes');
    // } else {
    //   Message.showToast(msg: 'Une erreur est survenue');
    // }
    //calculateUserScore();
    notifyListeners();
  }

  addclient(
      {required BuildContext context,
      required ClientModel clientModel,
      required bool updatingData,
      required Function callback}) async {
    if (clientModel.names.isEmpty ||
        clientModel.email == null ||
        clientModel.telephone == null ||
        clientModel.username == null ||
        clientModel.password == null) {
      return Message.showToast(msg: 'Veuillez remplir tous les champs');
    }

    print(clientModel.toJson());
    // return;
    // Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    //usersData.add(clientModel.toJson());
    usersData.add(clientModel);

    //calculateUserScore();
    notifyListeners();
    showDialog(
        context: context,
        builder: (BuildContext context) => new AlertDialog(
              title: new Text('Félicitation'),
              content: new Text('Utilisateur ajouté avec succès!!!'),
              actions: <Widget>[
                new IconButton(
                    icon: new Icon(Icons.close),
                    onPressed: () {
                      Navigator.pop(context);
                    })
              ],
            ));
  }

  List<CaisseModel> activitiesList = [];
  List caisseData = [];
  addcaisse(
      {required BuildContext context,
      required CaisseModel creationActiviteModel,
      required bool updatingData,
      required Function callback}) async {
    if (creationActiviteModel.designation.isEmpty ||
            creationActiviteModel.description.isEmpty ||
            //creationActiviteModel.type_activite.isEmpty ||
            creationActiviteModel.solde_virtuel_CDF == null ||
            creationActiviteModel.solde_cash_CDF == null ||
            creationActiviteModel.solde_cash_USD == null
        //creationActiviteModel.telephone == null
        ) {
      return Message.showToast(msg: 'Veuillez remplir tous les champs');
    }

    print(creationActiviteModel.toJson());
    // return;
    // Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    //rcaisseData.add(creationActiviteModel.toJson());
    creationActiviteModel.id = caisseData.length + 1;
    caisseData.add(creationActiviteModel);

    //calculateUserScore();
    notifyListeners();
    return showDialog(
        context: context,
        builder: (BuildContext context) => new AlertDialog(
              title: new Text('Félicitation'),
              content: new Text(
                  'Votre creation de caisse a ete effectuée avec succès...'),
              actions: <Widget>[
                new IconButton(
                    icon: new Icon(Icons.close),
                    onPressed: () {
                      Navigator.pop(context);
                    })
              ],
            ));
  }

  updateCaisse(
      {required CaisseModel caisse,
      BuildContext? context,
      required Function callback}) {
    if (caisse.designation.isEmpty ||
            caisse.description.isEmpty ||
            //creationActiviteModel.type_activite.isEmpty ||
            caisse.solde_virtuel_CDF == null ||
            caisse.solde_cash_CDF == null ||
            caisse.solde_cash_USD == null
        //creationActiviteModel.telephone == null
        ) {
      return Message.showToast(msg: 'Veuillez remplir tous les champs');
    }
    caisseData[caisseData.indexWhere(
        (element) => element.id!.toString() == caisse.id!.toString())] = caisse;
    callback();
    notifyListeners();
    print('caisse updated');
  }

  updateUser(
      {required ClientModel client,
      BuildContext? context,
      required Function callback}) {
    if (client.names.isEmpty ||
            client.username.isEmpty ||
            //creationActiviteModel.type_activite.isEmpty ||
            client.role == null ||
            client.telephone == null ||
            client.password == null ||
            client.email == null
        //creationActiviteModel.telephone == null
        ) {
      return Message.showToast(msg: 'Veuillez remplir tous les champs');
    }
    usersData[usersData.indexWhere(
        (element) => element.id!.toString() == client.id!.toString())] = client;
    callback();
    notifyListeners();
    print('client updated');
  }

  updateactivities(
      {required CreatActiviteModel activity,
      BuildContext? context,
      required Function callback}) {
    if (activity.designation.isEmpty ||
        activity.description.isEmpty ||
        activity.type_activite == null) {
      return Message.showToast(msg: 'Veuillez remplir tous les champs');
    }
    activitiesdata[activitiesdata.indexWhere(
            (element) => element.id!.toString() == activity.id!.toString())] =
        activity;
    callback();
    notifyListeners();
    print('activities updated');
  }

  List<CreatActiviteModel> createactivities = [];
  List activitiesdata = [];
  addactivities(
      {required BuildContext context,
      required CreatActiviteModel creationActiviteModel,
      required bool updatingData,
      required Function callback}) async {
    if (creationActiviteModel.designation.isEmpty ||
            creationActiviteModel.description.isEmpty ||
            creationActiviteModel.type_activite.isEmpty
        // creationActiviteModel.solde_virtuel_CDF == null ||
        // creationActiviteModel.solde_cash_CDF == null ||
        // creationActiviteModel.solde_cash_USD == null ||
        // creationActiviteModel.telephone == null
        ) {
      return showDialog(
          context: context,
          builder: (BuildContext context) => new AlertDialog(
                title: new Text('Tous les Champs sont Obligatoire'),
                content: new Text('Veillez remplir tous les champs...'),
                actions: <Widget>[
                  new IconButton(
                      icon: new Icon(Icons.close),
                      onPressed: () {
                        Navigator.pop(context);
                      })
                ],
              ));
    }

    print(creationActiviteModel.toJson());
    // return;
    // Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    activitiesdata.add(creationActiviteModel);

    //calculateUserScore();
    notifyListeners();
    return showDialog(
        context: context,
        builder: (BuildContext context) => new AlertDialog(
              title: new Text('Felicitation'),
              content: new Text('Activité ajoutée avec succès...'),
              actions: <Widget>[
                new IconButton(
                    icon: new Icon(Icons.close),
                    onPressed: () {
                      Navigator.pop(context);
                    })
              ],
            ));
  }

  loginUser(
      {required BuildContext context,
      required Map clientModel,
      required Function callback}) async {
    // print(clientModel);
    if (clientModel['email'].isEmpty || clientModel['psw'].isEmpty) {
      return Message.showToast(msg: 'Veuillez remplir tous les champs'
          // showDialog(
          //     context: context,
          //     builder: (BuildContext context) => new AlertDialog(
          //           title: new Text('Attention'),
          //           content: new Text('Veuillez remplir tous les champs'),
          //           actions: <Widget>[
          //             new IconButton(
          //                 icon: new Icon(Icons.close),
          //                 onPressed: () {
          //                   Navigator.pop(context);
          //                 })
          //           ],
          //         )
          );
    }

    // print(clientModel);
    // return;
    Provider.of<adminAppStateProvider>(context, listen: false).changeAppState();
    // var response = await Provider.of<AppStateProvider>(context, listen: false)
    //     .httpPost(url: BaseUrl.getLogin, body: clientModel);

    Provider.of<adminAppStateProvider>(context, listen: false).changeAppState();
    // print(response.body);
    // if (response.statusCode >= 200 && response.statusCode < 300) {
    //   if (response.body != null) {
    Message.showToast(msg: 'User logged successfuly');
    // showDialog(
    //     context: context,
    //     builder: (BuildContext context) => new AlertDialog(
    //           title: new Text('Felicitation'),
    //           content: new Text('Connexion Reussie'),
    //           actions: <Widget>[
    //             new IconButton(
    //                 icon: new Icon(Icons.close),
    //                 onPressed: () {
    //                   Navigator.pop(context);
    //                 })
    //           ],
    //         )
    // );
    // clientData = ClientModel.fromJson(jsonDecode(response.body));
    // prefs.setString("userData", response.body);
    callback();
    notifyListeners();
    //   } else {
    //     Message.showToast(msg: 'Error occured');
    //   }
    // } else if (response.statusCode == 401) {
    //   var decoded = jsonDecode(response.body);
    //   Message.showToast(msg: decoded['message'].toString().trim());
    // } else {
    //   Message.showToast(msg: 'Error occured on the server');
    // }
  }

  getuser({required BuildContext context, required bool isRefreshed}) async {
    // if (users.isNotEmpty && isRefreshed == false) return;
    // users.clear();
    Provider.of<adminAppStateProvider>(context, listen: false).changeAppState();
    // var response =
    //     await Provider.of<AppStateProvider>(context, listen: false).httpGet(
    //   url: BaseUrl.addUser,
    //);
    Provider.of<adminAppStateProvider>(context, listen: false).changeAppState();
    // if (response.body != "error") {
    //   List decoded = jsonDecode(response.body);
    //   for (var data in decoded) {
    //     users.add(ClientModel.fromJson(data));
    //   }
    //   notifyListeners();
    // } else {
    //   Message.showToast(
    //       msg: 'Impossible de recuperer les donnees des possession');
    //}
  }

  getUserData() {
    // var savedUser = prefs.getString('userData');
    //Map user = savedUser != null ? jsonDecode(savedUser) : {};
    // if (user.isNotEmpty) {
    //   clientData = ClientModel.fromJson(user);
    //   userId = clientData!.id!;
    // }
    // notifyListeners();
  }
}
