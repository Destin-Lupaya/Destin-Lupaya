import 'package:flutter/material.dart';

class CreatActiviteModel {
  final int? id;
  final String designation;
  final String description;
  final String type_activite;
  CreatActiviteModel({
    this.id,
    required this.designation,
    required this.description,
    required this.type_activite,
  });
  static fromJson(json) {
    return CreatActiviteModel(
      designation: json['designation'].toString().trim(),
      description: json['description'].toString().trim(),
      type_activite: json['type_activite'].toString().trim(),
      id: json['id'] != null ? int.parse(json['id'].toString()) : 0,
    );
  }

  toJson() {
    return {
      "id": id.toString().trim(),
      "designation": designation.toString().trim(),
      "description": description.toString().trim(),
      "type_activite": type_activite.toString(),
    };
  }
}
