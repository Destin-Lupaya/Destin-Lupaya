import 'package:orion/Views/Admin_Orion/Resources/AppStateProvider/app_stateprovider.dart';
import 'package:orion/Views/Admin_Orion/Resources/AppStateProvider/theme_stateprovider.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/button.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/card.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/texts.dart';
import 'package:orion/Views/Admin_Orion/Resources/global_variables.dart';
import 'package:orion/Views/Admin_Orion/Resources/theme.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class SettingsPage extends StatelessWidget {
  SettingsPage({Key? key}) : super(key: key);
  final PageController _controller = PageController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        controller: _controller,
        child: Column(
          children: [
            CardWidget(
              title: 'Theme',
              content: Consumer<adminThemeStateProvider>(
                builder: (context, themeStateProvider, child) {
                  return Container(
                    child: Column(
                      children: [
                        Row(
                          children: [
                            const Text(
                              'Dark',
                              style: TextStyle(fontSize: 16),
                            ),
                            Checkbox(
                                value: themeStateProvider.isDarkMode,
                                onChanged: (value) {
                                  themeStateProvider.toogleTheme(value!);
                                }),
                          ],
                        )
                      ],
                    ),
                  );
                },
              ),
            ),
            CardWidget(
              backColor: AppColors.kBlackLightColor,
              title: 'Deconnexion',
              content: Consumer<adminAppStateProvider>(
                builder: (context, appStateProvider, child) {
                  return Container(
                    child: Column(
                      children: [
                        CustomButton(
                            text: 'Deconnecter mon compte',
                            backColor: AppColors.kBlackColor,
                            textColor: AppColors.kWhiteColor,
                            callback: () {
                              appStateProvider.logOut(context: context);
                            })
                      ],
                    ),
                  );
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}
