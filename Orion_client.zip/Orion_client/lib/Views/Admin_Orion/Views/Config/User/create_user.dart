import 'package:orion/Views/Admin_Orion/Resources/Components/applogo.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/empty_model.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/searchable_textfield.dart';
import 'package:orion/Views/Admin_Orion/Resources/Models/utilisateur_model.dart';
import 'package:orion/Views/Admin_Orion/Resources/AppStateProvider/user_stateprovider.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/button.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/card.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/dropdown_button.dart';
//import 'package:admin_andema/Resources/Components/radio_button.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/search_textfield.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/text_fields.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/texts.dart';
import 'package:orion/Views/Admin_Orion/Resources/global_variables.dart';
import 'package:orion/Views/Admin_Orion/Views/Guichet/update_user.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class CreateUserPage extends StatefulWidget {
  final bool updatingData;
  final ClientModel? clientModel;
  const CreateUserPage({Key? key, required this.updatingData, this.clientModel})
      : super(key: key);

  @override
  _CreateUserPageState createState() => _CreateUserPageState();
}

String? nomFournisseur;
String? membreInterne;

String? nomMembre;

class _CreateUserPageState extends State<CreateUserPage> {
  final PageController _controller = PageController();
  final TextEditingController _nameCtrller = TextEditingController();
  final TextEditingController _roleCtrller = TextEditingController();
  final TextEditingController _usernameCtrller = TextEditingController();
  final TextEditingController _pwdCtrller = TextEditingController();
  final TextEditingController _mailCtrller = TextEditingController();
  final TextEditingController _telephCtrller = TextEditingController();
  final TextEditingController _pwhCtrller = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.updatingData == true) {
      _nameCtrller.text = widget.clientModel!.names.trim();
      _usernameCtrller.text = widget.clientModel!.username.toString().trim();
      _roleCtrller.text = widget.clientModel!.password.toString().trim();
      _mailCtrller.text = widget.clientModel!.email.toString().trim();
      _telephCtrller.text = widget.clientModel!.telephone.toString().trim();
      _pwhCtrller.text = widget.clientModel!.password.toString().trim();
    }
    WidgetsBinding.instance!.addPostFrameCallback((timeStamp) {
      //Provider.of<UserStateProvider>(context, listen: false)
      // .getuser(context: context, isRefreshed: false);
    });
  }

  List<String> genderList = ["Homme", "Femme"];
  String currentGender = "Homme";
  List<String> typeUserList = ["Caissier", "Agregateur", "admin"];
  String currentUser = "Caissier";

  // String currentRole = "Backoffice";
  String currentUserType = "Backoffice";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
          controller: _controller,
          child: Column(
            children: [
              // const AppLogo(size: Size(100, 100)),
              CardWidget(
                backColor: AppColors.kBlackLightColor,
                title: 'Ajouter un utilisateur',
                content: Wrap(
                  children: [
                    Row(children: [
                      Expanded(
                        child: TextFormFieldWidget(
                          maxLines: 1,
                          editCtrller: _nameCtrller,
                          hintText: 'Noms',
                          textColor: AppColors.kWhiteColor,
                          backColor: AppColors.kTextFormWhiteColor,
                        ),
                      ),
                      Expanded(
                        child: TextFormFieldWidget(
                          maxLines: 1,
                          editCtrller: _usernameCtrller,
                          hintText: 'Nom d\'Utilisateur',
                          textColor: AppColors.kWhiteColor,
                          backColor: AppColors.kTextFormWhiteColor,
                        ),
                      ),
                    ]),
                    Row(children: [
                      // Expanded(
                      //   child: TextFormFieldWidget(
                      //     maxLines: 1,
                      //     editCtrller: _surnameCtrller,
                      //     hintText: 'Prenom',
                      //     textColor: AppColors.kWhiteColor,
                      //     backColor: AppColors.kTextFormWhiteColor,
                      //   ),
                      // ),
                      // Expanded(
                      //   child: GestureDetector(
                      //     child: TextFormFieldWidget(
                      //         backColor: AppColors.kTextFormBackColor,
                      //         hintText: 'Date de naissance',
                      //         isEnabled: false,
                      //         isObsCured: false,
                      //         editCtrller: _dobCtrller,
                      //         textColor: AppColors.kWhiteColor,
                      //         maxLines: 1),
                      //     onTap: () async {
                      //       var picked = await showDatePicker(
                      //           context: context,
                      //           initialDate: DateTime.now()
                      //               .subtract(const Duration(days: 365 * 20)),
                      //           firstDate: DateTime.now()
                      //               .subtract(const Duration(days: 365 * 20)),
                      //           lastDate: DateTime.now());
                      //       if (picked == null) return;
                      //       _dobCtrller.text =
                      //           picked.toString().substring(0, 10);
                      //       setState(() {});
                      //     },
                      //   ),
                      // ),
                    ]),
                    Row(children: [
                      // Expanded(
                      //   child: CustomDropdownButton(
                      //       value: currentGender,
                      //       hintText: "Genre",
                      //       callBack: (newValue) {
                      //         setState(() {
                      //           currentGender = newValue;
                      //         });
                      //       },
                      //       items: genderList),
                      // ),
                      // Expanded(
                      //   child: CustomDropdownButton(
                      //       value: currentmarriagestatus,
                      //       hintText: "Etat Civil",
                      //       callBack: (newValue) {
                      //         setState(() {
                      //           currentmarriagestatus = newValue;
                      //         });
                      //       },
                      //       items: marriagestatusList),
                      // ),
                      Expanded(
                        child: CustomDropdownButton(
                            value: currentUser,
                            hintText: "Role",
                            callBack: (newValue) {
                              setState(() {
                                currentUser = newValue;
                              });
                            },
                            items: typeUserList),
                      ),
                    ]),
                    // Row(children: [
                    //   Expanded(
                    //     child: TextFormFieldWidget(
                    //       maxLines: 1,
                    //       editCtrller: _countryCtrller,
                    //       hintText: 'Pays',
                    //       textColor: AppColors.kWhiteColor,
                    //       backColor: AppColors.kTextFormWhiteColor,
                    //     ),
                    //   ),
                    //   Expanded(
                    //     child: TextFormFieldWidget(
                    //       maxLines: 1,
                    //       editCtrller: _addressCtrller,
                    //       hintText: 'Address',
                    //       textColor: AppColors.kWhiteColor,
                    //       backColor: AppColors.kTextFormWhiteColor,
                    //     ),
                    //   ),
                    // ]),
                    Row(children: [
                      Expanded(
                        child: TextFormFieldWidget(
                          maxLines: 1,
                          editCtrller: _telephCtrller,
                          hintText: 'Telephone',
                          textColor: AppColors.kWhiteColor,
                          backColor: AppColors.kTextFormWhiteColor,
                        ),
                      ),
                      Expanded(
                        child: TextFormFieldWidget(
                          maxLines: 1,
                          editCtrller: _mailCtrller,
                          hintText: 'Email',
                          textColor: AppColors.kWhiteColor,
                          backColor: AppColors.kTextFormWhiteColor,
                        ),
                      ),
                    ]),
                    Row(children: [
                      // Expanded(
                      //   child: TextFormFieldWidget(
                      //     maxLines: 1,
                      //     editCtrller: _usernameCtrller,
                      //     hintText: 'Username',
                      //     textColor: AppColors.kWhiteColor,
                      //     backColor: AppColors.kTextFormWhiteColor,
                      //   ),
                      // ),
                      Expanded(
                        child: TextFormFieldWidget(
                          maxLines: 1,
                          editCtrller: _pwdCtrller,
                          hintText: 'Mot de passe',
                          textColor: AppColors.kWhiteColor,
                          backColor: AppColors.kTextFormWhiteColor,
                        ),
                      ),
                    ]),
                    Consumer<AdminUserStateProvider>(
                        builder: (context, userStateProvider, _) {
                      return CustomButton(
                        text: 'Enregistrer',
                        backColor: AppColors.kYellowColor,
                        textColor: AppColors.kWhiteColor,
                        callback: () {
                          Map data = {
                            "names": _nameCtrller.text.trim(),
                            // "lname": _lastnameCtrller.text.trim(),
                            // "pname": _surnameCtrller.text.trim(),
                            //  "dob": _dobCtrller.text.trim(),
                            // "genre": currentGender.trim(),
                            // "marriagestatus": currentmarriagestatus.trim(),
                            // "country": _countryCtrller.text.trim(),
                            "telephone": _telephCtrller.text.trim(),
                            // "address": _addressCtrller.text.trim(),
                            "email": _mailCtrller.text.trim(),
                            "username": _usernameCtrller.text.trim(),
                            "password": _pwdCtrller.text.trim(),
                            "role": currentUser,
                          };

                          userStateProvider.addclient(
                              context: context,
                              clientModel: ClientModel.fromJson(data),
                              updatingData: widget.updatingData,
                              callback: () {});
                        },
                      );
                    })
                  ],
                ),
              ),
              DisplayUserPageState()
            ],
          )),
    );
  }
}

class DisplayUserPageState extends StatelessWidget {
  const DisplayUserPageState({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Consumer<AdminUserStateProvider>(
      builder: (context, userStateProvider, child) {
        return userStateProvider.usersData.isNotEmpty
            ? Column(
                children: [
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          flex: 2,
                          child: TextWidgets.text300(
                              title: 'Noms',
                              fontSize: 14,
                              textColor: AppColors.kBlackLightColor),
                        ),
                        Expanded(
                          flex: 4,
                          child: TextWidgets.text300(
                              title: 'Nom d\'Utilisateur',
                              fontSize: 14,
                              textColor: AppColors.kBlackLightColor),
                        ),
                        Expanded(
                          flex: 2,
                          child: TextWidgets.text300(
                              title: 'Role',
                              fontSize: 14,
                              textColor: AppColors.kBlackLightColor),
                        ),
                        Expanded(
                          flex: 4,
                          child: TextWidgets.text300(
                              title: 'Telephone',
                              fontSize: 14,
                              textColor: AppColors.kBlackLightColor),
                        ),
                        Expanded(
                          flex: 2,
                          child: TextWidgets.text300(
                              title: 'Email',
                              fontSize: 14,
                              textColor: AppColors.kBlackLightColor),
                        ),
                        Expanded(
                          flex: 2,
                          child: TextWidgets.text300(
                              title: 'Mot de pass ',
                              fontSize: 14,
                              textColor: AppColors.kBlackLightColor),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 10),
                    child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: userStateProvider.usersData.length,
                        itemBuilder: (context, int index) {
                          return GestureDetector(
                            onTap: () {
                              showCupertinoModalPopup(
                                  context: context,
                                  builder: (context) => Center(
                                          child: UpdateUserPage(
                                        clientModel:
                                            userStateProvider.usersData[index],
                                        updatingData: true,
                                      )));
                            },
                            child: Column(
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 5, vertical: 10),
                                  color: index % 2 == 0
                                      ? AppColors.kBlackLightColor
                                      : AppColors.kBlackLightColor,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Expanded(
                                        flex: 2,
                                        child: TextWidgets.text300(
                                            title: userStateProvider
                                                .usersData[index].names
                                                .toString()
                                                .trim(),
                                            fontSize: 14,
                                            textColor: AppColors.kWhiteColor),
                                      ),
                                      Expanded(
                                        flex: 2,
                                        child: TextWidgets.text300(
                                            title: userStateProvider
                                                .usersData[index].username
                                                .toString()
                                                .trim(),
                                            fontSize: 14,
                                            textColor: AppColors.kWhiteColor),
                                      ),
                                      Expanded(
                                        flex: 4,
                                        child: TextWidgets.text300(
                                            title: userStateProvider
                                                .usersData[index].role
                                                .toString()
                                                .trim(),
                                            fontSize: 14,
                                            textColor: AppColors.kWhiteColor),
                                      ),

                                      Expanded(
                                        flex: 2,
                                        child: TextWidgets.text300(
                                            title: userStateProvider
                                                .usersData[index].telephone
                                                .toString()
                                                .trim(),
                                            fontSize: 14,
                                            textColor: AppColors.kWhiteColor),
                                      ),
                                      Expanded(
                                        flex: 2,
                                        child: TextWidgets.text300(
                                            title: userStateProvider
                                                .usersData[index].email
                                                .toString()
                                                .trim(),
                                            fontSize: 14,
                                            textColor: AppColors.kWhiteColor),
                                      ),
                                      // Expanded(
                                      //   flex: 2,
                                      //   child: TextWidgets.text300(
                                      //       title: userStateProvider
                                      //           .users[index].username
                                      //           .toString()
                                      //           .trim(),
                                      //       fontSize: 14,
                                      //       textColor: AppColors.kWhiteColor),
                                      // ),
                                      Expanded(
                                        flex: 2,
                                        child: TextWidgets.text300(
                                            title: userStateProvider
                                                .usersData[index].password
                                                .toString()
                                                .trim(),
                                            fontSize: 14,
                                            textColor: AppColors.kWhiteColor),
                                      ),
                                    ],
                                  ),
                                ),
                                Divider(
                                    height: 2,
                                    thickness: 1,
                                    color:
                                        AppColors.kWhiteColor.withOpacity(0.4))
                              ],
                            ),
                          );
                        }),
                  )
                ],
              )
            : EmptyModel(color: AppColors.kGreyColor);
      },
    );
  }
}
