import 'package:orion/Views/Admin_Orion/Resources/AppStateProvider/app_stateprovider.dart';

import 'package:orion/Views/Admin_Orion/Resources/AppStateProvider/user_stateprovider.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/button.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/dropdown_button.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/empty_model.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/search_textfield.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/card.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/searchable_textfield.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/text_fields.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/texts.dart';
import 'package:orion/Views/Admin_Orion/Resources/Models/Guichet/activite_model.dart';
import 'package:orion/Views/Admin_Orion/Resources/global_variables.dart';
import 'package:orion/Views/Admin_Orion/Views/Guichet/update_caisse.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class CreateCaissePage extends StatefulWidget {
  final bool updatingData;

  final CaisseModel? creationActiviteModel;
  const CreateCaissePage(
      {Key? key, required this.updatingData, this.creationActiviteModel})
      : super(key: key);

  @override
  _CreateCaissePageState createState() => _CreateCaissePageState();
}

List<String> typeactiviteList = ["Mobile Money", "Autres"];
late String typeactiviteMode = "Mobile Money";

String? nomFournisseur;
String? membreInterne;

String? nomMembre;

class _CreateCaissePageState extends State<CreateCaissePage> {
  final PageController _controller = PageController();
  String? sousCompteId;
  final TextEditingController _activiteCtrller = TextEditingController();
  final TextEditingController _namestCtrller = TextEditingController();
  final TextEditingController _typeaCtrller = TextEditingController();

  final TextEditingController _caissierCtrller = TextEditingController();
  final TextEditingController _soldevirtCDFCtrller = TextEditingController();
  final TextEditingController _soldecashCDFCtrller = TextEditingController();
  final TextEditingController _soldevirtUSDCtrller = TextEditingController();
  final TextEditingController _soldecashUSDCtrller = TextEditingController();
  final TextEditingController _telephoneCtrller = TextEditingController();

  final TextEditingController _telephCtrller = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.updatingData == true) {
      _activiteCtrller.text = widget.creationActiviteModel!.designation.trim();
      _namestCtrller.text = widget.creationActiviteModel!.description.trim();
      _caissierCtrller.text = widget.creationActiviteModel!.caissier.trim();
      _typeaCtrller.text =
          widget.creationActiviteModel!.type_activite.toString().trim();
      _soldevirtCDFCtrller.text =
          widget.creationActiviteModel!.solde_virtuel_CDF.toString().trim();
      _soldevirtUSDCtrller.text =
          widget.creationActiviteModel!.solde_virtuel_USD.toString().trim();
      _telephoneCtrller.text =
          widget.creationActiviteModel!.telephone.toString().trim();
      _soldecashCDFCtrller.text =
          widget.creationActiviteModel!.solde_cash_CDF.toString().trim();
      _soldecashUSDCtrller.text =
          widget.creationActiviteModel!.solde_cash_USD.toString().trim();
    }
    WidgetsBinding.instance!.addPostFrameCallback((timeStamp) {
      // Provider.of<UserStateProvider>(context, listen: false)
      //     .getactivities(context: context, isRefreshed: false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        controller: _controller,
        child: Column(
          children: [
            // GestureDetector(
            //   onTap: () {},
            //   child: Icon(Icons.edit, color: AppColors.kGreenColor),
            // ),
            // const SizedBox(width: 10),
            // GestureDetector(
            //   child: Icon(Icons.delete, color: AppColors.kRedColor),
            // ),
            // const AppLogo(size: Size(100, 100)),
            CardWidget(
                backColor: AppColors.kBlackLightColor,
                title: 'Creation Caisse',
                content: Wrap(
                  children: [
                    Row(children: [
                      // Expanded(
                      //   child: TextFormFieldWidget(
                      //     maxLines: 1,
                      //     hintText: 'Activites',
                      //     editCtrller: _activiteCtrller,
                      //     textColor: AppColors.kWhiteColor,
                      //     backColor: AppColors.kTextFormWhiteColor,
                      //   ),
                      // ),
                      Expanded(
                        child: SearchableTextFormFieldWidget(
                          hintText: 'Activites',
                          textColor: AppColors.kWhiteColor,
                          backColor: AppColors.kTextFormWhiteColor,
                          editCtrller: _activiteCtrller,
                          maxLines: 1,
                          callback: (value) {
                            nomFournisseur = value.toString();
                            setState(() {});
                          },
                          //data: Provider.of<AppStateProvider>(context)
                          data: Provider.of<AdminUserStateProvider>(context)
                              // .membreInscrit,
                              .activitiesdata
                              .map((user) => user.toJson())
                              .toList(),
                          displayColumn: "designation",
                          indexColumn: "designation",
                          secondDisplayColumn: "type_activite",
                        ),
                      ),

                      Expanded(
                        child: SearchableTextFormFieldWidget(
                          hintText: 'Noms Caissier',
                          textColor: AppColors.kWhiteColor,
                          backColor: AppColors.kTextFormWhiteColor,
                          editCtrller: _caissierCtrller,
                          maxLines: 1,
                          callback: (value) {
                            nomMembre = value.toString();
                            setState(() {});
                          },
                          //data: Provider.of<AppStateProvider>(context)
                          data: Provider.of<AdminUserStateProvider>(context)
                              // .membreInscrit,
                              .usersData
                              .map((user) => user.toJson())
                              .toList(),
                          displayColumn: "names",
                          indexColumn: "names",
                          secondDisplayColumn: "telephone",
                        ),
                      ),
                    ]),
                    // Row(
                    //   children: [
                    //     Expanded(
                    //       child: CustomDropdownButton(
                    //           value: typeactiviteMode,
                    //           hintText: "Type d\'activites ",
                    //           callBack: (newValue) {
                    //             setState(() {
                    //               typeactiviteMode = newValue;
                    //             });
                    //           },
                    //           items: typeactiviteList),
                    //     ),
                    //   ],
                    // ),
                    Row(
                      children: [
                        Expanded(
                          child: TextFormFieldWidget(
                            maxLines: 1,
                            hintText: 'Solde Virtuel USD',
                            editCtrller: _soldevirtUSDCtrller,
                            textColor: AppColors.kWhiteColor,
                            backColor: AppColors.kTextFormWhiteColor,
                          ),
                        ),
                        Expanded(
                          child: TextFormFieldWidget(
                            maxLines: 1,
                            hintText: 'Solde Virtuel CDF',
                            editCtrller: _soldevirtCDFCtrller,
                            textColor: AppColors.kWhiteColor,
                            backColor: AppColors.kTextFormWhiteColor,
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: TextFormFieldWidget(
                            maxLines: 1,
                            hintText: 'Solde Cash USD',
                            editCtrller: _soldecashUSDCtrller,
                            textColor: AppColors.kWhiteColor,
                            backColor: AppColors.kTextFormWhiteColor,
                          ),
                        ),
                        Expanded(
                          child: TextFormFieldWidget(
                            maxLines: 1,
                            hintText: 'Solde Cash CDF',
                            editCtrller: _soldecashCDFCtrller,
                            textColor: AppColors.kWhiteColor,
                            backColor: AppColors.kTextFormWhiteColor,
                          ),
                        ),
                      ],
                    ),

                    Consumer<AdminUserStateProvider>(
                        builder: (context, userStateProvider, _) {
                      return CustomButton(
                        text: 'Enregistrer',
                        backColor: AppColors.kYellowColor,
                        textColor: AppColors.kWhiteColor,
                        callback: () {
                          Map data = {
                            "designation": _activiteCtrller.text.trim(),
                            "caissier": _caissierCtrller.text.trim(),
                            "solde_virtuel_CDF":
                                _soldevirtCDFCtrller.text.trim(),
                            "solde_virtuel_USD":
                                _soldevirtUSDCtrller.text.trim(),
                            "solde_cash_CDF": _soldecashCDFCtrller.text.trim(),
                            "solde_cash_USD": _soldecashUSDCtrller.text.trim(),
                          };

                          userStateProvider.addcaisse(
                              context: context,
                              creationActiviteModel: CaisseModel.fromJson(data),
                              updatingData: widget.updatingData,
                              callback: () {});
                        },
                      );
                    })
                  ],
                )),

            DisplayCaissePage()
          ],
        ),
      ),
    );
  }
}

class DisplayCaissePage extends StatelessWidget {
  const DisplayCaissePage({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Consumer<AdminUserStateProvider>(
      builder: (context, userStateProvider, child) {
        return userStateProvider.caisseData.isNotEmpty
            ? Column(
                children: [
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          flex: 4,
                          child: TextWidgets.text300(
                              title: 'Designation',
                              fontSize: 14,
                              textColor: AppColors.kBlackLightColor),
                        ),
                        Expanded(
                          flex: 2,
                          child: TextWidgets.text300(
                              title: 'Caissier',
                              fontSize: 14,
                              textColor: AppColors.kBlackLightColor),
                        ),
                        // Expanded(
                        //   flex: 2,
                        //   child: TextWidgets.text300(
                        //       title: 'Type activites',
                        //       fontSize: 14,
                        //       textColor: AppColors.kWhiteColor),
                        // ),
                        Expanded(
                          flex: 2,
                          child: TextWidgets.text300(
                              title: 'Solde virtuel CDF',
                              fontSize: 14,
                              textColor: AppColors.kBlackLightColor),
                        ),
                        Expanded(
                          flex: 2,
                          child: TextWidgets.text300(
                              title: 'Solde virtuel USD',
                              fontSize: 14,
                              textColor: AppColors.kBlackLightColor),
                        ),
                        Expanded(
                          flex: 2,
                          child: TextWidgets.text300(
                              title: 'Solde Cash CDF',
                              fontSize: 14,
                              textColor: AppColors.kBlackLightColor),
                        ),
                        Expanded(
                          flex: 2,
                          child: TextWidgets.text300(
                              title: 'Solde Cash USD',
                              fontSize: 14,
                              textColor: AppColors.kBlackLightColor),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 10),
                    child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: userStateProvider.caisseData.length,
                        itemBuilder: (context, int index) {
                          return GestureDetector(
                            onTap: () {
                              showCupertinoModalPopup(
                                  context: context,
                                  builder: (context) => Center(
                                          child: UpdateCaissePage(
                                        creationActiviteModel:
                                            userStateProvider.caisseData[index],
                                        updatingData: true,
                                      )));
                            },
                            child: Column(
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 5, vertical: 10),
                                  color: index % 2 == 0
                                      ? AppColors.kBlackLightColor
                                      : AppColors.kBlackLightColor,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Expanded(
                                        flex: 4,
                                        child: TextWidgets.text300(
                                            title: userStateProvider
                                                .caisseData[index].designation
                                                .toString()
                                                .trim(),
                                            fontSize: 14,
                                            textColor: AppColors.kWhiteColor),
                                      ),
                                      Expanded(
                                        flex: 2,
                                        child: TextWidgets.text300(
                                            title: userStateProvider
                                                .caisseData[index].caissier
                                                .toString()
                                                .trim(),
                                            fontSize: 14,
                                            textColor: AppColors.kWhiteColor),
                                      ),
                                      // Expanded(
                                      //   flex: 2,
                                      //   child: TextWidgets.text300(
                                      //       title: userStateProvider
                                      //           .caisseData[index].type_activite
                                      //           .toString()
                                      //           .trim(),
                                      //       fontSize: 14,
                                      //       textColor: AppColors.kWhiteColor),
                                      // ),
                                      Expanded(
                                        flex: 2,
                                        child: TextWidgets.text300(
                                            title: userStateProvider
                                                .caisseData[index]
                                                .solde_virtuel_CDF
                                                .toString()
                                                .trim(),
                                            fontSize: 14,
                                            textColor: AppColors.kWhiteColor),
                                      ),
                                      Expanded(
                                        flex: 2,
                                        child: TextWidgets.text300(
                                            title: userStateProvider
                                                .caisseData[index]
                                                .solde_virtuel_USD
                                                .toString()
                                                .trim(),
                                            fontSize: 14,
                                            textColor: AppColors.kWhiteColor),
                                      ),

                                      Expanded(
                                        flex: 2,
                                        child: TextWidgets.text300(
                                            title: userStateProvider
                                                .caisseData[index]
                                                .solde_cash_CDF
                                                .toString()
                                                .trim(),
                                            fontSize: 14,
                                            textColor: AppColors.kWhiteColor),
                                      ),
                                      Expanded(
                                        flex: 2,
                                        child: TextWidgets.text300(
                                            title: userStateProvider
                                                .caisseData[index]
                                                .solde_cash_USD
                                                .toString()
                                                .trim(),
                                            fontSize: 14,
                                            textColor: AppColors.kWhiteColor),
                                      ),
                                      // Expanded(
                                      //   flex: 2,
                                      //   child: TextWidgets.text300(
                                      //       title: userStateProvider
                                      //           .caisseData[index].telephone
                                      //           .toString()
                                      //           .trim(),
                                      //       fontSize: 14,
                                      //       textColor: AppColors.kWhiteColor),
                                      // ),
                                    ],
                                  ),
                                ),
                                Divider(
                                    height: 2,
                                    thickness: 1,
                                    color:
                                        AppColors.kWhiteColor.withOpacity(0.4))
                              ],
                            ),
                          );
                        }),
                  )
                ],
              )
            : EmptyModel(color: AppColors.kGreyColor);
      },
    );
  }
}
