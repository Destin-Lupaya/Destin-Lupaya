import 'package:orion/Views/Admin_Orion/Resources/AppStateProvider/app_stateprovider.dart';

import 'package:orion/Views/Admin_Orion/Resources/AppStateProvider/user_stateprovider.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/button.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/dropdown_button.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/empty_model.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/modal_progress.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/search_textfield.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/card.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/searchable_textfield.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/text_fields.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/texts.dart';
import 'package:orion/Views/Admin_Orion/Resources/Models/Guichet/activite_model.dart';
import 'package:orion/Views/Admin_Orion/Resources/global_variables.dart';
import 'package:flutter/material.dart';
import 'package:orion/Views/Admin_Orion/Resources/responsive.dart';
import 'package:provider/provider.dart';

class UpdateCaissePage extends StatefulWidget {
  final bool updatingData;

  final CaisseModel? creationActiviteModel;
  const UpdateCaissePage(
      {Key? key, required this.updatingData, this.creationActiviteModel})
      : super(key: key);

  @override
  _UpdateCaissePageState createState() => _UpdateCaissePageState();
}

List<String> typeactiviteList = ["Mobile Money", "Autres"];
late String typeactiviteMode = "Mobile Money";

String? nomFournisseur;
String? membreInterne;

String? nomMembre;

class _UpdateCaissePageState extends State<UpdateCaissePage> {
  final PageController _controller = PageController();
  String? sousCompteId;
  final TextEditingController _activiteCtrller = TextEditingController();
  final TextEditingController _nomcaissierCtrller = TextEditingController();
  final TextEditingController _soldeVUSDCtrller = TextEditingController();

  final TextEditingController _soldeVCDFCtrller = TextEditingController();
  final TextEditingController _soldeCaCDFCtrller = TextEditingController();
  final TextEditingController _soldeCaUSDCtrller = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.updatingData == true) {
      _activiteCtrller.text = widget.creationActiviteModel!.designation.trim();
      _nomcaissierCtrller.text = widget.creationActiviteModel!.caissier.trim();
      _soldeVUSDCtrller.text =
          widget.creationActiviteModel!.solde_virtuel_USD.toString().trim();
      _soldeVCDFCtrller.text =
          widget.creationActiviteModel!.solde_virtuel_CDF.toString().trim();
      _soldeCaCDFCtrller.text =
          widget.creationActiviteModel!.solde_cash_CDF.toString().trim();
      _soldeCaUSDCtrller.text =
          widget.creationActiviteModel!.solde_cash_USD.toString().trim();
    }
    WidgetsBinding.instance!.addPostFrameCallback((timeStamp) {
      // Provider.of<UserStateProvider>(context, listen: false)
      //     .getactivities(context: context, isRefreshed: false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        width: Responsive.isMobile(context)
            ? MediaQuery.of(context).size.width
            : MediaQuery.of(context).size.width / 2,
        height: MediaQuery.of(context).size.height * .85,
        color: AppColors.kBlackLightColor,
        child: Consumer<adminAppStateProvider>(
            builder: (context, appStateProvider, _) {
          return ModalProgress(
            isAsync: appStateProvider.isAsync,
            progressColor: AppColors.kYellowColor,
            child: ListView(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  CardWidget(
                    backColor: AppColors.kBlackLightColor,
                    title: 'Reaffectation a la Caisse',
                    content: Wrap(children: [
                      Row(children: [
                        Expanded(
                          child: SearchableTextFormFieldWidget(
                            hintText: 'Activites',
                            textColor: AppColors.kWhiteColor,
                            backColor: AppColors.kTextFormWhiteColor,
                            editCtrller: _activiteCtrller,
                            maxLines: 1,
                            callback: (value) {
                              nomFournisseur = value.toString();
                              setState(() {});
                            },
                            //data: Provider.of<AppStateProvider>(context)
                            data: Provider.of<AdminUserStateProvider>(context)
                                // .membreInscrit,
                                .activitiesdata
                                .map((user) => user.toJson())
                                .toList(),
                            displayColumn: "designation",
                            indexColumn: "designation",
                            secondDisplayColumn: "type_activite",
                          ),
                        ),
                        Expanded(
                          child: SearchableTextFormFieldWidget(
                            hintText: 'Noms Caissier',
                            textColor: AppColors.kWhiteColor,
                            backColor: AppColors.kTextFormWhiteColor,
                            editCtrller: _nomcaissierCtrller,
                            maxLines: 1,
                            callback: (value) {
                              nomMembre = value.toString();
                              setState(() {});
                            },
                            //data: Provider.of<AppStateProvider>(context)
                            data: Provider.of<AdminUserStateProvider>(context)
                                // .membreInscrit,
                                .usersData
                                .map((user) => user.toJson())
                                .toList(),
                            displayColumn: "names",
                            indexColumn: "names",
                            secondDisplayColumn: "telephone",
                          ),
                        ),
                      ]),
                      // Row(
                      //   children: [
                      //     Expanded(
                      //       child: CustomDropdownButton(
                      //           value: typeactiviteMode,
                      //           hintText: "Type d\'activites ",
                      //           callBack: (newValue) {
                      //             setState(() {
                      //               typeactiviteMode = newValue;
                      //             });
                      //           },
                      //           items: typeactiviteList),
                      //     ),
                      //   ],
                      // ),
                      Row(
                        children: [
                          Expanded(
                            child: TextFormFieldWidget(
                              maxLines: 1,
                              hintText: 'Solde Virtuel USD',
                              editCtrller: _soldeVUSDCtrller,
                              textColor: AppColors.kWhiteColor,
                              backColor: AppColors.kTextFormWhiteColor,
                            ),
                          ),
                          Expanded(
                            child: TextFormFieldWidget(
                              maxLines: 1,
                              hintText: 'Solde Virtuel CDF',
                              editCtrller: _soldeVCDFCtrller,
                              textColor: AppColors.kWhiteColor,
                              backColor: AppColors.kTextFormWhiteColor,
                            ),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: TextFormFieldWidget(
                              maxLines: 1,
                              hintText: 'Solde Cash USD',
                              editCtrller: _soldeCaUSDCtrller,
                              textColor: AppColors.kWhiteColor,
                              backColor: AppColors.kTextFormWhiteColor,
                            ),
                          ),
                          Expanded(
                            child: TextFormFieldWidget(
                              maxLines: 1,
                              hintText: 'Solde Cash CDF',
                              editCtrller: _soldeCaCDFCtrller,
                              textColor: AppColors.kWhiteColor,
                              backColor: AppColors.kTextFormWhiteColor,
                            ),
                          ),
                        ],
                      ),
                      Consumer<AdminUserStateProvider>(
                          builder: (context, userStateProvider, _) {
                        return Row(children: [
                          Expanded(
                            child: CustomButton(
                              text: 'Supprimer',
                              backColor: AppColors.kRedColor,
                              textColor: AppColors.kWhiteColor,
                              callback: () {},
                            ),
                          ),
                          Expanded(
                            child: CustomButton(
                              text: 'Suspendre',
                              backColor: AppColors.kRedColor.withOpacity(0.5),
                              textColor: AppColors.kWhiteColor,
                              callback: () {},
                            ),
                          ),
                          Expanded(
                              child: CustomButton(
                            text: 'Modifier',
                            backColor: AppColors.kYellowColor,
                            textColor: AppColors.kWhiteColor,
                            callback: () {
                              Map data = {
                                "id": widget.creationActiviteModel!.id,
                                "designation": _activiteCtrller.text.trim(),
                                "caissier": _nomcaissierCtrller.text.trim(),
                                "solde_virtuel_CDF":
                                    _soldeVCDFCtrller.text.trim(),
                                "solde_virtuel_USD":
                                    _soldeVUSDCtrller.text.trim(),
                                "solde_cash_CDF":
                                    _soldeCaCDFCtrller.text.trim(),
                                "solde_cash_USD":
                                    _soldeCaUSDCtrller.text.trim(),
                              };

                              userStateProvider.updateCaisse(
                                  context: context,
                                  caisse: CaisseModel.fromJson(data),
                                  callback: () {
                                    Navigator.pop(context);
                                  });
                            },
                          ))
                        ]);
                      }),
                    ]),

                    //DisplayCaissePage()
                  )
                ]),
          );
        }));
  }
}
