import 'package:orion/Views/Admin_Orion/Resources/AppStateProvider/app_stateprovider.dart';

import 'package:orion/Views/Admin_Orion/Resources/AppStateProvider/user_stateprovider.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/button.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/dropdown_button.dart';

import 'package:orion/Views/Admin_Orion/Resources/Components/card.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/modal_progress.dart';

import 'package:orion/Views/Admin_Orion/Resources/Components/text_fields.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/texts.dart';
import 'package:orion/Views/Admin_Orion/Resources/Models/Guichet/activite_model.dart';

import 'package:orion/Views/Admin_Orion/Resources/Models/utilisateur_model.dart';
import 'package:orion/Views/Admin_Orion/Resources/global_variables.dart';
import 'package:flutter/material.dart';
import 'package:orion/Views/Admin_Orion/Resources/responsive.dart';
import 'package:provider/provider.dart';

class UpdateUserPage extends StatefulWidget {
  final bool updatingData;
  final ClientModel? clientModel;
  const UpdateUserPage({Key? key, required this.updatingData, this.clientModel})
      : super(key: key);
  @override
  _UpdateUserPageState createState() => _UpdateUserPageState();
}

List<String> typeactiviteList = ["Mobile Money", "Autres"];
late String typeactiviteMode = "Mobile Money";

String? nomFournisseur;
String? membreInterne;

String? nomMembre;

class _UpdateUserPageState extends State<UpdateUserPage> {
  final PageController _controller = PageController();
  final TextEditingController _nameCtrller = TextEditingController();
  final TextEditingController _roleCtrller = TextEditingController();
  final TextEditingController _usernameCtrller = TextEditingController();
  final TextEditingController _pwdCtrller = TextEditingController();
  final TextEditingController _mailCtrller = TextEditingController();
  final TextEditingController _telephCtrller = TextEditingController();
  final TextEditingController _pwhCtrller = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.updatingData == true) {
      _nameCtrller.text = widget.clientModel!.names.trim();
      _usernameCtrller.text = widget.clientModel!.username.toString().trim();
      _roleCtrller.text = widget.clientModel!.password.toString().trim();
      _mailCtrller.text = widget.clientModel!.email.toString().trim();
      _telephCtrller.text = widget.clientModel!.telephone.toString().trim();
      _pwhCtrller.text = widget.clientModel!.password.toString().trim();
    }
    WidgetsBinding.instance!.addPostFrameCallback((timeStamp) {
      //Provider.of<UserStateProvider>(context, listen: false)
      // .getuser(context: context, isRefreshed: false);
    });
  }

  List<String> genderList = ["Homme", "Femme"];
  String currentGender = "Homme";
  List<String> typeUserList = ["Caissier", "Agregateur", "admin"];
  String currentUser = "Caissier";

  // String currentRole = "Backoffice";
  String currentUserType = "Backoffice";
  @override
  Widget build(BuildContext context) {
    return Container(
        width: Responsive.isMobile(context)
            ? MediaQuery.of(context).size.width
            : MediaQuery.of(context).size.width / 2,
        height: MediaQuery.of(context).size.height * .85,
        color: AppColors.kBlackLightColor,
        child: Consumer<adminAppStateProvider>(
            builder: (context, appStateProvider, _) {
          return ModalProgress(
              isAsync: appStateProvider.isAsync,
              progressColor: AppColors.kYellowColor,
              child: ListView(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  CardWidget(
                    backColor: AppColors.kBlackLightColor,
                    title: 'Ajouter un utilisateur',
                    content: Wrap(
                      children: [
                        Row(children: [
                          Expanded(
                            child: TextFormFieldWidget(
                              maxLines: 1,
                              editCtrller: _nameCtrller,
                              hintText: 'Noms',
                              textColor: AppColors.kWhiteColor,
                              backColor: AppColors.kTextFormWhiteColor,
                            ),
                          ),
                          Expanded(
                            child: TextFormFieldWidget(
                              maxLines: 1,
                              editCtrller: _usernameCtrller,
                              hintText: 'Nom d\'Utilisateur',
                              textColor: AppColors.kWhiteColor,
                              backColor: AppColors.kTextFormWhiteColor,
                            ),
                          ),
                        ]),
                        Row(children: [
                          // Expanded(
                          //   child: TextFormFieldWidget(
                          //     maxLines: 1,
                          //     editCtrller: _surnameCtrller,
                          //     hintText: 'Prenom',
                          //     textColor: AppColors.kWhiteColor,
                          //     backColor: AppColors.kTextFormWhiteColor,
                          //   ),
                          // ),
                          // Expanded(
                          //   child: GestureDetector(
                          //     child: TextFormFieldWidget(
                          //         backColor: AppColors.kTextFormBackColor,
                          //         hintText: 'Date de naissance',
                          //         isEnabled: false,
                          //         isObsCured: false,
                          //         editCtrller: _dobCtrller,
                          //         textColor: AppColors.kWhiteColor,
                          //         maxLines: 1),
                          //     onTap: () async {
                          //       var picked = await showDatePicker(
                          //           context: context,
                          //           initialDate: DateTime.now()
                          //               .subtract(const Duration(days: 365 * 20)),
                          //           firstDate: DateTime.now()
                          //               .subtract(const Duration(days: 365 * 20)),
                          //           lastDate: DateTime.now());
                          //       if (picked == null) return;
                          //       _dobCtrller.text =
                          //           picked.toString().substring(0, 10);
                          //       setState(() {});
                          //     },
                          //   ),
                          // ),
                        ]),
                        Row(children: [
                          // Expanded(
                          //   child: CustomDropdownButton(
                          //       value: currentGender,
                          //       hintText: "Genre",
                          //       callBack: (newValue) {
                          //         setState(() {
                          //           currentGender = newValue;
                          //         });
                          //       },
                          //       items: genderList),
                          // ),
                          // Expanded(
                          //   child: CustomDropdownButton(
                          //       value: currentmarriagestatus,
                          //       hintText: "Etat Civil",
                          //       callBack: (newValue) {
                          //         setState(() {
                          //           currentmarriagestatus = newValue;
                          //         });
                          //       },
                          //       items: marriagestatusList),
                          // ),
                          Expanded(
                            child: CustomDropdownButton(
                                value: currentUser,
                                hintText: "Role",
                                callBack: (newValue) {
                                  setState(() {
                                    currentUser = newValue;
                                  });
                                },
                                items: typeUserList),
                          ),
                        ]),
                        // Row(children: [
                        //   Expanded(
                        //     child: TextFormFieldWidget(
                        //       maxLines: 1,
                        //       editCtrller: _countryCtrller,
                        //       hintText: 'Pays',
                        //       textColor: AppColors.kWhiteColor,
                        //       backColor: AppColors.kTextFormWhiteColor,
                        //     ),
                        //   ),
                        //   Expanded(
                        //     child: TextFormFieldWidget(
                        //       maxLines: 1,
                        //       editCtrller: _addressCtrller,
                        //       hintText: 'Address',
                        //       textColor: AppColors.kWhiteColor,
                        //       backColor: AppColors.kTextFormWhiteColor,
                        //     ),
                        //   ),
                        // ]),
                        Row(children: [
                          Expanded(
                            child: TextFormFieldWidget(
                              maxLines: 1,
                              editCtrller: _telephCtrller,
                              hintText: 'Telephone',
                              textColor: AppColors.kWhiteColor,
                              backColor: AppColors.kTextFormWhiteColor,
                            ),
                          ),
                          Expanded(
                            child: TextFormFieldWidget(
                              maxLines: 1,
                              editCtrller: _mailCtrller,
                              hintText: 'Email',
                              textColor: AppColors.kWhiteColor,
                              backColor: AppColors.kTextFormWhiteColor,
                            ),
                          ),
                        ]),
                        Row(children: [
                          // Expanded(
                          //   child: TextFormFieldWidget(
                          //     maxLines: 1,
                          //     editCtrller: _usernameCtrller,
                          //     hintText: 'Username',
                          //     textColor: AppColors.kWhiteColor,
                          //     backColor: AppColors.kTextFormWhiteColor,
                          //   ),
                          // ),
                          Expanded(
                            child: TextFormFieldWidget(
                              maxLines: 1,
                              editCtrller: _pwdCtrller,
                              hintText: 'Mot de passe',
                              textColor: AppColors.kWhiteColor,
                              backColor: AppColors.kTextFormWhiteColor,
                            ),
                          ),
                        ]),
                        Consumer<AdminUserStateProvider>(
                            builder: (context, userStateProvider, _) {
                          return Row(children: [
                            Expanded(
                              child: CustomButton(
                                text: 'Supprimer',
                                backColor: AppColors.kRedColor,
                                textColor: AppColors.kWhiteColor,
                                callback: () {},
                              ),
                            ),
                            Expanded(
                              child: CustomButton(
                                text: 'Suspendre',
                                backColor: AppColors.kRedColor.withOpacity(0.5),
                                textColor: AppColors.kWhiteColor,
                                callback: () {},
                              ),
                            ),
                            Expanded(
                                child: CustomButton(
                              text: 'Modifier',
                              backColor: AppColors.kYellowColor,
                              textColor: AppColors.kWhiteColor,
                              callback: () {
                                Map data = {
                                  "id": widget.clientModel!.id,
                                  "names": _nameCtrller.text.trim(),

                                  "telephone": _telephCtrller.text.trim(),
                                  // "address": _addressCtrller.text.trim(),
                                  "email": _mailCtrller.text.trim(),
                                  "username": _usernameCtrller.text.trim(),
                                  "password": _pwdCtrller.text.trim(),
                                  "role": currentUser,
                                };

                                userStateProvider.updateUser(
                                    context: context,
                                    client: ClientModel.fromJson(data),
                                    //updatingData: widget.updatingData,
                                    callback: () {});
                              },
                            ))
                          ]);
                        })
                      ],
                    ),
                  ),
                ],
              ));
        }));
  }
}
