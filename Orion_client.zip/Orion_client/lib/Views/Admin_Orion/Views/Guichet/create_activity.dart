import 'package:orion/Views/Admin_Orion/Resources/AppStateProvider/app_stateprovider.dart';

import 'package:orion/Views/Admin_Orion/Resources/AppStateProvider/user_stateprovider.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/button.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/dropdown_button.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/empty_model.dart';

import 'package:orion/Views/Admin_Orion/Resources/Components/card.dart';

import 'package:orion/Views/Admin_Orion/Resources/Components/text_fields.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/texts.dart';

import 'package:orion/Views/Admin_Orion/Resources/Models/Guichet/create_activity_model.dart';
import 'package:orion/Views/Admin_Orion/Resources/global_variables.dart';
import 'package:orion/Views/Admin_Orion/Views/Guichet/update_activity.dart';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';

class CreateActivityPage extends StatefulWidget {
  final bool updatingData;

  final CreatActiviteModel? creationActiviteModel;
  const CreateActivityPage(
      {Key? key, required this.updatingData, this.creationActiviteModel})
      : super(key: key);

  @override
  _CreateActivityPageState createState() => _CreateActivityPageState();
}

List<String> typeactiviteList = ["Mobile Money", "Autres"];
late String typeactiviteMode = "Mobile Money";

String? nomFournisseur;
String? membreInterne;

String? nomMembre;

class _CreateActivityPageState extends State<CreateActivityPage> {
  final PageController _controller = PageController();
  String? sousCompteId;
  final TextEditingController _designationCtrller = TextEditingController();
  final TextEditingController _descriptCtrller = TextEditingController();
  final TextEditingController _typeCtrller = TextEditingController();
  //final TextEditingController _avatarCtrller = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.updatingData == true) {
      _designationCtrller.text =
          widget.creationActiviteModel!.designation.trim();
      _descriptCtrller.text = widget.creationActiviteModel!.description.trim();
      _typeCtrller.text =
          widget.creationActiviteModel!.type_activite.toString().trim();
    }
    WidgetsBinding.instance!.addPostFrameCallback((timeStamp) {
      // Provider.of<ConstEpargnStateProvider>(context, listen: false)
      //     .getconstepargne(context: context, isRefreshed: false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AdminUserStateProvider>(
        builder: (context, userStateProvider, _) {
      return Scaffold(
        body: SingleChildScrollView(
          controller: _controller,
          child: Column(
            children: [
              // GestureDetector(
              //   onTap: () {},
              //   child: Icon(Icons.edit, color: AppColors.kGreenColor),
              // ),
              // const SizedBox(width: 10),
              // GestureDetector(
              //   child: Icon(Icons.delete, color: AppColors.kRedColor),
              // ),
              // const AppLogo(size: Size(100, 100)),
              CardWidget(
                  backColor: AppColors.kBlackLightColor,
                  title: 'Creation des Activites',
                  content: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: TextFormFieldWidget(
                              maxLines: 1,
                              hintText: 'Designation',
                              editCtrller: _designationCtrller,
                              textColor: AppColors.kWhiteColor,
                              backColor: AppColors.kTextFormWhiteColor,
                            ),
                          ),
                          Expanded(
                            child: TextFormFieldWidget(
                              maxLines: 1,
                              hintText: 'Description',
                              editCtrller: _descriptCtrller,
                              textColor: AppColors.kWhiteColor,
                              backColor: AppColors.kTextFormWhiteColor,
                            ),
                          )
                        ],
                      ),
                      Row(
                        children: [
                          Expanded(
                              child: CustomDropdownButton(
                                  value: typeactiviteMode,
                                  hintText: "Type d\'activites ",
                                  callBack: (newValue) {
                                    setState(() {
                                      typeactiviteMode = newValue;
                                    });
                                  },
                                  items: typeactiviteList)),
                          // Expanded(
                          //   child: TextFormFieldWidget(
                          //     maxLines: 1,
                          //     hintText: 'Avatar',
                          //     editCtrller: _avatarCtrller,
                          //     textColor: AppColors.kWhiteColor,
                          //     backColor: AppColors.kTextFormWhiteColor,
                          //   ),
                          // ),
                        ],
                      ),
                      CustomButton(
                          text: 'Add a file',
                          //  icon: Icons.add_to_photos_rounded,
                          backColor: AppColors.kBlackColor,
                          textColor: AppColors.kWhiteColor,
                          callback: () async {
                            FilePickerResult? fileResult =
                                await FilePicker.platform.pickFiles(
                                    allowMultiple: true,
                                    type: FileType.custom,
                                    allowedExtensions: [
                                  "png",
                                  "pdf",
                                  "jpg",
                                  "jpeg",
                                  "doc",
                                  "docx"
                                ]);
                            if (fileResult != null && fileResult.count > 0) {
                              userStateProvider.addFiles(
                                  context: context,
                                  picked: fileResult.files,
                                  callback: () {});
                            }
                          }),
                      Consumer<AdminUserStateProvider>(
                          builder: (context, creationActiviteModel, _) {
                        return CustomButton(
                          text: 'Enregistrer',
                          backColor: AppColors.kYellowColor,
                          textColor: AppColors.kWhiteColor,
                          callback: () {
                            Map data = {
                              "designation": _designationCtrller.text.trim(),
                              "description": _descriptCtrller.text.trim(),
                              "type_activite": typeactiviteMode,
                            };
                            userStateProvider.addactivities(
                                context: context,
                                creationActiviteModel:
                                    CreatActiviteModel.fromJson(data),
                                updatingData: widget.updatingData,
                                callback: () {});
                          },
                        );
                      }),
                    ],
                  )),

              DisplayCreateactivityPage()
            ],
          ),
        ),
      );
    });
  }
}

fileContainer({required PlatformFile file}) {
  return GestureDetector(
    onTap: () {
      // showCupertinoModalPopup(
      //     context: context,
      //     builder: (builder) {
      //       return Center(
      //         child: Container(
      //           padding: const EdgeInsets.all(10),
      //           child: Image.memory(file.bytes!),
      //         ),
      //       );
      //     });
    },
    child: Container(
        color: Colors.white.withOpacity(0.1),
        child: Stack(children: [
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            child: Container(
              width: double.maxFinite,
              height: double.maxFinite,
              padding: const EdgeInsets.all(0),
              child: Image.memory(
                file.bytes!,
                fit: BoxFit.cover,
              ),
            ),
          ),
          Positioned(
              left: 0,
              right: 0,
              bottom: -2,
              child: Container(
                padding: EdgeInsets.all(5),
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.bottomCenter,
                        end: Alignment.topCenter,
                        colors: [Colors.black, Colors.black.withOpacity(0.5)])),
                child: TextWidgets.textBold(
                    title: file.name,
                    fontSize: 12,
                    textColor: AppColors.kWhiteColor),
              )),
          Positioned(
              right: 0,
              top: 0,
              child: Container(
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    borderRadius: const BorderRadius.only(
                        bottomLeft: Radius.circular(10))),
                child: TextWidgets.text300(
                    title:
                        "${((file.size / 1024) / 1024).toStringAsFixed(2)} mb",
                    fontSize: 10,
                    textColor: AppColors.kWhiteColor),
              )),
        ])),
  );
}

class DisplayCreateactivityPage extends StatelessWidget {
  const DisplayCreateactivityPage({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Consumer<AdminUserStateProvider>(
      builder: (context, userStateProvider, child) {
        return userStateProvider.activitiesdata.isNotEmpty
            ? Column(
                children: [
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          flex: 4,
                          child: TextWidgets.text300(
                              title: 'Designation',
                              fontSize: 14,
                              textColor: AppColors.kBlackLightColor),
                        ),
                        Expanded(
                          flex: 2,
                          child: TextWidgets.text300(
                              title: 'Description',
                              fontSize: 14,
                              textColor: AppColors.kBlackLightColor),
                        ),
                        Expanded(
                          flex: 2,
                          child: TextWidgets.text300(
                              title: 'Type activites',
                              fontSize: 14,
                              textColor: AppColors.kBlackLightColor),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 10),
                    child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: userStateProvider.activitiesdata.length,
                        itemBuilder: (context, int index) {
                          return GestureDetector(
                            onTap: () {
                              showCupertinoModalPopup(
                                  context: context,
                                  builder: (context) => Center(
                                          child: UpdateActivityPage(
                                        creationActiviteModel: userStateProvider
                                            .activitiesdata[index],
                                        updatingData: true,
                                      )));
                              // child:
                              // Icon(Icons.edit, color: AppColors.kGreenColor);

                              // const SizedBox(width: 10);
                              // GestureDetector(
                              //   child: Icon(Icons.delete,
                              //       color: AppColors.kRedColor),
                              // );
                            },
                            child: Column(
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 5, vertical: 10),
                                  color: index % 2 == 0
                                      ? AppColors.kBlackLightColor
                                      : AppColors.kBlackLightColor,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Expanded(
                                        flex: 4,
                                        child: TextWidgets.text300(
                                            title: userStateProvider
                                                .activitiesdata[index]
                                                .designation
                                                .toString()
                                                .trim(),
                                            fontSize: 14,
                                            textColor: AppColors.kWhiteColor),
                                      ),
                                      Expanded(
                                        flex: 2,
                                        child: TextWidgets.text300(
                                            title: userStateProvider
                                                .activitiesdata[index]
                                                .description
                                                .toString()
                                                .trim(),
                                            fontSize: 14,
                                            textColor: AppColors.kWhiteColor),
                                      ),
                                      Expanded(
                                        flex: 2,
                                        child: TextWidgets.text300(
                                            title: userStateProvider
                                                .activitiesdata[index]
                                                .type_activite
                                                .toString()
                                                .trim(),
                                            fontSize: 14,
                                            textColor: AppColors.kWhiteColor),
                                      ),
                                    ],
                                  ),
                                ),
                                Divider(
                                    height: 2,
                                    thickness: 1,
                                    color:
                                        AppColors.kWhiteColor.withOpacity(0.4))
                              ],
                            ),
                          );
                        }),
                  )
                ],
              )
            : EmptyModel(color: AppColors.kGreyColor);
      },
    );
  }
}
