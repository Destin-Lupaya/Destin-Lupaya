import 'package:orion/Views/Admin_Orion/Resources/AppStateProvider/app_stateprovider.dart';

import 'package:orion/Views/Admin_Orion/Resources/AppStateProvider/user_stateprovider.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/button.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/dropdown_button.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/empty_model.dart';

import 'package:orion/Views/Admin_Orion/Resources/Components/card.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/modal_progress.dart';

import 'package:orion/Views/Admin_Orion/Resources/Components/text_fields.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/texts.dart';

import 'package:orion/Views/Admin_Orion/Resources/Models/Guichet/create_activity_model.dart';
import 'package:orion/Views/Admin_Orion/Resources/global_variables.dart';
import 'package:orion/Views/Admin_Orion/Resources/responsive.dart';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';

class UpdateActivityPage extends StatefulWidget {
  final bool updatingData;

  final CreatActiviteModel? creationActiviteModel;
  const UpdateActivityPage(
      {Key? key, required this.updatingData, this.creationActiviteModel})
      : super(key: key);

  @override
  _UpdateActivityPageState createState() => _UpdateActivityPageState();
}

List<String> typeactiviteList = ["Mobile Money", "Autres"];
late String typeactiviteMode = "Mobile Money";

String? nomFournisseur;
String? membreInterne;

String? nomMembre;

class _UpdateActivityPageState extends State<UpdateActivityPage> {
  final PageController _controller = PageController();
  String? sousCompteId;
  final TextEditingController _designationCtrller = TextEditingController();
  final TextEditingController _descriptCtrller = TextEditingController();
  final TextEditingController _typeCtrller = TextEditingController();
  //final TextEditingController _avatarCtrller = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.updatingData == true) {
      _designationCtrller.text =
          widget.creationActiviteModel!.designation.trim();
      _descriptCtrller.text = widget.creationActiviteModel!.description.trim();
      _typeCtrller.text =
          widget.creationActiviteModel!.type_activite.toString().trim();
    }
    WidgetsBinding.instance!.addPostFrameCallback((timeStamp) {
      // Provider.of<ConstEpargnStateProvider>(context, listen: false)
      //     .getconstepargne(context: context, isRefreshed: false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AdminUserStateProvider>(
        builder: (context, userStateProvider, _) {
      return Container(
          width: Responsive.isMobile(context)
              ? MediaQuery.of(context).size.width
              : MediaQuery.of(context).size.width / 2,
          height: MediaQuery.of(context).size.height * .85,
          color: AppColors.kBlackLightColor,
          child: Consumer<adminAppStateProvider>(
              builder: (context, appStateProvider, _) {
            return ModalProgress(
              isAsync: appStateProvider.isAsync,
              progressColor: AppColors.kYellowColor,
              child: ListView(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  CardWidget(
                      backColor: AppColors.kBlackLightColor,
                      title: 'Creation des Activites',
                      content: Column(
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: TextFormFieldWidget(
                                  maxLines: 1,
                                  hintText: 'Designation',
                                  editCtrller: _designationCtrller,
                                  textColor: AppColors.kWhiteColor,
                                  backColor: AppColors.kTextFormWhiteColor,
                                ),
                              ),
                              Expanded(
                                child: TextFormFieldWidget(
                                  maxLines: 1,
                                  hintText: 'Description',
                                  editCtrller: _descriptCtrller,
                                  textColor: AppColors.kWhiteColor,
                                  backColor: AppColors.kTextFormWhiteColor,
                                ),
                              )
                            ],
                          ),
                          Row(
                            children: [
                              Expanded(
                                  child: CustomDropdownButton(
                                      value: typeactiviteMode,
                                      hintText: "Type d\'activites ",
                                      callBack: (newValue) {
                                        setState(() {
                                          typeactiviteMode = newValue;
                                        });
                                      },
                                      items: typeactiviteList)),
                              // Expanded(
                              //   child: TextFormFieldWidget(
                              //     maxLines: 1,
                              //     hintText: 'Avatar',
                              //     editCtrller: _avatarCtrller,
                              //     textColor: AppColors.kWhiteColor,
                              //     backColor: AppColors.kTextFormWhiteColor,
                              //   ),
                              // ),
                            ],
                          ),
                          CustomButton(
                              text: 'Add a file',
                              //  icon: Icons.add_to_photos_rounded,
                              backColor: AppColors.kBlackColor,
                              textColor: AppColors.kWhiteColor,
                              callback: () async {
                                FilePickerResult? fileResult =
                                    await FilePicker.platform.pickFiles(
                                        allowMultiple: true,
                                        type: FileType.custom,
                                        allowedExtensions: [
                                      "png",
                                      "pdf",
                                      "jpg",
                                      "jpeg",
                                      "doc",
                                      "docx"
                                    ]);
                                if (fileResult != null &&
                                    fileResult.count > 0) {
                                  userStateProvider.addFiles(
                                      context: context,
                                      picked: fileResult.files,
                                      callback: () {});
                                }
                              }),
                          Consumer<AdminUserStateProvider>(
                              builder: (context, creationActiviteModel, _) {
                            return Row(
                              children: [
                                Expanded(
                                  child: CustomButton(
                                    text: 'Supprimer',
                                    backColor: AppColors.kRedColor,
                                    textColor: AppColors.kWhiteColor,
                                    callback: () {},
                                  ),
                                ),
                                Expanded(
                                  child: CustomButton(
                                    text: 'Suspendre',
                                    backColor:
                                        AppColors.kRedColor.withOpacity(0.5),
                                    textColor: AppColors.kWhiteColor,
                                    callback: () {},
                                  ),
                                ),
                                Expanded(
                                    child: CustomButton(
                                  text: 'Modifier',
                                  backColor: AppColors.kYellowColor,
                                  textColor: AppColors.kWhiteColor,
                                  callback: () {
                                    Map data = {
                                      "id": widget.creationActiviteModel!.id,
                                      "designation":
                                          _designationCtrller.text.trim(),
                                      "description":
                                          _descriptCtrller.text.trim(),
                                      "type_activite": typeactiviteMode,
                                    };
                                    userStateProvider.updateactivities(
                                        context: context,
                                        activity:
                                            CreatActiviteModel.fromJson(data),
                                        //updatingData: widget.updatingData,
                                        callback: () {});
                                  },
                                ))
                              ],
                            );
                          }),
                        ],
                      )),
                ],
              ),
            );
          }));
    });
  }
}
