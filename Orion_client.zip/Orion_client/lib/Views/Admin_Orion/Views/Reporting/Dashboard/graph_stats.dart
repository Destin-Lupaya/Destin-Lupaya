import 'package:orion/Views/Admin_Orion/Resources/Components/texts.dart';
import 'package:orion/Views/Admin_Orion/Resources/global_variables.dart';
import 'package:flutter/material.dart';
import 'package:pie_chart/pie_chart.dart';

class GraphStatsWidget extends StatefulWidget {
  const GraphStatsWidget({Key? key}) : super(key: key);

  @override
  State<GraphStatsWidget> createState() => _GraphStatsWidgetState();
}

class _GraphStatsWidgetState extends State<GraphStatsWidget> {
  Map<String, double> dataMap = {
    "Credits": 80,
    "Rembourses": 50,
    "En cours": 12,
    "Abandon": 18,
  };
  Map<String, double> dataRemboursement = {
    "Montant credit": 1906,
    "Montant rembourse": 1006,
    "Montant perdu": 500,
    "Restant": 400,
  };
  @override
  Widget build(BuildContext context) {
    return Card(
      color: AppColors.kBlackColor.withOpacity(0.5),
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(kDefaultPadding / 2)),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextWidgets.textNormal(
                title: 'All expenses',
                fontSize: 18,
                textColor: AppColors.kWhiteColor),
            const SizedBox(
              height: 20,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                cardStatsWidget(
                    title: 'Weekly',
                    textColor: AppColors.kGreyColor,
                    backColor: AppColors.kBlackLightColor,
                    value: '10877',
                    currency: '\$'),
                cardStatsWidget(
                    title: 'Monthly',
                    textColor: AppColors.kGreyColor,
                    backColor: AppColors.kBlackLightColor,
                    value: '10877',
                    currency: '\$'),
                cardStatsWidget(
                    title: 'Yearly',
                    textColor: AppColors.kGreyColor,
                    backColor: AppColors.kBlackLightColor,
                    value: '10877',
                    currency: '\$'),
              ],
            ),

            // PieChart(dataMap: dataRemboursement),
            Container(
              padding: EdgeInsets.zero,
              child: chart(title: 'Credits', data: dataMap),
            ),
            Container(
              padding: EdgeInsets.zero,
              child: chart(title: 'Montant', data: dataRemboursement),
            ),
          ],
        ),
      ),
    );
  }

  chart({required String title, required Map<String, double> data}) {
    return PieChart(
      dataMap: data,
      animationDuration: const Duration(milliseconds: 800),
      colorList: const [
        Colors.red,
        Colors.blue,
        Colors.orange,
        Colors.purple,
        Colors.cyan
      ],
      chartLegendSpacing: 8,
      chartRadius: MediaQuery.of(context).size.width / 3.2,
      initialAngleInDegree: 0,
      chartType: ChartType.disc,
      ringStrokeWidth: 30,
      centerText: title,
      legendOptions: const LegendOptions(
        showLegendsInRow: false,
        legendPosition: LegendPosition.right,
        showLegends: true,
        legendTextStyle: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
        ),
      ),
      chartValuesOptions: const ChartValuesOptions(
        chartValueStyle:
            TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        chartValueBackgroundColor: Colors.transparent,
        showChartValues: true,
        showChartValuesInPercentage: false,
        showChartValuesOutside: false,
        decimalPlaces: 1,
      ),
    );
  }

  cardStatsWidget(
      {required String title,
      required Color textColor,
      required Color backColor,
      required String value,
      required String currency}) {
    return Expanded(
      child: Card(
        color: backColor,
        margin: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(kDefaultPadding / 2)),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                      child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextWidgets.text300(
                          title: title, fontSize: 14, textColor: textColor),
                    ],
                  )),
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              Row(
                children: [
                  TextWidgets.textBold(
                      title: value, fontSize: 16, textColor: textColor),
                  const SizedBox(
                    width: 5,
                  ),
                  TextWidgets.textBold(
                      title: currency, fontSize: 16, textColor: textColor),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
