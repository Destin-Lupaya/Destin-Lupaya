import 'package:orion/Views/Admin_Orion/Resources/AppStateProvider/app_stateprovider.dart';
import 'package:orion/Views/Admin_Orion/Resources/Components/texts.dart';
import 'package:orion/Views/Admin_Orion/Resources/global_variables.dart';
import 'package:orion/Views/Admin_Orion/Resources/responsive.dart';
import 'package:orion/Views/Guichet/Historique/historique_transaction.dart';
import 'package:orion/Views/Admin_Orion/Views/Reporting/Dashboard/last_transactions.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

class HomeDashboardPage extends StatefulWidget {
  @override
  _HomeDashboardPageState createState() => _HomeDashboardPageState();
}

class _HomeDashboardPageState extends State<HomeDashboardPage> {
  ScrollController _controller = ScrollController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          controller: _controller,
          child: Responsive(
            mobile: Column(
              children: [
                // cardStatsWidget(
                //     title: 'Envoie CDF',
                //     subtitle: 'Credits CDF Envoye',
                //     icon: Icons.credit_card,
                //     textColor: AppColors.kWhiteColor,
                //     backColor: AppColors.kBlackColor,
                //     value: "908",
                //     value2: "79877",
                //     currency: 'FC'),
                // cardStatsWidget(
                //     title: 'Depot CDF',
                //     subtitle: 'Montant CDF Encaisse',
                //     icon: Icons.credit_score,
                //     textColor: AppColors.kWhiteColor,
                //     backColor: AppColors.kBlackColor,
                //     value: "876",
                //     value2: "6878",
                //     currency: 'FC'),
                // GraphStatsWidget(),
                LastTransactionList(),
              ],
            ),
            tablet: Column(
              children: [
                const SizedBox(
                  height: 0,
                ),
                Row(
                  children: [
                    // Expanded(
                    //     child: cardStatsWidget(
                    //         title: 'Credits Envoyé en USD',
                    //         subtitle: 'Montant Envoyés en USD',
                    //         icon: Icons.credit_card,
                    //         textColor: AppColors.kWhiteColor,
                    //         backColor: AppColors.kBlackColor,
                    //         value: "908",
                    //         value2: "79877",
                    //         currency: 'USD')),
                    // Expanded(
                    //   child: cardStatsWidget(
                    //       title: 'Credit Encaissé en USD  ',
                    //       subtitle: 'Montant Encaissés en USD',
                    //       icon: Icons.credit_score,
                    //       textColor: AppColors.kWhiteColor,
                    //       backColor: AppColors.kBlackColor,
                    //       value: "876",
                    //       value2: "6878",
                    //       currency: 'USD'),
                    // ),
                  ],
                ),
                const SizedBox(
                  height: 20,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    //Expanded(flex: 4, child: LastTransactionList()),
                    Expanded(flex: 3, child: HistortransList()),
                  ],
                )
              ],
            ),
            web: Column(
              children: [
                const SizedBox(
                  height: 0,
                ),
                Row(
                  children: [
                    // Expanded(
                    //   child: cardStatsWidget(
                    //       title: 'Fonds Envoyé en USD',
                    //       subtitle: 'compte dollar ',
                    //       icon: Icons.credit_score,
                    //       textColor: AppColors.kWhiteColor,
                    //       backColor: AppColors.kBlackColor,
                    //       value: "876",
                    //       value2: "6878",
                    //       currency: 'USD'),
                    // ),
                    //     Expanded(
                    //         child: cardStatsWidget(
                    //             title: ' Fonds Envoyé en CDF',
                    //             subtitle: 'compte Franc Congolais',
                    //             icon: Icons.credit_card,
                    //             textColor: AppColors.kWhiteColor,
                    //             backColor: AppColors.kBlackColor,
                    //             value: "908",
                    //             value2: "79877",
                    //             currency: 'USD')),
                  ],
                ),
                const SizedBox(
                  height: 20,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(flex: 4, child: HistortransList()),
                    // Expanded(flex: 3, child: GraphStatsWidget()),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  cardStatsWidget(
      {required String title,
      required String subtitle,
      required IconData icon,
      required Color textColor,
      required Color backColor,
      required String value,
      required String value2,
      required String currency}) {
    return Container(
      child: Card(
        color: backColor,
        margin: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(kDefaultPadding / 2)),
        child: Container(
          // width: double.maxFinite,
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                      child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextWidgets.textBold(
                          title: title, fontSize: 16, textColor: textColor),
                      TextWidgets.text300(
                          title: subtitle, fontSize: 12, textColor: textColor),
                    ],
                  )),
                  Container(
                    padding: const EdgeInsets.all(8),
                    child: Icon(icon),
                  )
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              Row(
                children: [
                  Expanded(
                      child: Row(children: [
                    TextWidgets.textBold(
                        title: value, fontSize: 20, textColor: textColor),
                  ])),
                  Expanded(
                      child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextWidgets.textBold(
                          title: value2, fontSize: 20, textColor: textColor),
                      const SizedBox(
                        width: 10,
                      ),
                      TextWidgets.textBold(
                          title: currency, fontSize: 20, textColor: textColor),
                    ],
                  )),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
