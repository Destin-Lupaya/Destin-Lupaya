import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

double kDefaultPadding = 20;

List<String> genderList = ['Masculin', 'Feminin'];

class AppColors {
  static Color kPrimaryColor = Colors.blue.shade900;
  static Color kSecondaryColor = Colors.blue;
  static Color kBlackColor = Colors.black;
  static Color kBlackLightColor = const Color.fromRGBO(24, 24, 24, 1);
  static Color kWhiteColor = Colors.white;
  static Color kWhiteDarkColor = Colors.grey.shade400;
  static Color kGreenColor = Colors.green;
  static Color kRedColor = Colors.red;
  static Color kGreyColor = Colors.grey;
  // static Color kYellowColor = const Color.fromRGBO(255, 184, 57, 1);
  static Color kYellowColor = const Color.fromRGBO(255, 185, 35, 1);
  static Color kTextFormWhiteColor = Colors.white.withOpacity(0.05);
  static Color kTextFormBackColor = Colors.black.withOpacity(0.1);
  static Color kTransparentColor = Colors.transparent;
}

class Navigation {
  static pushNavigate({required BuildContext context, required Widget page}) {
    Navigator.push(context, CupertinoPageRoute(builder: (context) => page));
  }

  static pushReplaceNavigate(
      {required BuildContext context, required Widget page}) {
    Navigator.pushReplacement(
        context, CupertinoPageRoute(builder: (context) => page));
  }
}

class Theme {
  // Enum themeVariant={"Light", Dark};

}

class Message {
  static showToast({required String msg}) {
    Fluttertoast.showToast(
        toastLength: Toast.LENGTH_LONG, msg: msg, gravity: ToastGravity.BOTTOM);
  }
}

class BaseUrl {
  static String ip = "http://192.168.2.145:8000";
  static String apiUrl = "$ip/api";
  static String getLogin = '$apiUrl/user/login/';
  static String addUser = '$apiUrl/users/';
  static String user = '$apiUrl/users/';

  // Statement position (Possession, liabilities, monthly income, monthly expenses)
  static String statementPosition = '$apiUrl/statmentposition/';
  // External loans (from other lenders)
  static String externalLoansHistory = '$apiUrl/externalloanhistory/';
  // Nominated administrator and closest relation
  static String payablePerson = '$apiUrl/payableperson/';
  // Employer information
  static String employer = '$apiUrl/employementdetails/';
  static String loanType = '$apiUrl/loantype/';
  static String wayOfPayments = '$apiUrl/wayspayment/';
  static String bank = '$apiUrl/clientbank/';
  static String loan = '$apiUrl/loan/';
  static String refundCalendar = '$apiUrl/refundcalendar/';
  static String uploadFiles = '$apiUrl/config/filesystem/';
  static String payment = '$apiUrl/clientpayment/';
  static String feesPayment = '$apiUrl/feespayment/';
}

class Config {
  static String stripePubKey = "", stripeSeck = "";
  static checkProd() {
    if (kReleaseMode) {
      print('release');
      // stripePubKey =
      //     'pk_live_51Hw3mwD5d1ycJf8ZIiZZNTymC6mIV49JiXkT4tsgvfUYe5ndQYHuURy70C8d8xY75wJiU8rMpBHurTmLwZHWCEyw00SuckNlNa';
      // stripeSeck =
      //     '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';
    } else {
      print('debug');
      stripePubKey =
          'pk_test_51Hw3mwD5d1ycJf8Za9t6r7qAHRPw4WB8Wif4M7oGRtl6qd4vBuM1nvJD3slW8kJkX83bETBvkO3LjMkpOTMGwe5b00f4aGcBWX';
      stripeSeck =
          'sk_test_51Hw3mwD5d1ycJf8Zc7VksIf3ZT0lJODobfqgqdnUTHgTP9ZPqKJWDOuTqbGrxhzf7vfTkfmuAQsaieyNXGydIQIT004a2w1tlu';
    }
    return {'pubKey': stripePubKey, 'secKey': stripeSeck};
  }
}
