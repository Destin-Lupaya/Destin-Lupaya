import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

import '../../Resources/global_variables.dart';

class CustomButton extends StatefulWidget {
  CustomButton(
      {Key? key,
      required this.text,
      required this.backColor,
      required this.textColor,
      required this.callback,
      this.icon,
      this.onClicked})
      : super(key: key);

  final String text;
  final Color backColor;
  final Color textColor;
  Function? onClicked;
  Function callback;
  IconData? icon;

  @override
  _CustomButtonState createState() => _CustomButtonState();
}

class _CustomButtonState extends State<CustomButton> {
  bool isButtonHovered = false;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: 
      () { 
        widget.callback();
      },
      child: MouseRegion(
        onHover: (value) => setState(() {
          isButtonHovered = true;
        }),
        onEnter: (value) => setState(() {
          isButtonHovered = true;
        }),
        onExit: (value) => setState(() {
          isButtonHovered = false;
        }),
        child: Container(
            width: double.maxFinite,
            alignment: Alignment.center,
            margin: EdgeInsets.symmetric(
                horizontal: kDefaultPadding / 2, vertical: 5),
            padding: EdgeInsets.symmetric(
                horizontal: kDefaultPadding / 2, vertical: 10),
            decoration: BoxDecoration(
              color: isButtonHovered
                  ? widget.backColor.withOpacity(0.9)
                  : widget.backColor,
              borderRadius: BorderRadius.circular(kDefaultPadding / 2),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                widget.icon != null
                    ? Icon(widget.icon,
                        color: isButtonHovered
                            ? widget.textColor.withOpacity(0.5)
                            : widget.textColor)
                    : Container(),
                widget.icon != null ? const SizedBox(width: 10) : Container(),
                Text(
                  widget.text,
                  style: TextStyle(
                      color: isButtonHovered
                          ? widget.textColor.withOpacity(0.5)
                          : widget.textColor,
                      fontWeight: FontWeight.bold),
                ),
              ],
            )),
      ),
    );
  }
}
