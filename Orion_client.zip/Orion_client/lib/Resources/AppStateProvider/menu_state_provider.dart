import 'package:orion/Resources/Models/menu_model.dart';
import 'package:orion/Views/Guichet/gestionnaire_activite_orion.dart';
import 'package:orion/Views/Login/login_page.dart';
import 'package:flutter/material.dart';

class MenuStateProvider extends ChangeNotifier {
  String currentMenu = 'Accueil';
  List<MenuModel> menu = [
    MenuModel(title: 'Connect', icon: Icons.home, page: const LoginPage()),
    MenuModel(
        title: 'Accueil', icon: Icons.login, page: const AcceuilOrionPage()),
  ];

  initMenu({required BuildContext context}) {
    menu = [
      // MenuModel(title: 'Accueil', icon: Icons.home, page: const LoginPage()),
      MenuModel(title: 'Connect', icon: Icons.login, page: const LoginPage()),
    ];
    setDefault(pageData: {"name": 'Accueil', "page": const LoginPage()});
    // title: 'Accueil',
    // page: const LoanCalculationPage(),
    notifyListeners();
  }

  addMenu({required List<MenuModel> menus}) {
    for (var i = 0; i < menus.length; i++) {
      if (menu.where((element) {
        return element.title == menus[i].title;
      }).isNotEmpty) {
        return;
      }
      menu.add(menus[i]);
    }
    notifyListeners();
  }

  removeMenu({required MenuModel menus}) {
    if (menu.where((element) {
      return element.title == menus.title;
    }).isNotEmpty) {
      menu.removeWhere((element) => element.title == menus.title);
    }
    notifyListeners();
  }

  getActivePage() {
    activePage = menu
        .where((menu) {
          return menu.title.toLowerCase() == currentMenu.toLowerCase();
        })
        .toList()[0]
        .page;
    // notifyListeners();
  }

  Widget activePage = const LoginPage();
  // Widget activePage = const LoanCalculationPage();

  changeMenu({required String newMenuValue}) {
    currentMenu = newMenuValue;
    getActivePage();
    notifyListeners();
  }

  setDefault({required Map pageData}) {
    currentMenu = pageData['name'];
    activePage = pageData['page'];
    notifyListeners();
  }
}
