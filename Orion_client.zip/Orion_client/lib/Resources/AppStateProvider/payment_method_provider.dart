import 'dart:convert';

import 'package:orion/Resources/AppStateProvider/app_stateprovider.dart';
import 'package:orion/Resources/Models/payment_method.model.dart';
import 'package:orion/Resources/global_variables.dart';
import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';

class PaymentMethodProvider extends ChangeNotifier {
  PaymentMethodModel? selectedCard;
  List<PaymentMethodModel> paymentMethods = [];
  addPaymentMethod(
      {required BuildContext context,
      required PaymentMethodModel payment,
      required bool updatingData,
      required Function callback}) async {
    if (payment.number.isEmpty ||
        payment.name.isEmpty ||
        payment.cvv == null ||
        payment.type.isEmpty ||
        payment.expirationData == null) {
      return Message.showToast(msg: 'Veuillez remplir tous les champs');
    }
    if (paymentMethods
            .where((paymentList) {
              return paymentList.isDefault == 1;
            })
            .toList()
            .isNotEmpty &&
        payment.isDefault == 1) {
      return Message.showToast(
          msg: 'Il existe deja un mode de paiement par defaut');
    }
    if (paymentMethods
            .where((paymentList) {
              return paymentList.number == payment.number;
            })
            .toList()
            .isNotEmpty &&
        updatingData == false) {
      return Message.showToast(
          msg: 'Il existe deja une carte avec le meme numero');
    }
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    var response;
    if (updatingData == false) {
      response = await Provider.of<AppStateProvider>(context, listen: false)
          .httpPost(url: BaseUrl.wayOfPayments, body: payment.toJson());
    } else {
      response = await Provider.of<AppStateProvider>(context, listen: false)
          .httpPut(
              url: "${BaseUrl.wayOfPayments}${payment.id!.toString().trim()}",
              body: payment.toJson());
    }
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    if (response.body != "error") {
      if (response.body != null) {
        PaymentMethodModel paymentResponse =
            PaymentMethodModel.fromJson(jsonDecode(response.body));
        if (updatingData == true) {
          paymentMethods.where((employer) {
            return employer.id! == paymentResponse.id;
          }).toList()[0] = paymentResponse;
        } else {
          paymentMethods.add(paymentResponse);
        }
        Message.showToast(msg: 'Data saved');
        // paymentMethods.add(payment);
        callback();
        notifyListeners();
      } else {
        Message.showToast(msg: 'Error occured');
      }
    } else {
      Message.showToast(msg: 'Error occured on the server');
    }
    notifyListeners();
  }

  deleteCard({required String cardNumber}) {
    paymentMethods.removeWhere((card) => card.number == cardNumber);
    notifyListeners();
  }

  getCards({required BuildContext context, required bool isRefreshed}) async {
    if (paymentMethods.isNotEmpty && isRefreshed == false) return;
    paymentMethods.clear();
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    var response =
        await Provider.of<AppStateProvider>(context, listen: false).httpGet(
      url: "${BaseUrl.wayOfPayments}",
    );
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    if (response.body != "error" && response.body != "null") {
      var decoded = jsonDecode(response.body);
      for (var row in decoded) {
        // print(row);
        // continue;
        paymentMethods.add(PaymentMethodModel.fromJson(row));
      }
    }
  }

  // load(Map data, var reqBody, String route, BuildContext context) async {
  //   try {
  //     Provider.of<AppStateProvider>(context, listen: false).changeAppState();
  //     notifyListeners();
  //     var cardObject = await Tokenize().card(
  //         cvc: data['cvv'].toString(),
  //         expiryMonth: int.parse(data['expiryDate'].toString().substring(0, 2)),
  //         expiryYear: int.parse(data['expiryDate'].toString().substring(3)),
  //         number: data['cardNumber'].toString(),
  //         name: data['fullname'].toString(),
  //         phone: '234840172420');
  //
  //     return print(cardObject.data.id);
  //
  //     if (cardObject.data.id != null) {
  //       var validPayment = await Charge().card(
  //           source: cardObject.data.id,
  //           amount: int.parse(
  //               (double.parse(data['amount'].toString()).round() * 100)
  //                   .toString()),
  //           description: 'Charged from ${data['fullname'].toString()}',
  //           receiptEmail: 'info@smart-tick.com');
  //       var res = validPayment.data;
  //       // print(res.);
  //       if (res.status == 'succeeded') {
  //         Message.showToast(msg: "Paid");
  //       } else {
  //         Message.showToast(
  //             msg:
  //                 "Une erreur est survenue lors du paiement, réessayez plus tard");
  //       }
  //       print("Status==================================" + res.status);
  //     } else {
  //       Message.showToast(msg: 'Carte invalide');
  //     }
  //   } catch (e) {
  //     print("Error: " + e.toString());
  //   }
  //   notifyListeners();
  // }

  PaymentMethodModel? refundPaymentMethod;
  setRefundMethod(
      {required BuildContext context,
      required PaymentMethodModel newPaymentMethod}) {
    refundPaymentMethod = newPaymentMethod;
    notifyListeners();
  }
}
