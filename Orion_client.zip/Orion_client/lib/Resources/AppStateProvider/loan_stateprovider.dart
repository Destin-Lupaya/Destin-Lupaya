import 'dart:convert';

import 'package:orion/Resources/AppStateProvider/app_stateprovider.dart';
import 'package:orion/Resources/AppStateProvider/menu_state_provider.dart';
import 'package:orion/Resources/AppStateProvider/user_stateprovider.dart';
import 'package:orion/Resources/Components/dialogs.dart';
import 'package:orion/Resources/Models/loan_model.dart';
import 'package:orion/Resources/Models/payback_calendar.model.dart';
import 'package:orion/Resources/Models/saved_loan.model.dart';
import 'package:orion/Resources/global_variables.dart';
import 'package:orion/Views/Reporting/Dashboard/home_dash_page.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class LoanStateProvider extends ChangeNotifier {
  List<Map> scores = [
    {"designation": "Faible", "minTaux": "12", "maxTaux": "18"},
    {"designation": "Assez bien", "minTaux": "9", "maxTaux": "15"},
    {"designation": "Bien", "minTaux": "7", "maxTaux": "12"},
    {"designation": "Tres bien", "minTaux": "5", "maxTaux": "9"},
    {"designation": "Excellent", "minTaux": "3", "maxTaux": "6"},
  ];
  List<Map> creditTypes = [];

  double amountValue = 300;
  double minTauxValue = 0;
  double maxTauxValue = 0;
  double durationValue = 12;
  double scoreValue = 5;

  List<LoanModel> credits = [];

  setLoanType({required BuildContext context}) {
    credits.clear();
    for (var i = 0; i < creditTypes.length; i++) {
      credits.add(LoanModel.fromJSON(creditTypes[i]));
    }
    notifyListeners();
    currentLoan = credits[0].id!.toString();
    choosedLoanType = credits
        .where((credit) {
          return credit.id!.toString() == currentLoan.toString();
        })
        .toList()[0]
        .toJson();
    amountValue = double.parse(choosedLoanType['minamount'].toString());
    calculateTotalPayback();
    getLoansTypeFees(context: context);
  }

  Map choosedLoanType = {};
  String currentLoan = "";
  String refundMode = "Automatique";

  initLoans({required BuildContext context}) {
    getLoansType(context: context);
  }

  List<PaybackModel> paybackCalendar = [];

  buildCalendar() {
    paybackCalendar.clear();
    for (var i = 0; i < durationValue; i++) {
      paybackCalendar.add(PaybackModel.fromJSON({
        "id": "${i + 1}",
        "loans_id": "0",
        "refundDate": DateTime.now()
            .add(Duration(days: 30 * (i + 1)))
            .toString()
            .substring(0, 10),
        "amount": (amountValue / durationValue).toString(),
        "interestRate": ((amountValue / durationValue) *
                (double.parse(choosedLoanType['insterestRate'].toString()) /
                    100))
            .toString(),
        "overDueFees": ((amountValue / durationValue) *
                (double.parse(choosedLoanType['overDueFees']) / 100))
            .toString(),
      }));
    }
  }

  double totalInteret = 0.0, totalCapital = 0.0;

  calculateTotalPayback() {
    buildCalendar();
    totalInteret = 0.0;
    totalCapital = 0.0;
    for (var i = 0; i < paybackCalendar.length; i++) {
      totalInteret += paybackCalendar[i].interestRate;
      totalCapital += paybackCalendar[i].amount;
    }
    notifyListeners();
  }

  List<SavedLoanModel> myLoans = [];
  List myLoan = [];

  getLoansType({required BuildContext context}) async {
    if (creditTypes.isNotEmpty) return;
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    var response =
        await Provider.of<AppStateProvider>(context, listen: false).httpGet(
      url: BaseUrl.loanType,
    );
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    if (response.body != "error" && response.body != "null") {
      // print(response.body);
      var decoded = jsonDecode(response.body);
      // print(response.body);
      // return;
      for (var row in decoded) {
        // print(row);
        row.addAll({"overDueFees": "4"});
        creditTypes.add(row);
      }
      setLoanType(context: context);
    } else {
      Message.showToast(msg: 'Impossible de récupérer les types des crédits');
    }
  }

  getLoansTypeFees({required BuildContext context}) async {
    if (credits
            .where(
                (credit) => credit.id!.toString().trim() == currentLoan.trim())
            .toList()[0]
            .fees !=
        null) return;
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    var response =
        await Provider.of<AppStateProvider>(context, listen: false).httpGet(
      url: "${BaseUrl.loanType}$currentLoan",
    );
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    if (response.body != "error" && response.body != "null") {
      Map decoded = jsonDecode(response.body);
      // print(response.body);
      // // return;
      credits
          .where((credit) => credit.id!.toString().trim() == currentLoan.trim())
          .toList()[0]
          .fees = decoded['fees'];
      choosedLoanType = credits
          .where((credit) {
            return credit.id!.toString() == currentLoan.toString();
          })
          .toList()[0]
          .toJson();
      // print(credits
      //     .where((credit) => credit.id!.toString().trim() == currentLoan.trim())
      //     .toList()[0]
      //     .fees);
      notifyListeners();
    } else {
      Message.showToast(msg: 'Impossible de récupérer les frais');
    }
  }

  saveLoans(
      {required BuildContext context, required SavedLoanModel loan}) async {
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    var response = await Provider.of<AppStateProvider>(context, listen: false)
        .httpPost(url: BaseUrl.loan, body: {
      "users_id": Provider.of<UserStateProvider>(context, listen: false)
          .userId
          .toString(),
      "loan_types_id": loan.loan_types_id.toString(),
      "amount": loan.amount.toString(),
      "duration": loan.duration.toString(),
      "refundMode": loan.refundMode.toString(),
      "status": 'Initiated',
    });
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    if (response.body != "error") {
      var decoded = jsonDecode(response.body);
      myLoans.insert(0, SavedLoanModel.fromJSON(decoded));
      // myLoans.add(SavedLoanModel.fromJSON(decoded));
      List refundCalendar = [];
      for (int i = 0; i < loan.payback!.length; i++) {
        Map singleCalendar = loan.payback![i].toJson();
        singleCalendar['loans_id'] = decoded['id'].toString();
        singleCalendar.remove("id");
        refundCalendar.add(singleCalendar);
        // loan.payback![i].loans_id = savedData.id!;
      }
      Provider.of<AppStateProvider>(context, listen: false).changeAppState();
      var resCalendar =
          await Provider.of<AppStateProvider>(context, listen: false).httpPost(
              url: BaseUrl.refundCalendar,
              body: {"data": jsonEncode(refundCalendar)});
      Provider.of<AppStateProvider>(context, listen: false).changeAppState();
      print(resCalendar.body);
      if (resCalendar.body != "error" && response.body != "null") {
        // Message.showToast(msg: 'Demande de crédit initiée');
        Dialogs.showDialogNoAction(
            heightFactor: 2,
            context: context,
            title: 'Success',
            content: 'Demande de crédit enregistrée');
        Provider.of<MenuStateProvider>(context, listen: false).setDefault(
            pageData: {"name": "Dashboard", "page": ClientHomePage()});
      } else {
        Message.showToast(
            msg: 'Impossible d\'enregistrer le calendrier de remboursement');
      }
    } else {
      Message.showToast(
          msg: 'Une erreur est survenue lors de la demande de crédit');
    }
  }

  getMyLoans({required BuildContext context}) async {
    if (myLoans.isNotEmpty) return;
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    var response =
        await Provider.of<AppStateProvider>(context, listen: false).httpGet(
      url: BaseUrl.loan,
    );
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    if (response.body != "error" && response.body != "null") {
      var decoded = jsonDecode(response.body);
      // print(response.body);
      for (var row in decoded) {
        myLoans.add(SavedLoanModel.fromJSON(row));
      }
      myLoans.sort((prev, next) => next.id!.compareTo(prev.id!));
      notifyListeners();
    } else {
      Message.showToast(msg: 'Impossible de récupérer les données des crédits');
    }
  }

  getRefundCalendar(
      {required BuildContext context,
      required String loanID,
      required Function callback}) async {
    if (myLoans
        .where((loan) {
          return loan.id!.toString().trim() == loanID.trim();
        })
        .toList()[0]
        .payback!
        .isNotEmpty) {
      return;
    }

    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    var response =
        await Provider.of<AppStateProvider>(context, listen: false).httpGet(
      url: "${BaseUrl.loan}$loanID",
    );
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    if (response.body != "error") {
      List<PaybackModel> refundCalendar = [];
      Map decoded = jsonDecode(response.body);
      for (var row in decoded['calendar']) {
        refundCalendar.add(PaybackModel(
            id: int.parse(row['id'].toString()),
            loans_id: int.parse(row['loans_id'].toString()),
            amount: double.parse(row['amount'].toString()),
            refundDate: row['refundDate'].toString(),
            interestRate: double.parse(row['interestRate'].toString()),
            overDueFees: double.parse(row['overDueFees'].toString()),
            payment: refundPayment
                .where((payment) =>
                    payment['refund_calendars_id'].toString().trim() ==
                    row['id'].toString().trim())
                .toList()));
        // setPayment(refundData: PaybackModel.fromJSON(row));
      }
      myLoans
          .where((loan) {
            return loan.id.toString().trim() ==
                decoded['loan']['id'].toString().trim();
          })
          .toList()[0]
          .payback = refundCalendar;

      notifyListeners();
      callback();
      getTotalRefund();
    } else {
      Message.showToast(msg: 'Impossible de récupérer les données des crédits');
    }
  }

  makePayment(
      {required BuildContext context,
      required PaybackModel refundData,
      required Map payment,
      required Function callback}) async {
    payment['amount'] = payment['amount'].toString();
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    var response = await Provider.of<AppStateProvider>(context, listen: false)
        .httpPost(url: BaseUrl.payment, body: payment);
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    if (response.body != "error" && response.body != "null") {
      Message.showToast(msg: 'Paeiment effectué');
      SavedLoanModel targetLoan = myLoans
          .where(
              (loan) => loan.id!.toString() == refundData.loans_id!.toString())
          .toList()[0];
      PaybackModel targetRefund = targetLoan.payback!
          .where((refund) =>
              refund.id!.toString().trim() == refundData.id!.toString().trim())
          .toList()[0];
      targetRefund.payment!.add(jsonDecode(response.body));
      targetLoan.payback!
          .where((refund) =>
              refund.id!.toString().trim() == refundData.id!.toString().trim())
          .toList()[0] = targetRefund;
      myLoans
          .where(
              (loan) => loan.id!.toString() == refundData.loans_id!.toString())
          .toList()[0] = targetLoan;
      callback();
      getTotalRefund();
      notifyListeners();
    } else {
      Message.showToast(msg: 'Impossible d\'enregistrer le paiement');
    }
  }

  List refundPayment = [];
  getPayment({required BuildContext context}) async {
    if (refundPayment.isNotEmpty) return;
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    var response = await Provider.of<AppStateProvider>(context, listen: false)
        .httpGet(url: BaseUrl.payment);
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    if (response.body != "error" && response.body != "null") {
      refundPayment = jsonDecode(response.body);
      Message.showToast(msg: 'Paiements récupérés');
    } else {
      Message.showToast(msg: 'Impossible de récupérer les paiements');
    }
  }

  setPayment({required PaybackModel refundData}) {
    SavedLoanModel targetLoan = myLoans
        .where((loan) => loan.id!.toString() == refundData.loans_id!.toString())
        .toList()[0];
    PaybackModel targetRefund = targetLoan.payback!
        .where((refund) =>
            refund.id!.toString().trim() == refundData.id!.toString().trim())
        .toList()[0];
    List targetRefundPayment = refundPayment
        .where((payment) =>
            payment['refund_calendars_id'].toString().trim() ==
            refundData.id!.toString().trim())
        .toList();
    targetRefund.payment != (targetRefundPayment);
    targetLoan.payback!
        .where((refund) =>
            refund.id!.toString().trim() == refundData.id!.toString().trim())
        .toList()[0] = targetRefund;
    myLoans
        .where((loan) => loan.id!.toString() == refundData.loans_id!.toString())
        .toList()[0] = targetLoan;
    notifyListeners();
  }

  double totalRefund = 0;
  getTotalRefund() {
    totalRefund = 0;
    for (int i = 0; i < myLoans.length; i++) {
      for (int j = 0; j < myLoans[i].payback!.length; j++) {
        for (int k = 0; k < myLoans[i].payback![j].payment!.length; k++) {
          totalRefund += double.parse(
              myLoans[i].payback![j].payment![k]['amount'].toString());
        }
      }
    }
    print(totalRefund.toString());
    notifyListeners();
  }

  Map loanTypeFromLoan = {};
  getLoansFees(
      {required BuildContext context, required SavedLoanModel loan}) async {
    if (credits
            .where((credit) =>
                credit.id!.toString().trim() ==
                loan.loan_types_id.toString().trim())
            .toList()[0]
            .fees !=
        null) return;
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    var response =
        await Provider.of<AppStateProvider>(context, listen: false).httpGet(
      url: "${BaseUrl.loanType}${loan.loan_types_id.toString()}",
    );
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    if (response.body != "error" && response.body != "null") {
      Map decoded = jsonDecode(response.body);
      // print(response.body);
      // return;
      credits
          .where((credit) =>
              credit.id!.toString().trim() ==
              loan.loan_types_id.toString().trim())
          .toList()[0]
          .fees = decoded['fees'];
      loanTypeFromLoan = credits
          .where((credit) {
            return credit.id!.toString().trim() ==
                loan.loan_types_id.toString().trim();
          })
          .toList()[0]
          .toJson();
      // print(loanTypeFromLoan);
      notifyListeners();
    } else {
      Message.showToast(msg: 'Impossible de récupérer les frais');
    }
  }

  makeFeesPayment(
      {required BuildContext context,
      required SavedLoanModel loanData,
      required Map payment,
      required Function callback}) async {
    payment['amount'] = payment['amount'].toString();
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    var response = await Provider.of<AppStateProvider>(context, listen: false)
        .httpPost(url: BaseUrl.feesPayment, body: payment);
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    if (response.body != "error" && response.body != "null") {
      Message.showToast(msg: 'Paeiment effectué');
      SavedLoanModel targetLoan = myLoans
          .where((loan) => loan.id!.toString() == loanData.id!.toString())
          .toList()[0];
      targetLoan.feesPayment!.add(jsonDecode(response.body));
      myLoans
          .where((loan) => loan.id!.toString() == loanData.id!.toString())
          .toList()[0] = targetLoan;
      callback();
      notifyListeners();
    } else {
      Message.showToast(msg: 'Impossible d\'enregistrer le paiement');
    }
  }
}
