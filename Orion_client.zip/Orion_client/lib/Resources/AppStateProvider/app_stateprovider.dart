import 'package:orion/Resources/AppStateProvider/menu_state_provider.dart';
import 'package:orion/Resources/Models/menu_model.dart';
import 'package:orion/Resources/global_variables.dart';
import 'package:orion/Views/Config/Settings/settings_form.dart';
import 'package:orion/Views/Guichet/gestionnaire_activite_orion.dart';
import 'package:orion/Views/Admin_Orion/Views/Home/home_page.dart';
import 'package:orion/Views/Login/login_page.dart';
import 'package:orion/Views/Home/home_page_new.dart';
import 'package:orion/main.dart';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:http/http.dart' as http;
import 'package:http/http.dart';
import 'package:provider/provider.dart';

class AppStateProvider extends ChangeNotifier {
  bool isAsync = false;
  bool isConnected = false;
  changeAppState() {
    isAsync = !isAsync;
    // print('changing state');
    notifyListeners();
  }

  initUI({required BuildContext context}) {
    if (prefs.getString('userData') != null) {
      WidgetsBinding.instance!.addPostFrameCallback((timeStamp) {
        changeConnexionState(context: context);
        Provider.of<MenuStateProvider>(context, listen: false)
            .setDefault(pageData: {"name": "Bienvenue", "page": HomePage2()});
      });
    }
  }

  changeConnexionState({required BuildContext context}) {
    Provider.of<MenuStateProvider>(context, listen: false).addMenu(menus: [
      // MenuModel(
      //     title: 'Acceuil', icon: Icons.dashboard, page: AcceuilOrionPage()),

      MenuModel(
          title: 'Activites', page: AcceuilOrionPage(), icon: Icons.person),

      MenuModel(title: 'Parametres', page: HomePage(), icon: Icons.settings),
      MenuModel(
          title: 'Profil', page: const SettingPage(), icon: Icons.settings),
      // MenuModel(
      //     title: 'Mes credits',
      //     page: const ProfilePage(),
      //     icon: Icons.credit_card)
    ]);
    Provider.of<MenuStateProvider>(context, listen: false).removeMenu(
        menus: MenuModel(
            title: 'Connect', page: const LoginPage(), icon: Icons.login));
    Provider.of<MenuStateProvider>(context, listen: false).removeMenu(
        menus: MenuModel(
            title: 'Accueil', page: const HomePage2(), icon: Icons.login));
    isConnected = !isConnected;
    notifyListeners();
  }

  Set<String> phonenumbers = Set();
  setPhonenumber() {
    for (int i = 0; i < membreInscrit.length; i++) {
      phonenumbers.add(membreInscrit[i]['phone number'].toString());
    }
    notifyListeners();
  }

  List membreInscrit = [];
  fetchMembreInscrit({required BuildContext context}) async {
    if (membreInscrit.isNotEmpty) return;
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    var response = await Provider.of<AppStateProvider>(context, listen: false)
        .httpGet(url: BaseUrl.addUser);
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    if (response.body != "error") {
      var decoded = jsonDecode(response.body);
      membreInscrit = decoded;
      Message.showToast(msg: 'Chargement numero des membres terminés');
      notifyListeners();
      setPhonenumber();
    } else {
      print(response.statusCode);
      Message.showToast(msg: 'Error occured, try again later');
    }
  }

  Future<Response> httpPost({required String url, required Map body}) async {
    try {
      Response response = await http.post(Uri.parse(url), body: body, headers: {
        "Accept": "application/json",
      });
      print(response.body);
      if (response.statusCode >= 200 && response.statusCode < 300) {
        return response;
      } else if (response.statusCode == 401) {
        return Response(response.body, response.statusCode);
      } else {
        return Response("error", 400);
      }
    } catch (error) {
      return Response("error", 400);
    }
  }

  Future<Response> httpPut({required String url, required Map body}) async {
    try {
      Response response = await http.put(Uri.parse(url), body: body, headers: {
        "Accept": "application/json",
      });
      print(response.body);
      if (response.statusCode >= 200 && response.statusCode < 300) {
        return response;
      } else if (response.statusCode == 401) {
        return Response(response.body, response.statusCode);
      } else {
        return Response("error", 400);
      }
    } catch (error) {
      return Response("error", 400);
    }
  }

  Future<Response> httpDelete({required String url, required Map body}) async {
    try {
      Response response = await http.delete(Uri.parse(url), headers: {
        "Accept": "application/json",
      });
      // print(response.body);
      if (response.statusCode >= 200 && response.statusCode < 300) {
        return response;
      } else if (response.statusCode == 401) {
        return Response(response.body, response.statusCode);
      } else {
        return Response("error", 400);
      }
    } catch (error) {
      return Response("error", 400);
    }
  }

  Future<Response> httpGet({required String url}) async {
    try {
      final response = await http.get(
        Uri.parse(url),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
      );
      if (response.statusCode >= 200 && response.statusCode < 300) {
        return response;
      } else {
        return Response("error", 400);
      }
    } catch (error) {
      return Response("error", 400);
    }
  }

  logOut({required BuildContext context}) {
    Provider.of<MenuStateProvider>(context, listen: false)
        .setDefault(pageData: {"name": "Accueil", "page": const HomePage2()});
    // .setDefault(
    //     pageData: {"name": "Accueil", "page": const LoanCalculationPage()});
    Navigation.pushReplaceNavigate(context: context, page: const LoginPage());
  }
}
