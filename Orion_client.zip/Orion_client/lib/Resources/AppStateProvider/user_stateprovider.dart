import 'dart:convert';
import 'package:orion/Resources/Models/Guichet_Model/activite_model.dart';
import 'package:orion/Resources/Models/Guichet_Model/demandeur_model.dart';
import 'package:orion/Resources/Models/Guichet_Model/envoyer_argent_model.dart';
import 'package:orion/Resources/Models/Guichet_Model/emprunt_model.dart';
import 'package:orion/Resources/Models/Guichet_Model/approvisionement_model.dart';
import 'package:orion/Resources/Models/Guichet_Model/fournisseurs_model.dart';
import 'package:orion/Resources/Models/Guichet_Model/historique_model.dart';
import 'package:orion/Resources/Models/Guichet_Model/pret_model.dart';
import 'package:orion/Resources/AppStateProvider/app_stateprovider.dart';
import 'package:orion/Resources/AppStateProvider/menu_state_provider.dart';
import 'package:orion/Resources/Models/client_bank.model.dart';
import 'package:orion/Resources/Models/client_model.dart';
import 'package:orion/Resources/Models/credit_history.model.dart';
import 'package:orion/Resources/Models/employer_model.dart';
import 'package:orion/Resources/Models/payable_person.model.dart';
import 'package:orion/Resources/Models/statement_position.model.dart';
import 'package:orion/Resources/global_variables.dart';
import 'package:orion/Views/Config/User/Profile/profile.dart';
import 'package:orion/Views/Reporting/Dashboard/home_dash_page.dart';
import 'package:orion/main.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class UserStateProvider extends ChangeNotifier {
  double cashCDF = 250000;
  double cashUSD = 7500;
  double stockVirtuelCDF = 580000;
  double stockVirtuelUSD = 1890;
  int userId = 1;
  double singleStepValue = 10;
//==========================================Envoi Virtuel CDF==========================================
  envoiVirtuel(
      {required double montant,
      required String devise,
      required Function callback,
      required BuildContext context}) async {
    if (devise == 'CDF') {
      if (montant > stockVirtuelCDF) {
        // Message.showToast(
        //     msg:
        //         'vous n\'avez pas suffisament de fond dans votre compte pour effectuer cet action');
        showDialog(
            context: context,
            builder: (BuildContext context) => new AlertDialog(
                  title: new Text('Solde Insuffisant'),
                  content: new Text(
                      'Veillez approvisionner votre compte pour effectue la transaction'),
                  actions: <Widget>[
                    new IconButton(
                        icon: new Icon(Icons.close),
                        onPressed: () {
                          Navigator.pop(context);
                        })
                  ],
                ));

        // if (montant == null || devise.isEmpty) {
        //   Message.showToast(msg: 'Veuillez remplir tous les champs');
        // }
        return;
      }
      stockVirtuelCDF -= montant;
      cashCDF += montant;
      notifyListeners();
      // Message.showToast(
      //     msg: 'Votre transaction a été effectuée avec succès...');

      return await showDialog(
          context: context,
          builder: (BuildContext context) => new AlertDialog(
                title: new Text('Felicitation'),
                content: new Text(
                    'Votre transaction a été effectuée avec succès...'),
                actions: <Widget>[
                  new IconButton(
                      icon: new Icon(Icons.close),
                      onPressed: () {
                        Navigator.pop(context);
                      })
                ],
              ));
    }

    //==========================================Envoi Virtuel USD==========================================

    {
      if (devise == 'USD') {
        if (montant > stockVirtuelUSD) {
          // Message.showToast(
          //     msg:
          //         'vous n\'avez pas suffisament de fond dans votre compte pour effectuer cet action ');
          // if (montant == null || devise.isEmpty) {
          //   Message.showToast(msg: 'Veuillez remplir tous les champs');
          // }
          showDialog(
              context: context,
              builder: (BuildContext context) => new AlertDialog(
                    title: new Text('Solde Insuffisant'),
                    content: new Text(
                        'Veillez approvisionner votre compte pour effectue la transaction'),
                    actions: <Widget>[
                      new IconButton(
                          icon: new Icon(Icons.close),
                          onPressed: () {
                            Navigator.pop(context);
                          })
                    ],
                  ));
          return;
        }
        stockVirtuelUSD -= montant;
        cashUSD += montant;
        callback();
        notifyListeners();
      }
      //Message.showToast(msg: 'Votre transaction a été effectuée avec succès...');

      return await showDialog(
          context: context,
          builder: (BuildContext context) => new AlertDialog(
                title: new Text('Felicitation'),
                content: new Text(
                    'Votre transaction a été effectuée avec succès...'),
                actions: <Widget>[
                  new IconButton(
                      icon: new Icon(Icons.close),
                      onPressed: () {
                        Navigator.pop(context);
                      })
                ],
              ));
    }
  }

//==========================================Envoi Cash CDF==========================================
  envoICash(
      {required double montant,
      required String devise,
      required Function callback,
      required BuildContext context}) async {
    if (devise.trim() == 'CDF') {
      if (montant > cashCDF) {
        showDialog(
            context: context,
            builder: (BuildContext context) => new AlertDialog(
                  title: new Text('Solde Insuffisant'),
                  content: new Text(
                      'Veillez approvisionner votre compte pour effectue la transaction'),
                  actions: <Widget>[
                    new IconButton(
                        icon: new Icon(Icons.close),
                        onPressed: () {
                          Navigator.pop(context);
                        })
                  ],
                ));
        // Message.showToast(
        //     msg:
        //         'vous n\'avez pas suffisament de fond dans votre compte pour effectuer cet action');
        // if (montant == null || devise.isEmpty) {
        //   Message.showToast(msg: 'Veuillez remplir tous les champs');
        // }
        return;
      }
      cashCDF -= montant;
      stockVirtuelCDF += montant;
      notifyListeners();
      // Message.showToast(
      //     msg: ' Votre transaction a été effectuée avec succès...');
      return await showDialog(
          context: context,
          builder: (BuildContext context) => new AlertDialog(
                title: new Text('Felicitation'),
                content: new Text(
                    'Votre transaction a été effectuée avec succès...'),
                actions: <Widget>[
                  new IconButton(
                      icon: new Icon(Icons.close),
                      onPressed: () {
                        Navigator.pop(context);
                      })
                ],
              ));
    }
//==========================================Envoi Cash USD==========================================

    if (devise.trim() == 'USD') {
      if (montant > cashUSD) {
        // Message.showToast(
        //     msg:
        //         'vous n\'avez pas suffisament de fond dans votre compte pour effectuer cet action');
        showDialog(
            context: context,
            builder: (BuildContext context) => new AlertDialog(
                  title: new Text('Solde Insuffisant'),
                  content: new Text(
                      'Veillez approvisionner votre compte pour effectue la transaction'),
                  actions: <Widget>[
                    new IconButton(
                        icon: new Icon(Icons.close),
                        onPressed: () {
                          Navigator.pop(context);
                        })
                  ],
                ));

        return;
      }
      cashUSD -= montant;
      stockVirtuelUSD += montant;
      notifyListeners();
      callback();
    }
    //Message.showToast(msg: 'Votre transaction a été effectuée avec succès...');

    return await showDialog(
        context: context,
        builder: (BuildContext context) => new AlertDialog(
              title: new Text('Felicitation'),
              content:
                  new Text('Votre transaction a été effectuée avec succès...'),
              actions: <Widget>[
                new IconButton(
                    icon: new Icon(Icons.close),
                    onPressed: () {
                      Navigator.pop(context);
                    })
              ],
            ));
  }

//==========================================Approvisionnement Virtuel CDF==========================================

  approvVirtuel(
      {required double montant,
      required String devise,
      required Function callback,
      required BuildContext context}) async {
    //    for (var montant = 0; montant < stockVirtuelCDF.devise; montant++) {
    // total += stockVirtuelCDF [montant].montant;

    if (devise == 'CDF') {
      stockVirtuelCDF += montant;
      notifyListeners();
      // Message.showToast(
      //     msg: 'Votre transaction a été effectuée avec succès...');

      return await showDialog(
          context: context,
          builder: (BuildContext context) => new AlertDialog(
                title: new Text('Felicitation'),
                content: new Text(
                    'Votre demande approvisionnement a été effectuée avec succès...'),
                actions: <Widget>[
                  new IconButton(
                      icon: new Icon(Icons.close),
                      onPressed: () {
                        Navigator.pop(context);
                      })
                ],
              ));
    }

    //==========================================Appovisionnement Virtuel USD==========================================

    if (devise == 'USD') {
      stockVirtuelUSD += montant;
      callback();
      notifyListeners();
    }
    //Message.showToast(msg: 'Votre transaction a été effectuée avec succès...');

    return await showDialog(
        context: context,
        builder: (BuildContext context) => new AlertDialog(
              title: new Text('Felicitation'),
              content: new Text(
                  'Votre demande approvisionnement a été effectuée avec succès...'),
              actions: <Widget>[
                new IconButton(
                    icon: new Icon(Icons.close),
                    onPressed: () {
                      Navigator.pop(context);
                    })
              ],
            ));
  }

  //==========================================Appovisionnement Cash CDF==========================================
  approvCash(
      {required double montant,
      required String devise,
      required Function callback,
      required BuildContext context}) async {
    //    for (var montant = 0; montant < stockVirtuelCDF.devise; montant++) {
    // total += stockVirtuelCDF [montant].montant;

    if (devise == 'CDF') {
      stockVirtuelCDF += montant;
      notifyListeners();
      // Message.showToast(
      //     msg: 'Votre transaction a été effectuée avec succès...');

      return await showDialog(
          context: context,
          builder: (BuildContext context) => new AlertDialog(
                title: new Text('Felicitation'),
                content: new Text(
                    'Votre demande approvisionnement a été effectuée avec succès...'),
                actions: <Widget>[
                  new IconButton(
                      icon: new Icon(Icons.close),
                      onPressed: () {
                        Navigator.pop(context);
                      })
                ],
              ));
    }

    //==========================================Appovisionnement Cash USD==========================================

    if (devise == 'USD') {
      cashUSD += montant;
      notifyListeners();
    }
    //Message.showToast(msg: 'Votre transaction a été effectuée avec succès...');
    callback();
    return await showDialog(
        context: context,
        builder: (BuildContext context) => new AlertDialog(
              title: new Text('Felicitation'),
              content: new Text(
                  'Votre demande approvisionnement a été effectuée avec succès...'),
              actions: <Widget>[
                new IconButton(
                    icon: new Icon(Icons.close),
                    onPressed: () {
                      Navigator.pop(context);
                    })
              ],
            ));
  }

  //==========================================Envoi Virtuel CDF avec 2 CheckBox==========================================
  envoiVirtuelcheck(
      {required double montant,
      required String devise,
      required String typedevise,
      required Function callback,
      required BuildContext context}) async {
    {
      if (devise == 'CDF') if (typedevise == 'Virtuel') {
        if (montant > stockVirtuelCDF) {
          // Message.showToast(
          //     msg:
          //         'vous n\'avez pas suffisament de fond dans votre compte pour effectuer cet action');
          showDialog(
              context: context,
              builder: (BuildContext context) => new AlertDialog(
                    title: new Text('Solde Insuffisant'),
                    content: new Text(
                        'Veillez approvisionner votre compte pour effectue la transaction'),
                    actions: <Widget>[
                      new IconButton(
                          icon: new Icon(Icons.close),
                          onPressed: () {
                            Navigator.pop(context);
                          })
                    ],
                  ));

          // if (montant == null || devise.isEmpty) {
          //   Message.showToast(msg: 'Veuillez remplir tous les champs');
          // }
          return;
        }
        stockVirtuelCDF -= montant;
        cashCDF += montant;
        notifyListeners();
        callback();

        // Message.showToast(
        //     msg: 'Votre transaction a été effectuée avec succès...');

        return await showDialog(
            context: context,
            builder: (BuildContext context) => new AlertDialog(
                  title: new Text('Felicitation'),
                  content: new Text(
                      'Votre transaction a été effectuée avec succès...'),
                  actions: <Widget>[
                    new IconButton(
                        icon: new Icon(Icons.close),
                        onPressed: () {
                          Navigator.pop(context);
                        })
                  ],
                ));
      }
    }
    //==========================================Envoi Virtuel USD avec 2 checkBox==========================================

    if (devise == 'USD') {
      if (typedevise == 'Virtuel') {
        if (montant > stockVirtuelUSD) {
          // Message.showToast(
          //     msg:
          //         'vous n\'avez pas suffisament de fond dans votre compte pour effectuer cet action ');
          // if (montant == null || devise.isEmpty) {
          //   Message.showToast(msg: 'Veuillez remplir tous les champs');
          // }
          showDialog(
              context: context,
              builder: (BuildContext context) => new AlertDialog(
                    title: new Text('Solde Insuffisant'),
                    content: new Text(
                        'Veillez approvisionner votre compte pour effectue la transaction'),
                    actions: <Widget>[
                      new IconButton(
                          icon: new Icon(Icons.close),
                          onPressed: () {
                            Navigator.pop(context);
                          })
                    ],
                  ));
          return;
        }
        stockVirtuelUSD -= montant;
        cashUSD += montant;
        notifyListeners();
      }

      //Message.showToast(msg: 'Votre transaction a été effectuée avec succès...');
      callback();
      return await showDialog(
          context: context,
          builder: (BuildContext context) => new AlertDialog(
                title: new Text('Felicitation'),
                content: new Text(
                    'Votre transaction a été effectuée avec succès...'),
                actions: <Widget>[
                  new IconButton(
                      icon: new Icon(Icons.close),
                      onPressed: () {
                        Navigator.pop(context);
                      })
                ],
              ));
    }
  }

//==========================================Envoi Cash CDF avec 2 checkbox==========================================
  envoICashCheck(
      {required double montant,
      required String devise,
      required String typedevise,
      required Function callback,
      required BuildContext context}) async {
    {
      if (devise.trim() == 'CDF') {
        if (typedevise.trim() == 'Cash') {
          if (montant > cashCDF) {
            showDialog(
                context: context,
                builder: (BuildContext context) => new AlertDialog(
                      title: new Text('Solde Insuffisant'),
                      content: new Text(
                          'Veillez approvisionner votre compte pour effectue la transaction'),
                      actions: <Widget>[
                        new IconButton(
                            icon: new Icon(Icons.close),
                            onPressed: () {
                              Navigator.pop(context);
                            })
                      ],
                    ));
            // Message.showToast(
            //     msg:
            //         'vous n\'avez pas suffisament de fond dans votre compte pour effectuer cet action');
            // if (montant == null || devise.isEmpty) {
            //   Message.showToast(msg: 'Veuillez remplir tous les champs');
            // }
            return;
          }
          cashCDF -= montant;
          stockVirtuelCDF += montant;
          notifyListeners();
          // Message.showToast(
          //     msg: ' Votre transaction a été effectuée avec succès...');
          return await showDialog(
              context: context,
              builder: (BuildContext context) => new AlertDialog(
                    title: new Text('Felicitation'),
                    content: new Text(
                        'Votre transaction a été effectuée avec succès...'),
                    actions: <Widget>[
                      new IconButton(
                          icon: new Icon(Icons.close),
                          onPressed: () {
                            Navigator.pop(context);
                          })
                    ],
                  ));
        }
      }
    }
//==========================================Envoi Cash USD avec 2 check box  ==========================================

    {
      if (devise.trim() == 'USD') {
        if (typedevise.trim() == 'Cash') {
          if (montant > cashUSD) {
            // Message.showToast(
            //     msg:
            //         'vous n\'avez pas suffisament de fond dans votre compte pour effectuer cet action');
            showDialog(
                context: context,
                builder: (BuildContext context) => new AlertDialog(
                      title: new Text('Solde Insuffisant'),
                      content: new Text(
                          'Veillez approvisionner votre compte pour effectue la transaction'),
                      actions: <Widget>[
                        new IconButton(
                            icon: new Icon(Icons.close),
                            onPressed: () {
                              Navigator.pop(context);
                            })
                      ],
                    ));

            return;
          }
          cashUSD -= montant;
          stockVirtuelUSD += montant;
          notifyListeners();
        }
      }
      //Message.showToast(msg: 'Votre transaction a été effectuée avec succès...');
      callback();

      return await showDialog(
          context: context,
          builder: (BuildContext context) => new AlertDialog(
                title: new Text('Felicitation'),
                content: new Text(
                    'Votre transaction a été effectuée avec succès...'),
                actions: <Widget>[
                  new IconButton(
                      icon: new Icon(Icons.close),
                      onPressed: () {
                        Navigator.pop(context);
                      })
                ],
              ));
    }
  }

//==========================================Depot Virtuel CDF avec 3 CheckBox==========================================
  envoiVirtuel3check(
      {required double montant,
      required String devise,
      required String typedevise,
      required String typeoperation,
      required Function callback,
      required BuildContext context}) async {
    if (devise == 'CDF' &&
        typedevise == 'Virtuel' &&
        typeoperation == 'Depot') {
      if (montant > stockVirtuelCDF) {
        Message.showToast(
            msg:
                'vous n\'avez pas suffisament de fond dans votre compte pour effectuer cet action');

        return;
      }
      stockVirtuelCDF -= montant;

      cashCDF += montant;
      //print(montant);
      notifyListeners();
      callback();

      Message.showToast(
          msg: 'Votre transaction a été effectuée avec succès...');

      return;
    }

    //==========================================Retrait Virtuel USD avec 3 checkBox==========================================

    if (devise == 'USD' &&
        typedevise == 'Virtuel' &&
        typeoperation == 'Retrait') {
      if (montant > stockVirtuelUSD) {
        Message.showToast(
            msg:
                'vous n\'avez pas suffisament de fond dans votre compte pour effectuer cet action ');
        // if (montant == null || devise.isEmpty) {
        //   Message.showToast(msg: 'Veuillez remplir tous les champs');
        // }

        return;
      }
      stockVirtuelUSD -= montant;
      cashUSD += montant;
      notifyListeners();
      Message.showToast(
          msg: 'Votre transaction a été effectuée avec succès...');
      callback();
      return;
    }
    if (devise == 'USD' && typedevise == 'Cash' && typeoperation == 'Depot') {
      if (montant > cashUSD) {
        Message.showToast(
            msg:
                'vous n\'avez pas suffisament de fond dans votre compte pour effectuer cet action');

        return;
      }
      cashUSD -= montant;

      stockVirtuelUSD += montant;
      //print(montant);
      notifyListeners();
      callback();

      Message.showToast(
          msg: 'Votre transaction a été effectuée avec succès...');

      return;
    }

    //==========================================Retrait Cash CDF avec 3 checkBox==========================================

    if (devise == 'CDF' && typedevise == 'Cash' && typeoperation == 'Retrait') {
      if (montant > cashCDF) {
        Message.showToast(
            msg:
                'vous n\'avez pas suffisament de fond dans votre compte pour effectuer cet action ');
        // if (montant == null || devise.isEmpty) {
        //   Message.showToast(msg: 'Veuillez remplir tous les champs');
        // }

        return;
      }
      cashCDF -= montant;
      stockVirtuelCDF += montant;
      notifyListeners();
      Message.showToast(
          msg: 'Votre transaction a été effectuée avec succès...');
      callback();
      return;
    }

    //==========================================Retrait Cash USD  avec 3 checkBox==========================================

    if (devise == 'USD' && typedevise == 'Cash' && typeoperation == 'Retrait') {
      if (montant > cashUSD) {
        Message.showToast(
            msg:
                'vous n\'avez pas suffisament de fond dans votre compte pour effectuer cet action ');
        // if (montant == null || devise.isEmpty) {
        //   Message.showToast(msg: 'Veuillez remplir tous les champs');
        // }

        return;
      }
      cashUSD -= montant;
      stockVirtuelUSD += montant;
      notifyListeners();
      Message.showToast(
          msg: 'Votre transaction a été effectuée avec succès...');
      callback();
      return;
    }

//==========================================Retrait virtuel CDF  avec 3 checkBox==========================================

    if (devise == 'CDF' &&
        typedevise == 'Virtuel' &&
        typeoperation == 'Retrait') {
      if (montant > stockVirtuelCDF) {
        Message.showToast(
            msg:
                'vous n\'avez pas suffisament de fond dans votre compte pour effectuer cet action ');
        // if (montant == null || devise.isEmpty) {
        //   Message.showToast(msg: 'Veuillez remplir tous les champs');
        // }

        return;
      }
      stockVirtuelCDF -= montant;
      cashCDF += montant;
      notifyListeners();
      Message.showToast(
          msg: 'Votre transaction a été effectuée avec succès...');
      callback();
      return;
    }

//==========================================Depot Virtuel USD  avec 3 checkBox==========================================

    if (devise == 'USD' &&
        typedevise == 'Virtuel' &&
        typeoperation == 'Depot') {
      if (montant > stockVirtuelUSD) {
        Message.showToast(
            msg:
                'vous n\'avez pas suffisament de fond dans votre compte pour effectuer cet action ');
        // if (montant == null || devise.isEmpty) {
        //   Message.showToast(msg: 'Veuillez remplir tous les champs');
        // }

        return;
      }
      stockVirtuelUSD -= montant;
      cashUSD += montant;
      notifyListeners();
      Message.showToast(
          msg: 'Votre transaction a été effectuée avec succès...');
      callback();
      return;
    }

//==========================================Depot Cash CDF avec 3 checkBox==========================================

    if (devise == 'CDF' && typedevise == 'Cash' && typeoperation == 'Depot') {
      if (montant > cashCDF) {
        Message.showToast(
            msg:
                'vous n\'avez pas suffisament de fond dans votre compte pour effectuer cet action ');
        // if (montant == null || devise.isEmpty) {
        //   Message.showToast(msg: 'Veuillez remplir tous les champs');
        // }

        return;
      }
      cashCDF -= montant;
      stockVirtuelCDF += montant;
      notifyListeners();
      Message.showToast(
          msg: 'Votre transaction a été effectuée avec succès...');
      callback();
      return;
    }

//==========================================Depot Cash USD avec 3 checkBox==========================================

    if (devise == 'USD' && typedevise == 'Cash' && typeoperation == 'Depot') {
      if (montant > cashCDF) {
        Message.showToast(
            msg:
                'vous n\'avez pas suffisament de fond dans votre compte pour effectuer cet action ');
        // if (montant == null || devise.isEmpty) {
        //   Message.showToast(msg: 'Veuillez remplir tous les champs');
        // }

        return;
      }
      cashUSD -= montant;
      stockVirtuelCDF += montant;
      notifyListeners();
      Message.showToast(
          msg: 'Votre transaction a été effectuée avec succès...');
      callback();
      return;
    }
  }

  List<CaisseModel> historiqueList = [];
  List historiqueData = [];
  updateDemande(
      {required HistoriqueModel historique,
      BuildContext? context,
      required Function callback}) {
    if (historique.designation.isEmpty ||
            historique.description.isEmpty ||
            //creationActiviteModel.type_activite.isEmpty ||
            historique.solde_virtuel_CDF == null ||
            historique.solde_cash_CDF == null ||
            historique.solde_cash_USD == null
        //creationActiviteModel.telephone == null
        ) {
      return Message.showToast(msg: 'Veuillez remplir tous les champs');
    }
    historiqueData[historiqueData.indexWhere(
            (element) => element.id!.toString() == historique.id!.toString())] =
        historique;
    callback();
    notifyListeners();
    print('caisse updated');
  }

  List usersData = [
    ClientModel(
            fname: "Destin",
            lname: "Kabote",
            pname: "Destin",
            role: "Agent",
            email: "destin@naledi.cd",
            telephone: "098889798")
        .toJson(),
    ClientModel(
            fname: "Julio",
            lname: "Kambale",
            pname: "Julio",
            role: "Agent",
            email: "julio@naledi.cd",
            telephone: "0976703577")
        .toJson(),
    ClientModel(
            fname: "Arthur",
            lname: "Mulao",
            pname: "Arthur",
            role: "Agent",
            email: "artur@naledi.cd",
            telephone: "7989869")
        .toJson(),
    ClientModel(
            fname: "Anthony",
            lname: "Chibinda",
            pname: "Antonio",
            role: "Agent",
            email: "anthony@naledi.cd",
            telephone: "07898")
        .toJson(),
    ClientModel(
            fname: "Moise",
            lname: "Bauma",
            pname: "Yosh",
            role: "Agent",
            email: "moise@naledi.cd",
            telephone: "970709")
        .toJson(),
    ClientModel(
            fname: "Patick",
            lname: "Patrick",
            pname: "Patrick",
            role: "Agent",
            email: "patrick@naledi.cd",
            telephone: "89898")
        .toJson(),
  ];

  List providerData = [
    FournisseurModel(
            alert: "urgence",
            montant: "100",
            request_id: "1",
            customer: "Kabote Destin",
            numero: "+243812323468381",
            status: "pending",
            amount_served: "100",
            fournisseur: "Fabrice Makindu")
        .toJson(),
    FournisseurModel(
            alert: "prevention",
            montant: "100",
            request_id: "1",
            customer: "Fabrice Makindu",
            numero: "+24399546788",
            status: "success",
            amount_served: "100",
            fournisseur: "Kabote Destin")
        .toJson(),
    FournisseurModel(
            alert: "rupture_stock",
            montant: "100",
            request_id: "1",
            customer: "Arthur Musomba",
            numero: "+243990876443",
            status: "Denied",
            amount_served: "100",
            fournisseur: "arthur@naledi.cd")
        .toJson()
  ];
  List customerrData = [
    DemandeurModel(
            alert: "urgence",
            montant: "100",
            request_id: "1",
            customer: "Patrick Kamanda",
            numero: "+2439974328381",
            status: "pending",
            amount_served: "100",
            fournisseur: "Providence Kambale")
        .toJson(),
    DemandeurModel(
            alert: "prevention",
            montant: "100",
            request_id: "1",
            customer: "Providence Kambale",
            numero: "+2439909878381",
            status: "success",
            amount_served: "100",
            fournisseur: "Moise Bauma")
        .toJson(),
    DemandeurModel(
            alert: "rupture_stock",
            montant: "100",
            request_id: "1",
            customer: "Moise Bauma",
            numero: "+243870268381",
            status: "denied",
            amount_served: "100",
            fournisseur: "Providence Kambale")
        .toJson()
  ];

  calculateUserScore() {
    cashCDF = 0;
    if (personalInfoUser != null) {
      cashCDF += singleStepValue;
    }
    if (pickedFiles.isNotEmpty) {
      cashCDF += singleStepValue;
    }
    // if (nearestPersonData != null) {
    //   userScore += singleStepValue;
    // }
    if (nominatedAdminData != null) {
      cashCDF += singleStepValue;
    }
    if (employerData != null) {
      cashCDF += singleStepValue;
    }
    if (creditHistoryData.isNotEmpty) {
      cashCDF += singleStepValue;
    }
  }

  ClientModel? clientData;

  initUserData({required BuildContext context, required bool isRefreshed}) {
    // getCreditHistory(context: context, isRefreshed: false);
    // getStatementPosition(context: context, isRefreshed: false);
    // getPayablePersonInfo(context: context);
    // getEmployerInfo(context: context);
    getUserData();
    getClientData(context: context, isRefreshed: isRefreshed);
  }

  createNewUser(
      {required BuildContext context,
      required ClientModel clientModel,
      required Function callback}) async {
    if (clientModel.fname.isEmpty ||
        clientModel.lname.isEmpty ||
        clientModel.password == null) {
      return Message.showToast(msg: 'Veuillez remplir tous les champs');
    }
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    var response = await Provider.of<AppStateProvider>(context, listen: false)
        .httpPost(url: BaseUrl.addUser, body: clientModel.toJson());
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    if (response.body != "error") {
      if (response.body != null) {
        Message.showToast(msg: 'User created successfuly');
        clientData = ClientModel.fromJson(jsonDecode(response.body));

        Provider.of<AppStateProvider>(context, listen: false)
            .changeConnexionState(context: context);
        Provider.of<MenuStateProvider>(context, listen: false).activePage =
            const ProfilePage();
        callback();
        notifyListeners();
      } else {
        Message.showToast(msg: 'Error occured');
      }
    } else {
      Message.showToast(msg: 'Error occured on the server');
    }
  }

  loginUser(
      {required BuildContext context,
      required Map clientModel,
      required Function callback}) async {
    if (clientModel['email'].toString().isEmpty ||
        clientModel['psw'].toString().isEmpty) {
      return Message.showToast(msg: 'Veuillez remplir tous les champs');
    }
    // print(clientModel);
    // return;
    // Provider.of<AppStateProvider>(context, listen: false)
    //     .changeConnexionState(context: context);
    // Provider.of<MenuStateProvider>(context, listen: false).setDefault(
    //     pageData: {"name": "Dashboard", "page": HomeDashboardPage()});
    // return;

    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    // var response = await Provider.of<AppStateProvider>(context, listen: false)
    //     .httpPost(url: BaseUrl.getLogin, body: clientModel);
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    // clientData = ClientModel.fromJson(jsonDecode(response.body));
    //     personalInfoUser = clientData;

    Provider.of<AppStateProvider>(context, listen: false)
        .changeConnexionState(context: context);
    Provider.of<MenuStateProvider>(context, listen: false)
        .setDefault(pageData: {"name": "Dashboard", "page": ClientHomePage()});
    callback();
    // if (response.statusCode >= 200 && response.statusCode < 300) {
    //   if (response.body != null) {
    //     clientData = ClientModel.fromJson(jsonDecode(response.body));
    //     personalInfoUser = clientData;

    //     Provider.of<AppStateProvider>(context, listen: false)
    //         .changeConnexionState(context: context);
    //     Provider.of<MenuStateProvider>(context, listen: false).setDefault(
    //         pageData: {"name": "Dashboard", "page": HomeDashboardPage()});
    //     callback();
    //     // return print(personalInfoUser!.toJson());
    //     prefs.setString("userData", response.body);
    //     notifyListeners();
    //   } else {
    //     Message.showToast(msg: 'Error occured');
    //   }
    // } else if (response.statusCode == 401) {
    //   var decoded = jsonDecode(response.body);
    //   Message.showToast(msg: "${decoded['message'].toString().trim()}");
    // } else {
    //   Message.showToast(msg: 'Server unreachable, please try again layer');
    // }
  }

  logOut() {
    personalInfoUser = null;
    clientData = null;
    nominatedAdminData.clear();
    employerData.clear();
    creditHistoryData.clear();
    pickedFiles.clear();
    statementPositionData.clear();
    notifyListeners();
  }

  ClientModel? personalInfoUser;

  addPersonalInfo(
      {required BuildContext context,
      required ClientModel personalInfo,
      required Function callback}) async {
    if (personalInfo.fname.isEmpty ||
        personalInfo.lname.isEmpty ||
        personalInfo.pname == null ||
        personalInfo.dob == null ||
        personalInfo.genre == null ||
        personalInfo.marriagestatus == null ||
        personalInfo.telephone == null ||
        personalInfo.email == null ||
        personalInfo.country == null ||
        personalInfo.country == 'null' ||
        personalInfo.address == null) {
      return Message.showToast(msg: 'Veuillez remplir tous les champs');
    }
    // return print(personalInfo.toJson());
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    var response = await Provider.of<AppStateProvider>(context, listen: false)
        .httpPut(
            url: "${BaseUrl.addUser}${userId.toString()}",
            body: personalInfo.toJson());
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    // Message.showToast(msg: 'Informations ajoutees avec succes');
    // personalInfoUser = personalInfo;
    // callback();
    if (response.statusCode >= 200 && response.statusCode < 300) {
      print(response.body);
      return;
      personalInfoUser = ClientModel.fromJson(jsonDecode(response.body));
      clientData = ClientModel.fromJson(jsonDecode(response.body));
      calculateUserScore();
      callback();
      notifyListeners();
      Message.showToast(msg: 'Informations ajoutees avec succes');
    } else {
      Message.showToast(msg: 'Une erreur est survenue');
    }
  }

  List<PayablePersonModel> nominatedAdminData = [];

  addPayablePersonInfo(
      {required BuildContext context,
      required PayablePersonModel nominatedAdmin,
      required Function callback}) async {
    if (nominatedAdmin.names.isEmpty ||
        nominatedAdmin.relation.isEmpty ||
        nominatedAdmin.address.isEmpty ||
        nominatedAdmin.telephone.isEmpty ||
        nominatedAdmin.payableStatus.isNaN ||
        nominatedAdmin.nameAcount == null ||
        nominatedAdmin.dob == null ||
        nominatedAdmin.acountNumber == null ||
        nominatedAdmin.email == null) {
      return Message.showToast(msg: 'Veuillez remplir tous les champs');
    }
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    var response = await Provider.of<AppStateProvider>(context, listen: false)
        .httpPost(url: BaseUrl.payablePerson, body: nominatedAdmin.toJson());
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();

    if (response.body != "error") {
      nominatedAdminData
          .add(PayablePersonModel.fromJson(jsonDecode(response.body)));
      callback();
      Message.showToast(msg: 'Informations ajoutees avec succes');
    } else {
      Message.showToast(msg: 'Une erreur est survenue');
    }
    calculateUserScore();
    notifyListeners();
  }

  List<EmployerModel> employerData = [];

  addEmployerInfo(
      {required BuildContext context,
      required EmployerModel employer,
      required bool updatingData,
      required Function callback}) async {
    if (employer.names.isEmpty ||
        employer.domain.isEmpty ||
        employer.startContract.isEmpty ||
        employer.address.isEmpty ||
        employer.email.isEmpty ||
        employer.telephone.isEmpty) {
      return Message.showToast(msg: 'Veuillez remplir tous les champs');
    }
    // print(employer.toJson());
    // return;
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    var response;
    if (updatingData == false) {
      response = await Provider.of<AppStateProvider>(context, listen: false)
          .httpPost(url: BaseUrl.employer, body: employer.toJson());
    } else {
      response = await Provider.of<AppStateProvider>(context, listen: false)
          .httpPut(
              url: "${BaseUrl.employer}${employer.id!.toString().trim()}",
              body: employer.toJson());
    }
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    // Message.showToast(msg: 'Informations ajoutees avec succes');

    if (response.body != "error") {
      EmployerModel employerResponse =
          EmployerModel.fromJson(jsonDecode(response.body));
      if (updatingData == true) {
        employerData.where((employer) {
          return employer.id! == employerResponse.id;
        }).toList()[0] = employerResponse;
      } else {
        employerData.add(employerResponse);
      }

      callback();
      Message.showToast(msg: 'Informations ajoutees avec succes');
    } else {
      Message.showToast(msg: 'Une erreur est survenue');
    }
    calculateUserScore();
    notifyListeners();
  }

  List<PlatformFile> pickedFiles = [];

  addFiles(
      {required BuildContext context,
      required List<PlatformFile> picked,
      required Function callback}) async {
    if (picked.isEmpty) {
      return Message.showToast(msg: 'Veuillez choisir au moins un fichier');
    }
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    // var response = await Provider.of<AppStateProvider>(context, listen: false)
    //     .httpPost(
    //         url: Uri(host: "http://192.169.2.137/andema/user/add"),
    // await Future.delayed(const Duration(seconds: 2));
    //         body: personalInfo.toJson());
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    Message.showToast(msg: 'Informations ajoutees avec succes');
    picked.forEach((file) {
      pickedFiles.add(file);
    });
    // pickedFiles.add(picked);
    // print(creditHistoryData);
    callback();
    // if (response.statusCode == 200) {
    //   Message.showToast(msg: 'Informations ajoutees avec succes');
    // } else {
    //   Message.showToast(msg: 'Une erreur est survenue');
    // }
    calculateUserScore();
    notifyListeners();
  }

  List<CreditHistoryModel> creditHistoryData = [];

  addCreditHistoryInfo(
      {required BuildContext context,
      required CreditHistoryModel creditHistory,
      required Function callback}) async {
    if (creditHistory.address.isEmpty || creditHistory.institution.isEmpty) {
      return Message.showToast(msg: 'Veuillez remplir tous les champs');
    }
    // print(creditHistory.toJson());
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    var response = await Provider.of<AppStateProvider>(context, listen: false)
        .httpPost(
            url: BaseUrl.externalLoansHistory, body: creditHistory.toJson());
    //         body: personalInfo.toJson());
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();

    if (response.body != "error") {
      {
        callback();
        creditHistoryData
            .add(CreditHistoryModel.fromJson(jsonDecode(response.body)));
        Message.showToast(msg: 'Informations ajoutees avec succes');
      }
    } else {
      Message.showToast(msg: 'Une erreur est survenue');
    }
    calculateUserScore();
    notifyListeners();
  }

  List<StatementPositionModel> statementPositionData = [];

  addStatementPosition(
      {required BuildContext context,
      required StatementPositionModel statementPosition,
      required bool updatingData,
      required Function callback}) async {
    if (statementPosition.type.isEmpty ||
        statementPosition.description.isEmpty ||
        statementPosition.category.isEmpty ||
        statementPosition.montant.isNaN ||
        statementPosition.montant.isNegative) {
      return Message.showToast(msg: 'Veuillez saisir des données correctes');
    }

    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    var response;
    if (updatingData == false) {
      response = await Provider.of<AppStateProvider>(context, listen: false)
          .httpPost(
              url: BaseUrl.statementPosition, body: statementPosition.toJson());
    } else {
      response = await Provider.of<AppStateProvider>(context, listen: false)
          .httpPut(
              url:
                  "${BaseUrl.statementPosition}${statementPosition.id!.toString().trim()}",
              body: statementPosition.toJson());
    }
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();

    if (response.body != "error") {
      Message.showToast(msg: 'Informations ajoutees avec succes');
      StatementPositionModel dataResponse =
          StatementPositionModel.fromJson(jsonDecode(response.body));
      if (updatingData == true) {
        statementPositionData.where((employer) {
          return employer.id! == dataResponse.id;
        }).toList()[0] = dataResponse;
      } else {
        statementPositionData.add(dataResponse);
      }
      callback();
    } else {
      Message.showToast(msg: 'Une erreur est survenue');
    }
    calculateUserScore();
    notifyListeners();
  }

  List<BankModel> banks = [];
  addBank(
      {required BuildContext context,
      required BankModel bank,
      required bool updatingData,
      required Function callback}) async {
    if (bank.institution.isEmpty ||
        bank.address.isEmpty ||
        bank.accountName.isEmpty ||
        bank.accountNumber.isEmpty) {
      return Message.showToast(msg: 'Veuillez saisir des données correctes');
    }

    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    // var response;
    // if (updatingData == false) {
    //   response = await Provider.of<AppStateProvider>(context, listen: false)
    //       .httpPost(
    //       url: BaseUrl.statementPosition, body: bank.toJson());
    // } else {
    //   response = await Provider.of<AppStateProvider>(context, listen: false)
    //       .httpPut(
    //       url:
    //       "${BaseUrl.statementPosition}${bank.id!.toString().trim()}",
    //       body: bank.toJson());
    // }
    await Future.delayed(const Duration(seconds: 2));
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();

    if (updatingData == true) {
      banks.where((bankList) {
        return bankList.id! == bank.id;
      }).toList()[0] = bank;
    } else {
      banks.add(bank);
    }
    callback();
    Message.showToast(msg: 'Informations ajoutees avec succes');
    // if (response.body != "error") {
    //   Message.showToast(msg: 'Informations ajoutees avec succes');
    //   BankModel dataResponse =
    //   BankModel.fromJson(jsonDecode(response.body));
    //   if (updatingData == true) {
    //     banks.where((employer) {
    //       return employer.id! == dataResponse.id;
    //     }).toList()[0] = dataResponse;
    //   } else {
    //     banks.add(dataResponse);
    //   }
    //   callback();
    // } else {
    //   Message.showToast(msg: 'Une erreur est survenue');
    // }
    calculateUserScore();
    notifyListeners();
  }

  getClientData(
      {required BuildContext context, required bool isRefreshed}) async {
    if (isRefreshed == false && statementPositionData.isNotEmpty) return;
    statementPositionData.clear();
    creditHistoryData.clear();
    nominatedAdminData.clear();
    employerData.clear();
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    var response =
        await Provider.of<AppStateProvider>(context, listen: false).httpGet(
      url: "${BaseUrl.user}$userId",
    );
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    if (response.body != "error" && response.body != "null") {
      var decoded = jsonDecode(response.body);
      for (var row in decoded['payablePersons']) {
        nominatedAdminData.add(PayablePersonModel.fromJson(row));
      }
      for (var row in decoded['employers']) {
        employerData.add(EmployerModel.fromJson(row));
      }
      for (var row in decoded['statmentpositions']) {
        statementPositionData.add(StatementPositionModel.fromJson(row));
      }
      // for (var row in decoded['externalLaons']) {
      //   creditHistoryData.add(CreditHistoryModel.fromJson(row));
      // }
      notifyListeners();
    } else {
      Message.showToast(msg: 'Impossible de recuperer les donnees');
    }
  }

  dataSetter(
      {required List source, required var destination, required var model}) {
    for (var row in source) {
      destination.add(model.fromJson(row));
    }
  }

  //
  // getStatementPosition(
  //     {required BuildContext context, required bool isRefreshed}) async {
  //   if (statementPositionData.isNotEmpty && isRefreshed == false) return;
  //   statementPositionData.clear();
  //   Provider.of<AppStateProvider>(context, listen: false).changeAppState();
  //   var response =
  //       await Provider.of<AppStateProvider>(context, listen: false).httpGet(
  //     url: BaseUrl.statementPosition,
  //   );
  //   Provider.of<AppStateProvider>(context, listen: false).changeAppState();
  //   if (response.body != "error" && response.body != "null") {
  //     List decoded = jsonDecode(response.body);
  //     for (var statement in decoded) {
  //       statementPositionData.add(StatementPositionModel.fromJson(statement));
  //     }
  //     notifyListeners();
  //   } else {
  //     Message.showToast(
  //         msg: 'Impossible de recuperer les donnees des possession');
  //   }
  // }
  //
  // // tryGetOnline({required BuildContext context}) async {
  // //   var response =
  // //       await Provider.of<AppStateProvider>(context, listen: false).httpGet(
  // //     url: "http://api-ohada.naledi.cd/api/classes",
  // //   );
  // //   print(response.body);
  // // }
  //
  // getCreditHistory(
  //     {required BuildContext context, required bool isRefreshed}) async {
  //   if (creditHistoryData.isNotEmpty && isRefreshed == false) return;
  //   creditHistoryData.clear();
  //   Provider.of<AppStateProvider>(context, listen: false).changeAppState();
  //   var response =
  //       await Provider.of<AppStateProvider>(context, listen: false).httpGet(
  //     url: BaseUrl.externalLoansHistory,
  //   );
  //   Provider.of<AppStateProvider>(context, listen: false).changeAppState();
  //   if (response.body != "error") {
  //     List decoded = jsonDecode(response.body);
  //     for (var credit in decoded) {
  //       creditHistoryData.add(CreditHistoryModel.fromJson(credit));
  //     }
  //     notifyListeners();
  //   } else {
  //     Message.showToast(
  //         msg: 'Impossible de recuperer les donnees des possession');
  //   }
  // }
  //
  // getPayablePersonInfo({
  //   required BuildContext context,
  // }) async {
  //   nominatedAdminData.clear();
  //   Provider.of<AppStateProvider>(context, listen: false).changeAppState();
  //   var response = await Provider.of<AppStateProvider>(context, listen: false)
  //       .httpGet(url: BaseUrl.payablePerson);
  //   Provider.of<AppStateProvider>(context, listen: false).changeAppState();
  //
  //   if (response.body != "error") {
  //     List decoded = jsonDecode(response.body);
  //     for (var payable in decoded) {
  //       nominatedAdminData.add(PayablePersonModel.fromJson(payable));
  //     }
  //   } else {
  //     Message.showToast(msg: 'Une erreur est survenue');
  //   }
  //   calculateUserScore();
  //   notifyListeners();
  // }
  //
  // getEmployerInfo({
  //   required BuildContext context,
  // }) async {
  //   employerData.clear();
  //   Provider.of<AppStateProvider>(context, listen: false).changeAppState();
  //   var response = await Provider.of<AppStateProvider>(context, listen: false)
  //       .httpGet(url: BaseUrl.employer);
  //   Provider.of<AppStateProvider>(context, listen: false).changeAppState();
  //
  //   if (response.body != "error") {
  //     List decoded = jsonDecode(response.body);
  //     for (var employer in decoded) {
  //       employerData.add(EmployerModel.fromJson(employer));
  //     }
  //   } else {
  //     Message.showToast(msg: 'Une erreur est survenue');
  //   }
  //   calculateUserScore();
  //   notifyListeners();
  // }

  double sumData({required List<StatementPositionModel> data}) {
    double total = 0;
    for (var i = 0; i < data.length; i++) {
      total += data[i].montant;
    }
    return total;
  }

  getUserData() {
    var savedUser = prefs.getString('userData');
    Map user = savedUser != null ? jsonDecode(savedUser) : {};
    if (user.isNotEmpty) {
      clientData = ClientModel.fromJson(user);
      personalInfoUser = clientData;
      userId = clientData!.id!;
    }
    // print(user);
    notifyListeners();
  }

  // =================================ORION USER STATEPROVIDER=======================

  List<EnvoieModel> envoieModels = [];
  addEnvoi(
      {required BuildContext context,
      required EnvoieModel envoieModel,
      required bool updatingData,
      required Function callback}) async {
    if (envoieModel.Nom_beneficiaire.isEmpty ||
        envoieModel.password.isEmpty ||
        //envoieModel.commentaire.isEmpty ||
        envoieModel.montant.isEmpty) {
      return Message.showToast(msg: 'Veuillez saisir des données correctes');
    }

    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    // var response;
    // if (updatingData == false) {
    //   response = await Provider.of<AppStateProvider>(context, listen: false)
    //       .httpPost(
    //       url: BaseUrl.statementPosition, body: bank.toJson());
    // } else {
    //   response = await Provider.of<AppStateProvider>(context, listen: false)
    //       .httpPut(
    //       url:
    //       "${BaseUrl.statementPosition}${bank.id!.toString().trim()}",
    //       body: bank.toJson());
    // }
    await Future.delayed(const Duration(seconds: 2));
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();

    if (updatingData == true) {
      envoieModels.where((envoieList) {
        return envoieList.id! == envoieModel.id;
      }).toList()[0] = envoieModel;
    } else {
      envoieModels.add(envoieModel);
    }
    callback();
    Message.showToast(msg: 'Informations ajoutees avec succes');
    // if (response.body != "error") {
    //   Message.showToast(msg: 'Informations ajoutees avec succes');
    //   BankModel dataResponse =
    //   BankModel.fromJson(jsonDecode(response.body));
    //   if (updatingData == true) {
    //     banks.where((employer) {
    //       return employer.id! == dataResponse.id;
    //     }).toList()[0] = dataResponse;
    //   } else {
    //     banks.add(dataResponse);
    //   }
    //   callback();
    // } else {
    //   Message.showToast(msg: 'Une erreur est survenue');
    // }
    calculateUserScore();
    notifyListeners();
  }

  List<ApprovisionnementModel> approvisionnementModels = [];
  addApprov(
      {required BuildContext context,
      required ApprovisionnementModel approvisionnementModel,
      required bool updatingData,
      required Function callback}) async {
    if (approvisionnementModel.nom_Expediteur.isEmpty ||
        approvisionnementModel.password.isEmpty ||
        //approvisionnementModel.commentaire.isEmpty ||
        approvisionnementModel.montant.isEmpty) {
      return Message.showToast(msg: 'Veuillez saisir des données correctes');
    }

    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    // var response;
    // if (updatingData == false) {
    //   response = await Provider.of<AppStateProvider>(context, listen: false)
    //       .httpPost(
    //       url: BaseUrl.statementPosition, body: bank.toJson());
    // } else {
    //   response = await Provider.of<AppStateProvider>(context, listen: false)
    //       .httpPut(
    //       url:
    //       "${BaseUrl.statementPosition}${bank.id!.toString().trim()}",
    //       body: bank.toJson());
    // }
    await Future.delayed(const Duration(seconds: 2));
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();

    if (updatingData == true) {
      approvisionnementModels.where((approvisionnementModelList) {
        return approvisionnementModelList.id! == approvisionnementModel.id;
      }).toList()[0] = approvisionnementModel;
    } else {
      approvisionnementModels.add(approvisionnementModel);
    }
    callback();
    Message.showToast(msg: 'Informations ajoutees avec succes');
    // if (response.body != "error") {
    //   Message.showToast(msg: 'Informations ajoutees avec succes');
    //   BankModel dataResponse =
    //   BankModel.fromJson(jsonDecode(response.body));
    //   if (updatingData == true) {
    //     banks.where((employer) {
    //       return employer.id! == dataResponse.id;
    //     }).toList()[0] = dataResponse;
    //   } else {
    //     banks.add(dataResponse);
    //   }
    //   callback();
    // } else {
    //   Message.showToast(msg: 'Une erreur est survenue');
    // }
    calculateUserScore();
    notifyListeners();
  }

  List<PretModel> pretModels = [];
  addpret(
      {required BuildContext context,
      required PretModel pretModel,
      required bool updatingData,
      required Function callback}) async {
    if (pretModel.Nom_beneficiaire.isEmpty ||
        //pretModel.commentaire.isEmpty ||
        pretModel.password.isEmpty ||
        pretModel.montant.isEmpty) {
      return Message.showToast(msg: 'Veuillez saisir des données correctes');
    }

    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    // var response;
    // if (updatingData == false) {
    //   response = await Provider.of<AppStateProvider>(context, listen: false)
    //       .httpPost(
    //       url: BaseUrl.statementPosition, body: bank.toJson());
    // } else {
    //   response = await Provider.of<AppStateProvider>(context, listen: false)
    //       .httpPut(
    //       url:
    //       "${BaseUrl.statementPosition}${bank.id!.toString().trim()}",
    //       body: bank.toJson());
    // }
    await Future.delayed(const Duration(seconds: 2));
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();

    if (updatingData == true) {
      pretModels.where((pretModelList) {
        return pretModelList.id! == pretModel.id;
      }).toList()[0] = pretModel;
    } else {
      pretModels.add(pretModel);
    }
    callback();
    Message.showToast(msg: 'Informations ajoutees avec succes');
    // if (response.body != "error") {
    //   Message.showToast(msg: 'Informations ajoutees avec succes');
    //   BankModel dataResponse =
    //   BankModel.fromJson(jsonDecode(response.body));
    //   if (updatingData == true) {
    //     banks.where((employer) {
    //       return employer.id! == dataResponse.id;
    //     }).toList()[0] = dataResponse;
    //   } else {
    //     banks.add(dataResponse);
    //   }
    //   callback();
    // } else {
    //   Message.showToast(msg: 'Une erreur est survenue');
    // }
    calculateUserScore();
    notifyListeners();
  }

  List<EmpruntModel> empruntModels = [];
  addEmprunt(
      {required BuildContext context,
      required EmpruntModel empruntModel,
      required bool updatingData,
      required Function callback}) async {
    if (empruntModel.nom_Expediteur.isEmpty ||
        //approvisionnementModel.commentaire.isEmpty ||
        empruntModel.password.isEmpty ||
        empruntModel.montant.isEmpty) {
      return Message.showToast(msg: 'Veuillez saisir des données correctes');
    }

    Provider.of<AppStateProvider>(context, listen: false).changeAppState();
    // var response;
    // if (updatingData == false) {
    //   response = await Provider.of<AppStateProvider>(context, listen: false)
    //       .httpPost(
    //       url: BaseUrl.statementPosition, body: bank.toJson());
    // } else {
    //   response = await Provider.of<AppStateProvider>(context, listen: false)
    //       .httpPut(
    //       url:
    //       "${BaseUrl.statementPosition}${bank.id!.toString().trim()}",
    //       body: bank.toJson());
    // }
    await Future.delayed(const Duration(seconds: 2));
    Provider.of<AppStateProvider>(context, listen: false).changeAppState();

    if (updatingData == true) {
      empruntModels.where((empruntModelList) {
        return empruntModelList.id! == empruntModel.id;
      }).toList()[0] = empruntModel;
    } else {
      empruntModels.add(empruntModel);
    }
    callback();
    Message.showToast(msg: 'Informations ajoutees avec succes');
    // if (response.body != "error") {
    //   Message.showToast(msg: 'Informations ajoutees avec succes');
    //   BankModel dataResponse =
    //   BankModel.fromJson(jsonDecode(response.body));
    //   if (updatingData == true) {
    //     banks.where((employer) {
    //       return employer.id! == dataResponse.id;
    //     }).toList()[0] = dataResponse;
    //   } else {
    //     banks.add(dataResponse);
    //   }
    //   callback();
    // } else {
    //   Message.showToast(msg: 'Une erreur est survenue');
    // }
    calculateUserScore();
    notifyListeners();
  }
}
