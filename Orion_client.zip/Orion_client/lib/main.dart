import 'package:orion/Resources/AppStateProvider/Guichet/creation_caisse_stateprovider.dart';
import 'package:orion/Resources/AppStateProvider/app_stateprovider.dart';
import 'package:orion/Resources/AppStateProvider/loan_stateprovider.dart';
import 'package:orion/Resources/AppStateProvider/menu_state_provider.dart';

import 'package:orion/Resources/AppStateProvider/user_stateprovider.dart';
import 'package:orion/Resources/theme.dart';
import 'package:orion/Views/Admin_Orion/Resources/AppStateProvider/app_stateprovider.dart';
import 'package:orion/Views/Admin_Orion/Resources/AppStateProvider/menu_state_provider.dart';
import 'package:orion/Views/Admin_Orion/Resources/AppStateProvider/theme_stateprovider.dart';
import 'package:orion/Views/Admin_Orion/Resources/AppStateProvider/user_stateprovider.dart';
import 'package:orion/Views/Login/login_main_page.dart';
import 'package:orion/Views/Login/login_page.dart';
import 'package:flutter/material.dart';
import 'package:orion/Views/Home/home_page_new.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'Views/Home/home_page.dart';

late SharedPreferences prefs;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  prefs = await SharedPreferences.getInstance();
  // Stripe.init(
  //     production: false,
  //     publicKey: Config.checkProd()['pubKey'],
  //     secretKey: Config.checkProd()['secKey'],
  //     useLogger: true);
  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider(create: (_) => MenuStateProvider()),
      ChangeNotifierProvider(create: (_) => AppStateProvider()),
      ChangeNotifierProvider(create: (_) => UserStateProvider()),
      ChangeNotifierProvider(create: (_) => AdminUserStateProvider()),
      ChangeNotifierProvider(create: (_) => adminAppStateProvider()),
      ChangeNotifierProvider(create: (_) => AdminMenuStateProvider()),
      ChangeNotifierProvider(create: (_) => LoanStateProvider()),
      ChangeNotifierProvider(create: (_) => adminThemeStateProvider()),
      ChangeNotifierProvider(create: (_) => CaisseStateProvider()),
    ],
    child: const MyApp(),
  ));
}

GlobalKey<NavigatorState> navKey = GlobalKey<NavigatorState>();

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Orion | Manage your busness in secure way',
      //themeMode: Provider.of<MenuStateProvider>(context).theme,
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.light,
      theme: Themes.lightTheme,
      //home: const startupLoginPage(),
      home: const HomePage2(),
      navigatorKey: navKey,
    );
  }
}
